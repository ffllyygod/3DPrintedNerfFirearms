This is the FMDA DD17.2 3D-printable Glock Frame
In addition to Glock 17 uppers/slides, it is compatible with Glock 22 uppers/slides

Original model developed by FMDA

The files found in the main directory - the documentation and the base files - are drawn as a blank slate - for a whole collection of remixes (both fun and possibly functional), refer to the "Remixes" folder.
To submit something (a remix, doodad, etc) to be included in the Add-On package, refer to the file in this package named 'Information Regarding Edits, Remixes, And Alternate Versions.txt'.

For help finishing your build, refer to the 'DD17.2 Build Tutorial' pdf found in this download package, as well as the video you can watch and download here: https://lbry.tv/@Ivan's_CAD_Streams:c/FMDADD17.2GlockFrameTutorial:e

For general print settings:

This frame has been tested to work well in eSun PLA+. In any material similar or superior to PLA+, this frame should work as well.
(You can print in Glass-Filled Zytel for a very strong frame. I recommend you learn how to print Zytel on your machine, then use those settings. Keep the nozzle hot - 290 - 300C ideally. Run a hot soldering iron over the outside layers of the finished frame to remelt those layers and you'll be left with a really tough frame.)

**Note that all STL files are oriented and scaled properly, and changing their scale or orientation may result in your parts not fitting/working properly.**
**Note on orientation - there's a lot of debate about which orientation to print pistol frames in. I've found upright works great for this particular frame when printed in PLA or Zytel. If you print in something that is prone to warp (like ABS), you might want to print it inverted to keep the bulk of the frame close to the heat coming off the bed (which will help discourage warp).
**Note that you MUST follow these print settings in order to get the best possible results - changing nozzle size or layer height may cause you to have to hand fit things!**

My print settings for PLA+ were as follows:

Nozzle: 0.4mm
Layer Height: 0.15mm
Temp: 230/60C
Infill: 100% (You can use 99% infill on Cura to speed up the print time)
Supports: On/full (tree supports are ok) - use a close support interface gap. Your interface gap should not be larger than 0.15mm unless you know what you are doing with your setup.
Cooling fan: 20% normal, 50% on bridges. Off for the first 10 layers. Keep the fan low to prevent warp.
Bed Adhesion: gluestick or hairspray or both

Post processing: If you print your frame upright, you can clean up the rough bottom-facing areas of your print with a soldering iron - after removing supports, take your soldering iron and melt the rough patches on the frame together to make them smooth.

All other settings can/should be left as default or whatever you know works best with your printing setup.


This project is published under the Unlicense.
