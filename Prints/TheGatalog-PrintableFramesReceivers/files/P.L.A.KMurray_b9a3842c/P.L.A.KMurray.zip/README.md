# P.L.A. (Printed Lever Action) Version 1.0
Printed receiver for the henry H001 .22lr lever guns.

by Kmurray
- Special thanks to @gerold_euerle on Twitter. This would not have existed without his help :D

## Description
This is a printed receiver for a Henry classic lever action in .22LR/L/S. Not to be confused with the locust, which is a printed lever action by SwarmTechDesign. So far this frame has been tested with PLA+. In it's current state it requires one extra screw and nut that you won't find in a parts kit. That is an M4 x 8 socket head screw and M4 nut for the tang-receiver connection. This version will also require drilling out the holes to the final dimension for most of the pins, as well as some general fitting. Here's some videos showing the disassembly/assembly process as well as how it works:

**NOTE: PLEASE MAKE SURE YOUR PRINTER IS TUNED WELL BEFORE PRINTING! The tolerances of this frame are very sensitive to even slightly uncalibrated printers. Please print the calibration cube first and make sure your dimensions are all within reason before continuing!**

https://youtu.be/djF-rPvaB3s	-Disassembly/assembly

https://youtu.be/CBflIe-iq7Y	-How it works

## Materials required:
- x1 **Henry H001 parts kit**
- x1 **M4 x 8 socket head screw**
- x1 **M4 Nut**


## Print settings (Settings used with the Prusa I3 MK3S):
- Nozzle dia: 0.4mm

- Layer Height: 0.2-0.3mm

- Perimeters: 5+

- Infill: 100%

- Skirt/Brim: 5mm Brim

- Support: On build plate only

- Support Z distance: 0.15mm

- Speed: ~30mm/s or less 

- Extrusion width: 0.6mm

- External perimeter extrusion width: 0.4mm 

- Cooling: Off/low


## Filament
Esun/Duramic PLA+  (Do not use 3Dfuel as it has been found to be far weaker than other PLA+ brands. Would recommend using a PLA+ filament that you have TESTED and KNOW to be strong)

- Temp: ~225-235c

- Bed: ~55c + glue stick


## Change log
 - v1.1: Version 1.1 Release
	- Documentation update
 - v1.0: Version 1.0 Release 
    - Documentation update
 - v0.5: Version 0.5 Beta Release
    - Added an optional version of the receiver with the lever area reinforced
	- Changed the geometry to allow the use of an M4 nut for the tang-receiver connection
	- Further strengthened the spring perch on the tang itself
	- Removed unnecessary shelves on back of receiver
	- Skipped v0.4 to avoid confusion
	- Documentation update




## License
No License selected