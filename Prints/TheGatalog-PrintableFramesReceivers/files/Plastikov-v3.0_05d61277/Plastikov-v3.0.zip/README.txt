The Plastikov
3D Printable AKM, RPK, and AK100-Compatible Receiver
v3.0 Update

Refer to the "Plastikov v3.0 Build Tutorial for detailed assembly instructions! Read it completely for info on how to build, how to troubleshoot, etc.
While the documentation is lengthy, don't mistake the overall process for being complex - the documentation is meant to aid everyone from newbies to experienced folks in putting an AK together.

Printable Parts Checklist:
	Front Receiver (Either AKM, RPK, or AK100 - most likely, you'll want the AKM since RPK and AK100 kits are rare)
	Rear Receiver (Either AR15 tube based or rear-facing pic rail based. Standard AK stocks don't place nice with a printed receiver)
	Top Cover (Standard AK top covers don't fit on the Plastikov without modifiction to the top cover - while you could grind on yours for a bit, the printed top covers are tested throughly and work well, though may take a little fitting to your particular kit!)

Hardware Checklist:

	Refer to the "Shopping List" section of the build tutorial pdf.




Printing Options/Settings:

     - For filament, eSun PLA+ is thoroughly tested.  Materials with better heat resistance than PLA will let you dump more mags before needing to let the gun cool.
     - A printer capable of printing PLA (or the plastic you choose to use).  The Creality Ender 3 is capable.


		
General Print Settings:

	This receiver has been tested to work well in eSun PLA+. In any material similar or superior to PLA+, this receiver should work as well.

**Note that all STL files are oriented and scaled properly, and changing their scale or orientation may result in your parts not fitting/working properly. Especially with parts like the barrel mount and receivers, orientation is important!**
**Note that you should follow these print settings in order to get the best possible results - changing nozzle size or layer height may cause you to have to hand fit things!**

My print settings for PLA+ were as follows:

	Walls: 8 (Very important to set walls to 8 - you should be able to go higher, but going lower will signifcantly weaken the flanges that mate the receiver sections)
	Nozzle: 0.4mm
	Layer Height: 0.15mm
	Temp: 230/60C
	Infill For all part except rear receiver: 50% (If printing in flexible materials you should bump this up a little. Printing at 100% fill with PLA tends to just waste a lot of filament, but you can do so if you wish. This receiver is thick to reduce flex, and gets the strenght it needs from having 8 inner and out walls - 50% infill offers all the required stiffness)
	Infill For rear receiver: 100%. This can be printed at 50%, but in order to help this part be strong enough to withstand recoil when the gun isn't held tight into your shoulder, printing it at 100% is ideal.
	Supports: On/full (tree supports are ok)
	Cooling fan: 20% normal, 50% on bridges. Off for the first 20 layers. Keep the fan low to prevent warp.
	Bed Adhesion: gluestick or hairspray - since the big sections of this print have small footprints on the bed, using plenty of gluestick or hairspray is recommended.

	All other settings can/should be left as default or whatever you know works best with your printing setup.
