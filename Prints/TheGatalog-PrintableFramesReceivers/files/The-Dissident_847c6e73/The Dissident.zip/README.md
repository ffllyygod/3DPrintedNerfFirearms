Dissident by mprtech

Printable AR bufferless using the CMMG Dissent bolt

Adjustable gas block is required.  

### Note:

If you paid *anything* for access to these files, you have been scammed.
------------------------------------------------------------------------------------------------------------------------------------------

## Print Settings:

Print upright. MOst files are pre orientated.  Use common sense or ask 

Body:
Layer Height: .16 - .20
Walls: 6
Top/Bottom: 8 / 8
Infill: 100% (This worked best for me, your printer may vary.)
Temps: Whatever you use normally for whatever filament.
Supports: Shouldn't be necessary
Build Plate Adhesion: Brim (Not necessary but it helped me. Discretion is key. You know your printer better than I do.)

Clips: Same stuff, yes supports. Aligned on its side.

--------------------------------------------------------------------------------------------------------------------------------------------

## Bill Of Materials + Assembly:

3mm Tap
4mm Tap
Palm sander
10.4mm counter sink bit Amazon sourced
Drill press is preferable
Red Loctite
Soldering iron and M5 insert


Hardware
Substitute button head screws if using carbon fiber side plates
6x M5x10 flat head
8x M5x12 flat head
M3x10 socket head
M3x14 socket head
3/16x5/8 compression spring
2x 3mm standard nuts
M5x40 dowel pin stainless
M5 heatset insert Amazon ASIN B0C4GV8XDX
2x M3 shallow square nut
14x M5 shallow square nut yellow zinc
2x M4x12 button head unless if using Krrawn brace then use flat head
2xM4x40 Barrel nut Amazon ASIN B0C4D4D4D1
4x M4x55 socket head
m3x350 threaded stainless rod
M3x10 barrel nut
1/8x1/2 roll pin
M5x25 socket head for grip screw



---------------------------------------------------------------------------------------------------------------------------------------------------

## Change Log

V1 alpha

V2 Beta

V1 Release

---------------------------------------------------------------------------------------------------------------------------------------------------

## Notes, etc.:

Super huge thanks to DBFirearms, Krrawn, Desert3d, JosephSmith, Dobewan and all the other testers.

----------------------------------------------------------------------------------------------------------------------------------------------------

## License

The Dissident © 2024 by mprtech is licensed under CC BY-NC-SA 4.0. 
To view a copy of this license, visit https://creativecommons.org/licenses/by-nc-sa/4.0/