This is the 3011DS - a 3D-printable 1911 frame that takes AR15 fire control parts and doublestack 1911 magazines.
The 3011DS can be configured as a rifle (with 16" barrels), braced pistol carbine, or as a standalone pistol - or however else you'd like!

For help finishing your build, refer to the '3011DS Build Tutorial' pdf found in this download package, as well as the video you can watch and download here: https://odysee.com/@Ivan's_CAD_Streams:c/3011BuildTutorial:c

Note - this package contains files for frames with work with standard barrels and Para/Clark ramped barrels. Be aware that due to variation in how Para/Clark barrels are made, fitting will usually be required if you use a ramped barrel - this fitting is usually required on the inside chamfer edge on the rails.

Printed Parts List:
	1x 3011DS Frame - 2 variants are as follows:
		Standard Barrel - Straight End: A 3011 frame that is set up to take standard 1911 barrels and has a completely vertical rear pic rail for mounting stocks/optics - for use with optics that have risers/standard AR15 cowitness height optics.
		Ramped Barrel - Straight End: A 3011 frame that is set up to take Clark-Para Ramped 1911 barrels and has a completely vertical rear pic rail for mounting stocks/optics - for use with optics that have risers/standard AR15 cowitness height optics. Note that ramped barrels will usually require fitting of the frame/front rail.
	
	1x AR15 Buffer Tube Adapter (Optional) - 2 variants are as follows:
		 Straight End: an adpater that will fit on your rear pic rail and allow AR15 tubes to be attached, allowing AR15 stocks/braces to be used. Tubes will stick straight out the back with no drop - meaning optics will need to have risers.
		 Dropped End: an adapter that will an adpater that will fit on your rear pic rail and allow AR15 tubes to be attached, allowing AR15 stocks/braces to be used. Tubes will stick down at an angle, meaning optics may not need risers and iron sights can be used.

		Both versions of the AR15 Buffer Tube Adapter can be secured to the frame using three M5x35mm bolts and nuts.
			
	1x 3011 Rail Puller (Optional) - a tool that can be used to pull the rails out of your frame without damaging the rails.


This frame has been tested to work well in eSun PLA+. In any material similar or superior to PLA+, this frame should work as well.

**Note that all STL files are oriented and scaled properly, and changing their scale or orientation may result in your parts not fitting/working properly.**
**Note on orientation - there's a lot of debate about which orientation to print pistol frames in. I've found upright works great for this particular frame when printed in PLA or Zytel. If you print in something that is prone to warp (like ABS), you might want to print it inverted to keep the bulk of the frame close to the heat coming off the bed (which will help discourage warp).
**Note that you MUST follow these print settings in order to get the best possible results - changing nozzle size or layer height may cause you to have to hand fit things!**

My print settings for PLA+ were as follows:

Nozzle: 0.4mm
Layer Height: 0.15mm
Temp: 230/60C
Infill: 100% (You can use 99% infill on Cura to speed up the print time)
Supports: On/full (tree supports are ok) - use a close support interface gap. Your interface gap should not be larger than 0.15mm unless you know what you are doing with your setup.
Cooling fan: 20% normal, 50% on bridges. Off for the first 10 layers. Keep the fan low to prevent warp.
Bed Adhesion: gluestick or hairspray or both

Post processing: If you print your frame upright, you can clean up the rough bottom-facing areas of your print with a soldering iron - after removing supports, take your soldering iron and melt the rough patches on the frame together to make them smooth.

All other settings can/should be left as default or whatever you know works best with your printing setup.

