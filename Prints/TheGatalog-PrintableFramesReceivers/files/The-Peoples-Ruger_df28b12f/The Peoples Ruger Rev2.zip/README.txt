# ThePeoplesRuger
A 3D Printable P95 Frame

by UberClay


## Description
A 3D printable P95 and P95DC frame.  

## Variants
- **P95_OEM_MAG** - Frame that uses OEM Mags
- **P95_GLONK_MAG** - Frame that uses Glonk Mags
- **CT OEM P95** - Frame that uses OEM Mags (For slides made in CT)
- **CT Glonk P95** - Frame that uses Glonk Mags (For slides made in CT)


## Materials Required
You will need a set of each below for each [x] you make.
- x1 **Parts Kit** - A P95 or P95DC Parts Kit
- x1 **P-SERIES RAILS** - Get them here: https://riptiderails.com/rugerpseries
- x1 **M2 12mm in length
- x1 **M2 nut
- x1 **5/64" or 2mm black oxide drill bit
- x1 **#5 drill bit (oem mag frame only)
- x1 **Glonk 17 or larger mag**
- x1 **Glonk mag spring**
	OR
- x1 **OEM Ruger P95 mag**


## Instructions
1. Print a the frame rails up at a 30 degree angle.  4 or more walls, 100% infill, 220/60c or your preferred print settings for PLA +
2. Print the mag catch if printing the Glonk mag version
4. Install rails
3. Assemble

See Assembly Guide PDF for detailed instructions

Credits
ChairmanWon
Unseenkiller
Riptide Rails
MPRTech
UberPoor
The DDRC Beta Team
The Gatalog


## License
no images, models, documents or other files licensed for commercial sale, use, exchange, subscription, download, or transfer, copyright 2024