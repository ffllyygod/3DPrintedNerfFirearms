The Moore Dakka

A Printable Smith and Wesson M&P45

You need:
	M&P 45 Parts Kit
	3D Printer
	Mag Catch Spring(maybe if your kit is without one.  I used Glock spring)

Print rails down if you can, otherwise your preferred print orientation.
Print settings:
	220/60
	4 or more walls (I use 8 its overkill)
	99%+ infill

Print the frame and remove any supports.  test fit rear sear block and locking block. Also you want to check the takedown lever area for trash as it sits flush in the locking block.  I usually have to check this and it must be free of any debris.

I usually install the rear sear first.  then the locking block and trigger assembly
install the catch spring and catch
install takedown lever and pivot the rear sear lever down
install slide and retract and lock in the LRBHO position
flip rear sear lever up and turn takedown lever 90 degrees into it's normal position
unlock slide and test function.  trigger should reset when slide is actuated


