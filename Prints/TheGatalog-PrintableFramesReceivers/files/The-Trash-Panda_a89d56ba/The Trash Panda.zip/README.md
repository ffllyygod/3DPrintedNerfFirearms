# Trash Panda

The Trash Panda is a 5.56/300BLK 3D printed lever action rifle, so you can live out your space cowboy fantasies without breaking the bank. Depending on the standard
metric hardware hardware you already own, the cost ranges from $250 to $400.

by AvieAtrix



## Variants

* Normal - In 5.56 or 300BLK, uses a slimmer receiver and handguard with MLOK attachments
* Integrally Suppressed - Coming Soon



## Materials Required

You will need a set of each below.

* x1 AR-15 bolt carrier group
* x1 AR-15 fire control group
* x1 AR-15 Pistol Grip Bolt

OR

   x1 M5x25 bolt and x1 M5x8 heatset insert

* x1 AR-15 barrel, 14-16" length
* x1 compatible low-profile gas block
* x2 M3x6 heatset inserts
* x2 carbon fiber/x4 steel arms from SendCutSend or similar

https://cart.sendcutsend.com/rwfjml8mctdf

OR

https://cart.sendcutsend.com/joy1dm0j8lzl

* x1 M3x25 steel dowel
* x8 M3x35 bolts
* x1 1/2" worm-drive hose clamp
* x2 0.25"OD x 1.375"L extension springs
* x1 Magpul M3 PMag internals
* x2 M3x20 bolts
* x2 M3x4x4 same-size shoulder screws
* x2 5/32"x1.5" steel dowels
* x1 M4x8 set screw
* Polymaker PLA Pro or similar
* Polymaker PA6-CF or similar
  --Optional--
* x1 10mmx270mm carbon fiber tube
* x1 M3x16 bolt
* x2 M5x20 and x2 M5x8 heatsets for the buttpad.



## Instructions

See the included Trash Panda Assembly Guide.pdf for detailed instructions on assembly and operation



## Change Log

* v1.4: Initial release



## License

Creative Commons Attribution NonCommercial Share-Alike 4.0
https://creativecommons.org/licenses/by-nc-sa/4.0/

