For Printed mags, print your mag body, follower, baseplate and lock. Install with glock 33 round magazine spring or equivalent.

PLA+ or better. All parts have been oriented correctly for printing in the .stl file. 



NOTE: if you have a metal sten mag, print the Sten latch and follow the instructions
below to glue it into your sten magazine. 

1. File the rectangle on the back of the latch until it fits into the rectangle opening on your Sten magazine.  
2. Test fit the mag into the assembled firearm.  As long as it seems to fit ok and the mag catch closes remove the 
mag and clean off any residue and oil off the mag.  
3. Apply JBweld clear weld to the backside of the sten latch.  Install the latch onto the mag and 
using a C clamp, clamp the assembly and let dry overnight.  After drying insert the mag.  
The bolt will most likely just touch the mag lips and bind.  
4. Remove the mag and file the underside of the sten latch where it interfaces with the mag catch.  It will not take 
much removal at least on the 6 different sten mags I set up.  When its right the mag 
catch will lock and the bolt will not bind on the lips.  It should feed and be good to
go.

