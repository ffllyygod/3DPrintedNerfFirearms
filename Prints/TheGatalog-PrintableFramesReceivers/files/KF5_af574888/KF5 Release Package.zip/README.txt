The KF5

	The KF5 is a 3D printable MP5 receiver set. It is compatible with OEM HK parts, PTR parts, RCM parts, and most of the other clone or US-made MP5 parts.
	Thanks to it's design, the KF5 is a cost-effective way to get MP5 performance at a discount - because many of the complex and expensive parts of the MP5 are replaced with printed or AR15 parts, the price to complete a build is rather cheap.

	At the core of the KF5's design is its press-fit clambshell barrel mount - a simple, effective way to securely and rigidly attach the barrel and trunnion to the receiver.


Printed Parts Checklist:

	(Note that the "Remixed Parts" folder has some variants of these parts, if you'd like to change the look of your build.)
	
	Upper Receiver (Variants for use with MP5 and MP5k bolt carriers)
	Lower Receiver (Variants for: high web cut, binary compatible, and inclusion of a printed paddle-style mag release in addition to the standard button release)
	Endcap (Variants for use with MP5 and MP5k bolt carriers)
	Handguard/Cocking Tube (Note that while k-size carriers are supported by this build, k-length barrels aren't exactly supported - the muzzle of a k-length barrel will not clear this handguard unless you 	use a linear compensator)
	Barrel Mount Left (Variants for use with PTR and RCM bolt carriers)
	Barrel Mount Right (Variants for use with PTR and RCM bolt carriers)
	Charging Handle (Two variants exist - I recommend you use Type 2, as it is much stronger)
	Charging Rod (Variants for use with MP5 and MP5k bolt carriers)
	
Hardware Checklist:
	
	Refer to the "Shopping List" section of the build tutorial pdf.


General Print Settings:

	This receiver has been tested to work well in eSun PLA+. In any material similar or superior to PLA+, this receiver should work as well.

**Note that all STL files are oriented and scaled properly, and changing their scale or orientation may result in your parts not fitting/working properly. Especially with parts like the barrel mount and receivers, orientation is important!**
**Some cooling settings/filaments may cause some parts to warp slightly. This is generally acceptable, and will not negatively effect function. If warping seems extreme, reduce cooling settings/print speed.**
**Note that you should follow these print settings in order to get the best possible results - changing nozzle size or layer height may cause you to have to hand fit things!**

My print settings for PLA+ were as follows:

	Walls: 8 walls recommended to ensure strength of the mating flanges.
	Nozzle: 0.4mm
	Layer Height: 0.15mm
	Temp: 230/60C
	Infill: Ideally 100% - though if you use 8 walls you can use much lower infill - this has been tested at 20% infill and 8 walls, if you are trying to set a low weight record.
	Supports: On/full (tree supports are ok)
	Cooling fan: 20% normal, 50% on bridges. Off for the first 20 layers. Keep the fan low to prevent warp.
	Bed Adhesion: gluestick or hairspray - since the big sections of this print have small footprints on the bed, using plenty of gluestick or hairspray is recommended.

	All other settings can/should be left as default or whatever you know works best with your printing setup.

