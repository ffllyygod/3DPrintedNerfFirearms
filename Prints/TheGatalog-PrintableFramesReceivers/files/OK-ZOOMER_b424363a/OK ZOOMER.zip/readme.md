# OK ZOOMER.
A 3dprinted Ruger SR45 frame that takes Glock 21 magazines.

by UBERCLAY 
seed frame by Ghostgunsrspooky


## Description
Printable frame for the Ruger SR45


## Variants
	There are 3 variants of the frame.  1. A traditional frame, 2. A traditional frame with printable grips
	
## Materials Required
PLA+ or other suitable material
Ruger SR45 parts kit
Glock 21 Magazine
Glock magazine spring
you need an SR9 rail from Riptide or similiar
https://riptiderails.com/sr9-diy-rail-kit-aluminum


## Instructions
Printing orientation should be rails down if you can.  Otherwise rails up.

Use best judgement for supports


Assembly Summary (Detailed instructions in the assembly guide)

REMOVE THE MAG OUT SAFETY
	Using a small pin punch release the backplate from the slide
	pull the firing pin plunger out enough to remove the mag out safety
	replace the backplate

install the trigger onto the locking block
install the locking block and rear sear assembly
install the rail

