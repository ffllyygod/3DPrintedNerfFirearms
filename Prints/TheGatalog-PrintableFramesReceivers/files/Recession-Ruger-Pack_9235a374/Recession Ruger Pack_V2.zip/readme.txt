The 3089 V2 readme

**credit to Ivan for the original 3011 and Chairmanwon for the original P95 Beta, from which I defiled and created this unholy alliance**

*Credit to Kukitan for the removable rail 2.0 idea, remix, and documents work

*Credit to Internetpizza for his remix frame

*Credit to DB for his remix frame

*Credit to Ghostgunsrspooky for the Dust Cover and dust cover handle

*Credit to BattoIsOutto for charging handles

**and a special Thank You to the Beta Room and the Deterrence Dispensed community.**

***3-11-23 3089 frame update: moved the FCG slightly to help with widening the tolerance for hammer reset.  Also some aesthetic improvements.


You will need to

print the frame		(note renders for position)
print the front rail	(note renders for position)
Print the rear rail	(note renders for position)
an AR FCG
P89 Slide, Barrel, Spring and guide rod
P89 ejector and .125 x 1.125 roll pin
P89 Slide lock lever
2) M3x10 screws and nuts
1) or 2) M3x30 screws and nuts

Chairmanwon's P95 mag release or the included 'Chonky' version or extended version
Glock mag release spring
Glock mag

*important first step
Take the Firing Pin Block out of the slide
	1. Note the set screw on top of the rear sight
	2. remove
	3. drive the rear sight out to the right or left
	4. flip the slide safety to 'on'
	5. pull the block straight up and out
	6. replace rear sight
	7. replace set screw

The slide safety will still function.  as will the FCG safety.

Print frame, front rail, and rear rail, and clean supports
Install the Front Rail using 2) M3x10 screws and nuts.  THE SCREWS CANNOT BE ABOVE THE NUTS.  IF THEY PROTRUDE ABOVE THE NUTS USE WASHERS.
Install the Rear Rail with the rear M3x30 screw ONLY.  If you want to use the front screw, (optional) you must install the slide first.  (this screw captures the ejector if you so choose and keeps it in the up position)
Install Ejector, use .125 x 1.125 roll pin (you may need to enlarge ejector pin holes in ejector)
Install AR FCG
Install Ejector, use .125 x 1.125 roll pin (you may need to enlarge ejector pin holes in ejector)
Install slide, barrel, spring, and guide rod.  Modify slide lock if desired (more on this later) and install
(Install second screw in Rear Rail) with ejector in the up position) **optional
P95 notes:
Print the P95 rear block
This design will work with the P95, but the ejector (at this time) must be mounted using a 8-32 machine screw and 2 spacers.  
Open up the roll pin hole for the screw and thread the screw through the frame, then spacer, ejector, and another spacer.
Once you do this, the frame is dedicated P95
P85 notes:
OEM P85 ejector will NOT work in this design.  Go buy a P89 ejector.  Link is in the assembly guide





