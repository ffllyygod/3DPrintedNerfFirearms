

Print included mag catch and saftey for this build. They are required and differ from the main build. 
Also front rail block now needs to be mounted with M3x20mm screws (can be longer but make sure ends of screws dont stick too far out of the front rail block), not the M3x10mm used in the main build.

1/27/23   -   Kukitan

-Moved FCHG Forward 1 mm to allow better reset of hammer and catch on disconnector.
-Cut away 1mm in front of first rail block to allow slide to cycle further back to aid in consitenmcy of hammer reset.
-Added back recessed holes to front rail block in 1 piece frame. USE m3x20mm again!!!!!!!!
-Only included 1 piece frame in this release. Want it to work first, then will make split frame.

1/12/23   -   Kukitan

-Filled recessed holes back in, wont work. OOPS!  Need to use M3x22mm or larger screw for front to rails.
-Lowered pistol grip magwell catch location down 4mm as mags sat too high.

1/10/23   -   UberClay and Kukitan

-Opened up shroud so the slide properly cycles
-Filled in accent holes so that they print with thickness, as opposed to becoming windows (Those looked cool though, will bring em back as a seperate stl)

-Mag catch moved up to allow for proper magazine function
	-Shortened magwell slightlyt because magazines sit higher up
-Provided a combined nose+body stl and step
-Added countersinks to front and rear rail block screw holes
-Front rail block now requires M3x20mm screws x2  instead of M3x10mm
-Guide rod trough opened up a bit so allow spring to cycle more freely
