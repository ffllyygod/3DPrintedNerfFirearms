from DB:

Regarding the mag release, it may need to be drilled out. But basically it functions like a CZ mag release. So you insert the spring and detent from the FP block you take out of the slide. Stick those in the hole of the mag release. Then slide a piece of 2mm rod into the frame to retain the mag release and press on the plunger. It worked really well for me.

The grip takes a M6 nut and M6x25 bolt