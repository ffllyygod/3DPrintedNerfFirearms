MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMWNX0OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOKNWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMW0d:'..                                    ..,:oONMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMWO:.                                               'l0WMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMM0c.                                                   .cKMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMK;       .';ccccccccccccccccccccccccccccccccc:''.        'xNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMWo      .c0NWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWNNKx;        :0WMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMM0'      lNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNd'       .oXMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMk.     .dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMXl.       ;kNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMk.      dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWO;.      .lKNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNWWMMMMMMMMMMMMMMM
MMMMMMMMMk.      dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNx.       .'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''';lx0NMMMMMMMMMMM
MMMMMMMMMk.      dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWKl.                                                                                                                     .,xNMMMMMMMMM
MMMMMMMMMk.      dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWO;                                                                                                                       ,OWMMMMMMM
MMMMMMMMMk.      dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNd,...............................................................................................................       .xWMMMMMM
MMMMMMMMMk.      dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNX0l.      ,0MMMMMM
MMMMMMMMMk.      dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNl       oWMMMMM
MMMMMMMMMk.      dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWo       cNMMMMM
MMMMMMMMMk.      dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWo       cNMMMMM
MMMMMMMMMk.      dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWo       cNMMMMM
MMMMMMMMMk.      dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWo       cNMMMMM
MMMMMMMMMk.      dMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWo       cNMMMMM
MMMMMMMMMk.      c00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000:       cNMMMMM
MMMMMMMMMk.       .......................................................................................................................................................................        cNMMMMM
MMMMMMMMMk.                                                                                                                                                                                      cNMMMMM
MMMMMMMMMk.                                                                                                                                                                                      cNMMMMM
MMMMMMMMMk.       ........................................................................................................................................................................       cNMMMMM
MMMMMMMMMk.      'kXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXKx:,lOXXXXXXXXXXXXXXX0d;;dKXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXO'      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMXo.   'xNMMMMMMMMMMMWO;   .lKMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMXc  .,. .lXMMMMMMMMMNd.  ,.  ;0MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNl  .kNx.  lNMMMMMMMWd. .oX0,  :XMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMO. .oWMWd. .xWWWWWWWO'  lNMWx. .xWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWo  'OMMMK,  .;;,,,,;'  .OMMMK;  cNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWMMMMMMMMMMMMMMMMMMMMMWl  '0MMMX:             ,KMMMX;  :XMMMMMMMMMMMMMMMMMMMMMWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNOoc:l0WMMMMMMMMMMMMMMMMMMWo  '0MMMX;             '0MMMX;  cNMMMMMMMMMMMMMMMMMMM0l::oONMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNx;.    lNMMMMMMMMMMMMMMMMMMMk. .xWMNd.             .lXMMO. .dWMMMMMMMMMMMMMMMMMMWo.    ,xXMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNk;  ..  .dWMMMMMMMMMMMMMMMMMMMX:  ;kx;.               .,dkc  '0MMMMMMMMMMMMMMMMMMMMx.  ..  ,xNMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMW0:. .ckc  .xMMMMMMMMMMMMMMMMMMMMWk.   .lxkxc.       .;dkkl'.  .oWMMMMMMMMMMMMMMMMMMMMk.  ;kl.  ;OWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNd.  ;OWN:   oWMMMMMMMMMMMMMMMMMMMMNl  .xWMMMWo.      cNMMMMO.  :KMMMMMMMMMMMMMMMMMMMMWd.  ,KW0:. .oXMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWK:  .dXMMN:   ;KMMMMMMMMMMMMMMMMMMMMMk. .lXMMMXl.      :KWMMNx. .dWMMMMMMMMMMMMMMMMMMMMX:   ,KMMNx'  ;0WMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMWO,  ,OWMMMNl   .oNMMMMMMMMMMMMMMMMMMMMK;   'cllxOkkkkkkkOkoll;.  '0MMMMMMMMMMMMMMMMMMMMWd.   ;XMMMMK:  'kWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMWk.  cKMMMMMWd.   .oXMMMMMMMMMMMMMMMMMMMWk.      'xNMMMMMNO;      .dWMMMMMMMMMMMMMMMMMMMNd.    lNMMMMMXl. .xWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMWk.  lXMMMMMMMO. ..  ;kNMMMMMMMMMMMMMMMMMMWO,       ,okOkd;.      .xNMMMMMMMMMMMMMMMMMMNO:  .. .xWMMMMMMNd. .xWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMO'  cXMMMMMMMMX: 'l;   ,oOXWMMMMMMMMMMMMMMMMXo.                 .c0WMMMMMMMMMMMMMMMWN0d,.  'o, ,0MMMMMMMMNo. .kWMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMK;  :KMMMMMMMMMWx..dKo.   ..;ldk0KXXNNNXXXK0kdl'                 .cdkOKXXNNNNXXK0Oxl:'.   .c0k. lNMMMMMMMMMNl  ,0MMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMNo  'OMMMMMMMMMMMK; ,0WO:.       .....''....                           .....'.....        ,kNX: '0MMMMMMMMMMMK;  lNMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMO. .dWMMMMMMMMMMMWk. cXMNk,                                                             'dXMNo..dWMMMMMMMMMMMWk. .kWMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMNc  ;KMMMMMMMMMMMMMNo .lNMMXd'                                                         .oKWMWx. :XMMMMMMMMMMMMMNc  :XMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMO. .dWMMMMMMMMMMMMMMX: .oNMMMXd.                                                     .lKWMMWk. ,0MMMMMMMMMMMMMMMk. .kMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMWo  ,0MMMMMMMMMMMMMMMMO' .xWMMMWKl.                                                 .c0WMMMWO' .xWMMMMMMMMMMMMMMMX:  lNMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMX;  cNMMMMMMMMMMMMMMMMWx. .kWMMMMW0c.                                              ;OWMMMMM0,  oNMMMMMMMMMMMMMMMMWd. ,KMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMO' .dWMMMMMMMMMMMMMMMMMNl  ;KMMMMMMNk,                                           'xNMMMMMMXc  ;KMMMMMMMMMMMMMMMMMMO. .OMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMx. .OMMMMMMMMMMMMMMMMMMM0,  oNMMMMMMMXo.                                       .cKWMMMMMMWx. .kMMMMMMMMMMMMMMMMMMMK, .dWMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMWo  ,KMMMMMMMMMMMMMMMMMMMWd. '0MMMMMMMMWO,                                     'xNMMMMMMMMX:  cNMMMMMMMMMMMMMMMMMMMX:  lWMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMWl  ;KMMMMMMMMMMMMMMMMMMMMK, .dWMMMMMMMMMXc.                                  ;0WMMMMMMMMMk. .OMMMMMMMMMMMMMMMMMMMMNc  cNMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMWl  :XMMMMMMMMMMMMMMMMMMMMNo  :XMMMMMMMMMMNd.                               .lXMMMMMMMMMMNl  :XMMMMMMMMMMMMMMMMMMMMWo  :NMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMWl  cNMMMMMMMMMMMMMMMMMMMMMk. '0MMMMMMMMMMMWx.                             .oNMMMMMMMMMMMX; .dWMMMMMMMMMMMMMMMMMMMMWo  :NMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMWl  cNMMMMMMMMMMMMMMMMMMMMMK, .kMMMMMMMMMMMMWx.                           .oNMMMMMMMMMMMM0' .OMMMMMMMMMMMMMMMMMMMMMWo  :NMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMWl  :XMMMMMMMMMMMMMMMMMMMMMX: .dMMMMMMMMMMMMMWx.                         .oNMMMMMMMMMMMMMO. ,KMMMMMMMMMMMMMMMMMMMMMNl  cNMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMWo  ,KMMMMMMMMMMMMMMMMMMMMMWl  oWMMMMMMMMMMMMMNd.                        lXMMMMMMMMMMMMMMx. ;XMMMMMMMMMMMMMMMMMMMMMNc  cNMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMWd. ,0MMMMMMMMMMMMMMMMMMMMMWl  lNMMMMMMMMMMMMMMNc                       ;KMMMMMMMMMMMMMMWd. ;XMMMMMMMMMMMMMMMMMMMMMX:  lWMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMWx. .OMMMMMWX0kxxxk0NWMMMMMX:  oWMMMMMMMMMMMMMMMK,                     .OMMMMMMMMMMMMMMMMx. ,KMMMMMWNKOxxxkOXNMMMMMK, .dWMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMO. .xWMN0o;..     .'cxXMMM0, .dMMMMMMMMMMMMMMMMWx.                   .oNMMMMMMMMMMMMMMMMO. .OMMMNOc'.      .,lONMMO. .kMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMK,  l0d,.  ':ldddl;.  'xNWx. .kMMMMMMMMMMMMMMMMMXc                   ;KMMMMMMMMMMMMMMMMM0'  oWNk;  .,ldddo:'   'o0d. '0MMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMX:  ..  .ckXWMMMMMW0l.  :x;  '0MMWWNXKKKXNWMMMMMMO.                 .xWMMMMMWNXKKKKXNWMMX;  ,xl. .c0WMMMMMWNOl.  ..  ;XMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMWo    .oKWMMMMMMMMMMW0;  .   :OOo:,......';cdOXWMNc                 ;KMWNOdc;'......,:ok0c   .  ,OWMMMMMMMMMMWKo.    lNMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMk. .:0WMMMMMMMMMMMMMMK:     ..   .,;:::;'.   .:xKx.               .oKkc'   .';:::;,.   ..     ;KMMMMMMMMMMMMMMWKc. .xWMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMK;.xNMMMMMMMMMMMMMMMMMK;     .;dOXWWWMMWNKOo;.  .'.                '.  .;okKNWWMMWWXOd:.     ,0MMMMMMMMMMMMMMMMMNx',0MMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMNO0WMMMMMMMMMMMMMMMMMMWk.  .o0WMMMMMMMMMMMMMWKx;.                   .;dKWMMMMMMMMMMMMMWKo'  .xWMMMMMMMMMMMMMMMMMMW0ONMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMk.      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNl'oKWMMMMMMMMMMMMMMMMMMW0l.               .cONMMMMMMMMMMMMMMMMMMWXd'cXMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMK,      cNMMMMM
MMMMMMMMMO'      ,KMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMXKWMMMMMMMMMMMMMMMMMMMMMMWKl.           .c0WMMMMMMMMMMMMMMMMMMMMMMWXXWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMO.      lWMMMMM
MMMMMMMMMNl      .lKWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWXxc,.....':dKWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMNk,      '0MMMMMM
MMMMMMMMMM0'       .;coooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooc:::::coooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooool:'.      .oNMMMMMM
MMMMMMMMMMWO;                                                                                                                                                                                 .oNMMMMMMM
MMMMMMMMMMMMNx,                                                                                                                                                                             .lKWMMMMMMMM
MMMMMMMMMMMMMMNkl,..                                                                                                                                                                    .':dKWMMMMMMMMMM
MMMMMMMMMMMMMMMMMWXKkxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx0KNWMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
|_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-=-_-|
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Recession Ruger P89 Charging Handle and Rear Sight Combo V1.0 by Batto_Is_Outto!

Hello, thank you for downloading my sight.

Settings I used with sucess.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
|､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒ ､., (㇏( •̀ᵥᵥ•́)ノ)|
|______________________________________________________________________________________________________________________________________________________________________________________________________|
|Wall count: 6                                                                                                                                                                                          |
|                                                                                                                                                                                                      |
|Infill %: 40                                                                                                                                                                                           |                                                                                                                                                     |
|                                                                                                                                                                                                      |
|Infill type: Gyroid                                                                                                                                                                                    |
|                                                                                                                                                                                                      |
|Supports: Yes, touching buildplate. (supports may need tweaking!)                                                                                                                                      |
|                                                                                                                                                                                                      |
|Orientation: Flatside of the dovetail facing the build plate. (Shown in render photos)                                                                                                                 |                                                                                                      |
|                                                                                                                                                                                                      |
|Temperature: Use what ever temp settings you used to print the frame, I used Polymaker Polylite Pro Pla which likes to run hot on my machines. So I was running 245-255c                               |
|                                                                                                                                                                                                      |
|Speed: 55                                                                                                                                                                                              |
|                                                                                                                                                                                                      |
|Fan: 100%                                                                                                                                                                                              |
|                                                                                                                                                                                                      |
|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
|､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒ ､., (㇏( •̀ᵥᵥ•́)ノ)|
|______________________________________________________________________________________________________________________________________________________________________________________________________|

THINGS TO KEEP IN MIND!

The dovetail on this sight combo is sized to 14.5mm compared to the stock sight's 13.6mm. This is oversized on purpose to allow for a snug fitment as well as to account for PLA shrinkage. On my printer 
I was getting 14mm after prints. The large size also means we don't-- in theory-- need the set screw that is present on the original sight. (The Purpose of this screw is to raise the rear sight into
 the dovetail to lock it into place.)

However, with that being said you can't just ram into the dovetail and hope for the best.  There is a method I found to getting the sight in.

HOW TO INSTALL THE SIGHT!

<<Remove the original sight if you haven't~~ also remove that pesky firing pin block~~>>

Line up the sight combo to the dovetail slot on the slide.  The extended overhang faces the rear of the gun as shown in the photos.

Carefully line the rear dovetail up to the slot.( YOU DO NOT want this jumping out otherwise you will ruin the print!)

Insert the sight into the slot BY HAND. Wiggle it into place making sure that both of the dovetails on the sight are actually going under the ones on the slide.

You will reach a point where it will no longer move, you will see a thin line of PLA being peeled from the front sight dovetail.<<THIS IS GOOD>>

Use somethig to tap the sight in. I used a screwdriver handle. I advise AGAINST using a metal hammer and treating it like a nail. DO NOT treat it like it owes you money otherwise it will BREAK.

Watch carefully as you tap it in. The thin line of pla will continue to strip the deeper you go in. Removing this strip peroidically actually speeds up the process.

Hammer it until the center slot is in align with the firing pin hole.

Tadaaah you're now a gunsmith!

､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒ ､., (㇏( •̀ᵥᵥ•́)ノ)

Notes:

With supports there will be one in the center of the slot. You can knock that out with what ever will fit.

The two holes on the sight beside the slot are sized to allow 1.75, Filament to be inserted. If you plan on doing so, check to make sure the holes are clean, a paperclip or even the glock magazine catch 
will work to clean them out.

For filament I suggest Glow in the dark PLA. Because it's tacticool, and gives you very cheap night sights. 


､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒､., ⌒ ､., ⌒ ､., ⌒ ､., (㇏( •̀ᵥᵥ•́)ノ)




