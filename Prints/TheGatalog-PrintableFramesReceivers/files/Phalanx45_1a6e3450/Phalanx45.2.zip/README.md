
Smith and Wesson Shield 45 compatible frame

by Optimal_fail

## Variants
- Shield 45 - no texture = Plain frame with no textures.
- Shield 45 - factory style texture by uberclay = Factory style textures by Uberclay.

## Materials Required
Shield 45 parts kit

## Instructions
1. Print in either rails down or rails up.
2. Clean up supports and frame in general.
3. Assemble.
4. Enjoy.

## Thanks
Thanks to Uberclay for helping this one cross the finish line, as well as making an awesome texture for it.
