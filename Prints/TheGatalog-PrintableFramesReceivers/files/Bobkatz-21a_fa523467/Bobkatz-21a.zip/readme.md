# BobKatz 21a
A 3dprinted beretta 21a 

#Author
gerald.katz
credits to:
	tjb556 for the hammer spring assembly jig
	mountainman1776 for the grip models
	freeman1337 for his stipple remixs
	all members who helped troubleshoot in the BETA
## Description
The Bobkatz is an entirely 3dprinted Beretta 21a that uses nothing but the OEM parts kit.  There are grips, and a hammer spring compressor tool included in the file pack.
	The grips are blank and ready for stipple.
	The hammer spring jig / compressor has a PDF on how to use it.
	Freeman1337 has remix'd a frame and grips with stipple


## Materials Required

- x1 **Parts Kit** - Source a parts kit of your preference. 25acp or 22lr use the same frame. In the file pack is a parts list that outlines what parts are needed.

## Instructions
Print settings:
-	.12 layer height
	-	.2 can cause issues but .16 has mostly been tested to be okay.
-	100% infill
-	7-10 walls
-	magwell on bed
-   Tree supports are helpful but tuned normal supports also work well.
-	Inland or Esun PLA+ preferred but PLA has been used.  Longevity is not expected out of just PLA frames. YMMV.


disassembly:
https://odysee.com/gF5LgjfVeuE:5
assembly:
https://odysee.com/GPz-PEHUosU:6
triggerjob:
https://odysee.com/0RXHUjuCjgc:2




Almost all parts install in a OEM fashion.  These videos will outline most if not all of those parts.  Anything that strays is documented below.

-Do not pull the trigger for DA without grips on the side.  The grips hold the bar from pulling away and damaging the bar / hammer surfaces.-


1 Post Processing:
Remove all supports.
Run a m3 bolt through the grip screws to make it easier when putting the grips on.  Heat up the end of the bolts slightly with a lighter to start the thread. Countersink is to avoid the plastic from being pulled up and interfering with the grip.
Cleanup bottom and top surfaces of each hole through the frame like the trigger bar and sear holes.
Make sure the hole under the hammer spring base is clear of supports otherwise your hammer might not cock back fully.
Clear each pin hole with a proper sized drill bit.



2 hammerspring:
Refer to photos in instructions steps 1-4.
	1. Lay it into the magwell on its side with the top of spring near the front of the mag (near the trigger section) and the base above the round clearance hole.
	2. Use the clearance hole to rotate the base with the notch facing forward.
	3. After its in the correct orientation youll need to get the top of the bar under where the hammer will be.
	4. Once its lined up just seat the base of the hammer into its slot and make sure it sits flat.

3 sear:
Lay the frame onto its left side and lay the sear on its flat side into the magwell from the top (with the 'arm' toward the rear of the gun)  Line up the arm up into the gap push it downward out of the side of the frame. As you push on the arm the sear should twist into its position. Line up the pinhole and insert pin.  Make sure the spring is installed on the pin before inserting. Don't install the sear spring until after the hammer.

4 Slide:
Install the slide to the frame.  Use slide to push through the underhang on the rails. It is normal to be difficult but results in close tolerances. If you're confident enough to file the rails go ahead.  This will wear into smooth after a shot or two, or manual cycles. 


5 Hammer:
Place hammer roughly into its position.  Line up the spring bar into the slot in the hammer.  Rotate the hammer forward until the pin lines up, making sure the sear is forward to not catch it.  Install pin and bring hammer back.  If the spring bar didn't seat into hammer correctly push it downward  forward while pulling the hammer back It will click in.

6 Ejector:
The square hole needs filed to fit (this is intentional).  measure the outside of the rails  to be roughly ~12.7mm (as long as the slide moves easily) Insert the ejector and see if it bows the frame outward.  try to keep it under ~12.8 otherwise the slide will bind on the bowed plastic.
Otherwise ejector installs as expected. Send the roll pins through all four holes to make sure you don't blow them out when actually installing.



7 Recoil bars:
Fit them onto the pegs prior to installing recoil springs to make your life easier.  The bar will need mounted to the peg and rotated to compress the recoil spring and locked into the frame.   

8 Pins:
The two 3mm pins in the trigger and barrel pin spring are longer than the frame.  They are to stick out to the left side to interface with the barrel lever.  Trigger is mostly flush on the right side and the other is close.

9 Trigger guard:
The barrel should be fully installed and tipped up.  Insert the front of the guard into the slot behind the barrel and compress it to meet the hole in the frame.  The hole is purposely much larger to account for supports that couldn't be easily removed.  It will not seat very deep into it. 

#Notes and other general information
Ammo
-	Use 1200+ FPS 22lr or more unless running a can.
-	25acp seems to run fine.
Lubrication
-	Lubricate all the things.
-	A thicker lube also helps since it stays around.
Issues
-Failure to ejects happen often if the chamber isnt clean. Suggestion is to clean the gun often.
-Do not pull the trigger with a double action pull if the grip is off. It will damage your hammer and trigger bar.
-Your hammer spring may come not assembled. Refer to the extras section for an install jig.
-Do not rack the slide with the grips off.  This will result in parts being launched.


## Change Log

- v1.0 Release file
    * renamed from the BETA 2.3 file

## License
GPL v3.1 - resulting prints may not be sold for commercial purposes or financial gain.
