# Recession Ruger R2
Printable frame for the Ruger P89

by Unseenkiller

## Description
The Recession Ruger R2 is a printable frame for the Ruger P89 that utilizes a AR FCG and feeds from a Glock Magazine

## Materials Required
You will need a set of each below for each [x] you make.
Stock (short)					Function
- x2 **M5-35 SHCS**				Pic Rail mount
- x2 **M5 Nut**					Pic Rail mount
- x2 **M3-20 SHCS**				Stock or Brace pad
- x2 **M3 Nut**					Stock or Brace pad
- x2 **#8-32 Threaded Rod - 220 to 225mm**	Threaded Rod compression
- x4 **#8-32 Nut**				Threaded Rod compression
		
Stock (long)					Function
- x2 **M5-35 SHCS**				Pic Rail mount
- x2 **M5 Nut**					Pic Rail mount
- x2 **M3-20 SHCS**				Stock or Brace pad
- x2 **M3 Nut**					Stock or Brace pad
- x2 **#8-32 Threaded Rod - 315 to 322mm**	Threaded Rod compression
- x4 **#8-32 Nut**				Threaded Rod compression
		
Frame						Function
- x1 **M5-35 SHCS**				Front Rail
- x1 **M5-25 SHCS**				Pistol Grip
- x2 **M5 Nut**					Front Rail, Pistol Grip
- x1 **M3-30 SHCS**				Rear Rail
- x2 **M3-20 SHCS**				Mag Release Left Button (optional), Mag Release Right Paddle (optional)
- x1 **M3-10 SHCS**				Front Rail
- x4 **M3 Nut**					Front Rail, Mag Release Left Button (optional), Mag Release Right Paddle (optional), Rear Rail
- x1 **M2-35 SHCS**				Ejector
- x1 **M2 Nut**					Ejector
- x1 **Glock Magazine Spring Bar**		Mag Release
- x1 **AR-15 FCG**				Fire Control Group (full, including safety selector, springs, detents and pins)
- x1 **Ruger P89 Parts Kit**			Slide (complete), barrel, recoil spring, guide rod, ejector
		
Magazine (27rd)					Function
- x1 **Glock 17rd Magazine Spring**		Follower spring for printed mag when using printable spacer
		
Magazine (35rd)					Function
- x1 **Glock 33rd Magazine Spring**		Follower spring for printed mag
		
Foregrip					Function
- x1 **M5-30 SHCS**				Grip pic rail attachment
- x1 **M5 Nut**					Grip pic rail attachment

## Instructions
 --- Printing --- 
It is recommended that all parts be printed with 8 walls, 100% infill, and using normal supports. Please refer to the Print Orientation for placement but be sure to print the sleeves for the threaded rod in the stock one at a time, otherwise they are likely to fall! 

 --- Install --- 
1.	Frame
	a.	FCG
		i.	Install trigger with mil-spec pin and trigger spring.
		ii.	Install hammer with mil-spec pin and hammer spring.
			1.	A few of the beta testers have seen a failure to reset the AR-15 hammer due to hammer spring strength, this can be addressed by 				flipping the hammer spring orientation or using the blue (low power) spring, this is not required – do your own testing.
		iii.	Install AR-15 Mil Spec safety selector, safety selector detent, and detent spring.
		iv.	Insert M5 nut into grip cavity.
		v.	Install pistol grip.
		vi.	Use M5-25 SHCS to install pistol grip.

	b.	Magazine Release Cavity
		i.	Insert ejector into cavity.
		ii.	Install Ruger P89 ejector with M2-35 SHCS and M2 nut into rear magwell cavity (tooth should be facing forward).
		iii.	Insert Glock magazine spring bar for magazine release.
			1.	OPTIONAL: For modular mag release, insert M3 nut into printed magazine release.
		iv.	Insert printed magazine release, seat magazine release spring bar into release cavity.
			1.	OPTIONAL: Install left side buttons using M3-20 SHCS.
			2.	OPTIONAL: Seat right side release paddle.
			3.	OPTIONAL: Complete installation with M3 nut and M3-20 SHCS bolt through release paddle.

	c.	Ruger actioning hardware
		i.	Insert front rail into cavity.
		1.	Fine / High grit sanding or polishing of rails not required but suggested.
		ii.	Secure front rail with M3-10 SHCS and M3 nut (underside only for now).
		iii.	Insert rear rail into cavity.
			1.	Fine / High grit sanding or polishing of rails not required but suggested.
		iv.	Secure rear rail with M3-30 bolt and M3 nut.
		v.	Remove rear sight post set screw, remove spring loaded hardware, return rear sight post set screw.
		vi.	Install barrel, recoil spring and guide rod into the slide.
		vii.	Install slide onto front rail from front to back until barrel loop becomes visible through the side of the front rail M5-35 SHCS cavity.
		viii.	Install M5 nut and bolt through cavity (this acts as your slide takedown pin)
		ix.	Action slide back and forth, confirming that all friction parts are well-lubricated using firearm lubricant.
		x.	NOTE: Firearm reliability and functionality has been observed to increase substantially after ~50rds of break-in period. 

2.	Stock
	a.	Insert threaded rods into sleeves.
		i.	OR sleeves AND coupler if building the longer version.
	b.	Place sleeves into ladder or (ladders) of your choosing.
	c.	Seat ladder into pic rail mount of your choosing.
	d.	Thread rod into #8-32 nuts flush and then ensure the nuts are seated all the way into the pic rail mount.
	e.	Place M3 nut into top cavity of Rear Cap.
	f.	Place Rear Cap on rear of ladder.
	g.	Tighten #8-32 nuts onto the rear of the Rear Cap, ensuring the nut faces rest facing upward.
		i.	This step determines how rigid your stock will be, so do not over tighten to the point of fracture – but be sure to tighten more than 				normal. Consider a half rotation past “snug.”
	h.	Place stock or brace pad over #8-32 nuts.
	i.	Bolt top of pad into nut captured in Rear Cap (from step e.)
	j.	Bolt bottom of pad to rear cap using M3 nut and M3-20 SHCS.
	k.	Install stock onto frame using M5-35 SHCS’s and M5 nuts.

3.	Foregrip
	a.	Slide onto front pic rail.
	b.	Install using M5-30 SHCS and M5 nuts.

4.	Magazine (Danny Meatball Glock XL Magazine Remix)
	a.	Attach follower to magazine spring of your choosing.
		i.	OPTIONAL: insert spacer if building a 27rd magazine.
	b.	Place locking plate against spring with nipple pointing downward.
	c.	While depressing locking plate, slide baseplate into place until locking plate nipple clicks into place.


 --- STL Glossary --- 

Path \ Folder \ Subfolder(s)	STL File Name	File Size	Printing Requirement
Unseenkiller - Recession Ruger R2\STL\	 	 	Mostly Required
Unseenkiller - Recession Ruger R2\STL\	AFG.stl	15 MB	Optional
Unseenkiller - Recession Ruger R2\STL\	Frame.stl	25 MB	Required
Unseenkiller - Recession Ruger R2\STL\	Front Rail.stl	0 MB	Required
Unseenkiller - Recession Ruger R2\STL\	Rear Rail.stl	1 MB	Required
			
Unseenkiller - Recession Ruger R2\STL\Grips\	 	 	Optional
Unseenkiller - Recession Ruger R2\STL\Grips\	Ergo.stl	19 MB	Optional
Unseenkiller - Recession Ruger R2\STL\Grips\	Large.stl	15 MB	Optional
Unseenkiller - Recession Ruger R2\STL\Grips\	Small.stl	11 MB	Optional
			
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	 	Optional
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Brace.stl	7 MB	Required for Ladder Stock * OR Stock Pad.stl
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Long Coupler.stl	0 MB	Group 1 - Required for Long Ladder Stock
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Long Ladder - Front.stl	8 MB	Group 1 - Required for Long Ladder Stock
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Long Ladder - Rear.stl	1 MB	Group 1 - Required for Long Ladder Stock
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Long Rod Guide - 1.stl	1 MB	Group 1 - Required for Long Ladder Stock
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Long Rod Guide - 2.stl	1 MB	Group 1 - Required for Long Ladder Stock
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Long Rod Guide - 3.stl	1 MB	Group 1 - Required for Long Ladder Stock
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Long Rod Guide - 4.stl	1 MB	Group 1 - Required for Long Ladder Stock
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Pic Mount - 5 Degree.stl	2 MB	Required for Ladder Stock * OR Straight.stl
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Pic Mount - Straight.stl	2 MB	Required for Ladder Stock * OR 5 Degree.stl
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Rear Cap.stl	1 MB	Required for all Ladder Stocks
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Short Ladder.stl	8 MB	Group 2 - Required for Short Ladder Stock
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Short Rod Guide - 1.stl	1 MB	Group 2 - Required for Short Ladder Stock
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Short Rod Guide - 2.stl	1 MB	Group 2 - Required for Short Ladder Stock
Unseenkiller - Recession Ruger R2\STL\Ladder Stock\	Stock Pad.stl	5 MB	Required for Ladder Stock * OR Brace.stl
			
Unseenkiller - Recession Ruger R2\STL\Mag Release\	 	Mostly Required
Unseenkiller - Recession Ruger R2\STL\Mag Release\	Modular Release Buttons - Large.stl	1 MB	Required if using Modular Release.stl
Unseenkiller - Recession Ruger R2\STL\Mag Release\	Modular Release Buttons - Medium.stl	2 MB	Required if using Modular Release.stl
Unseenkiller - Recession Ruger R2\STL\Mag Release\	Modular Release Buttons - Small.stl	0 MB	Required if using Modular Release.stl
Unseenkiller - Recession Ruger R2\STL\Mag Release\	Modular Release.stl	1 MB	Required * OR Simple Release.stl
Unseenkiller - Recession Ruger R2\STL\Mag Release\	Release Lever - Finger Pad.stl	1 MB	Suggested * technically optional
Unseenkiller - Recession Ruger R2\STL\Mag Release\	Release Lever - Slim.stl	0 MB	Suggested * technically optional
Unseenkiller - Recession Ruger R2\STL\Mag Release\	Simple Release.stl	1 MB	Required * OR Modular Release.stl
			
Unseenkiller - Recession Ruger R2\STL\Magazine\	 	 	Optional
Unseenkiller - Recession Ruger R2\STL\Magazine\	27rd spacer for Ghost 17 Springs.stl	1 MB	Required if using Ghost brand Glock 17 springs
Unseenkiller - Recession Ruger R2\STL\Magazine\	Baseplate Locking Plate.stl	0 MB	Optional
Unseenkiller - Recession Ruger R2\STL\Magazine\	Baseplate.stl	7 MB	Optional
Unseenkiller - Recession Ruger R2\STL\Magazine\	Follower.stl	3 MB	Optional
Unseenkiller - Recession Ruger R2\STL\Magazine\	Magazine Body.stl	33 MB	Optional
