# The Big Mac
A 3dprinted Mac 10 frame that uses Grease Gun Magazines.

by UBERCLAY 
seed frame by  william.Jackson


## Description
Printable frame for the MAC-10


## Variants
	There are 3 variants of the frame.  1. A traditional frame, 2. A slick side frame 3. A slick side frame with the 'Come and Take It' graphic on the side

## Materials Required
PLA+ or other suitable material
Mac-10 parts kit
Grease Gun Magazine



## Instructions
Printing orientation should be rails up.

Use best judgement for supports


Detailed instructions in the assembly guide


