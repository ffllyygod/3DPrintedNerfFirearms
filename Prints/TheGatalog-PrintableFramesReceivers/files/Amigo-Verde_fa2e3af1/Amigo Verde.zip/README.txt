The Amigo Verde

	The Amigo Verde is a 3D printable CETME L receiver.

General Print Settings:

	This receiver has been tested to work well in eSun PLA+. In any material similar or superior to PLA+, this receiver should work as well.

**Note that all STL files are oriented and scaled properly, and changing their scale or orientation may result in your parts not fitting/working properly. Especially with parts like the barrel mount and receivers, orientation is important!**
**Note that you should follow these print settings in order to get the best possible results - changing nozzle size or layer height may cause you to have to hand fit things!**

My print settings for PLA+ were as follows:

	Walls: 8 (Very important to set walls to 8 - you should be able to go higher, but going lower will signifcantly weaken the flanges that mate the receiver sections)
	Nozzle: 0.4mm
	Layer Height: 0.15mm
	Temp: 230/60C
	Infill: 100% Recommended
	Supports: On/full (tree supports are ok)
	Cooling fan: 20% normal, 50% on bridges. Off for the first 20 layers. Keep the fan low to prevent warp.
	Bed Adhesion: gluestick or hairspray - since the big sections of this print have small footprints on the bed, using plenty of gluestick or hairspray is recommended.

	All other settings can/should be left as default or whatever you know works best with your printing setup.


Notes on printing barrel mounts:

	The barrel mounts for the barrel/trunnion in this build can be printed in more heat resistant materials to extend the number of rounds you can shoot between cooling breaks.
	Most testing of barrel mounts has been done with PLA+ - I would avoid printing the barrel mounts in any material that is less heat resistant than PLA+.
	In PLA+, the barrel mount can survive repeated 30 round dumps if allowed to cool between dumps *WITH ZERO LOSS IN ACCURACY*.
	If pushed to 60 rounds dumped, PLA+ barrel mounts may exhibit loss of accuracy if the barrel is torqued while things are still hot - for example, dumping 60 rounds then leaning the gun against a wall by its barrel can cause a shift.
	PLA+ mounts will work to 60 or so rounds, but accuracy will start to suffer and even after cooling accuracy will still be poor.
	Finally, testing has been done where a thin layer of RTV gasket maker is applied to the inside of the barrel mount to provide a heat barrier between the trunnion and mount. Testing shows that this barrier will reduce the loss of accuracy at 60 rounds dumped to zero. So while it isn't required, it seems to be quite helpful.

NO IMAGES, INSTRUCTIONS, DOCUMENTS, NOR ANY OTHER FILES LICENSED FOR COMMERCIAL USE, SUBSCRIPTION DOWNLOAD, OR ANY PAID DISTRIBUTION WHATSOEVER.
COPYRIGHT 2024

