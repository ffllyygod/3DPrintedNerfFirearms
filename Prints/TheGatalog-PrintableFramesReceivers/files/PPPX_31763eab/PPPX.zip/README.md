# PPPX
A 3D printable frame for Walther PPX and Creed part kits

by nguyenkvvn

## Description
A 3D printable frame for Walther PPX and Creed part kits, with variants for Glock magazines and original PPX magazines.

## Variants
- **Glock Magazine Variant** - Frame compatible with full-size Glock 17-round magazines
- **PPX Magazine Variant** - Frame compatible with PPX magazines

## Materials Required
Please follow the included Assembly Guide PDF for a material manifest.

## Instructions
Please follow the included Assembly Guide PDF for printing and assembly instructions.

## Pedigree
The following models/geometry were referenced in the development of this project:

* unreleased Glock Gen4/5 magazine negative geometry by the_aveees
* OEM PPX magazine geometry by UberPoor

## Change Log

- v1.0: Release Candidate 1
    * Update to assembly guide to tidy formatting for various sections, and provide clarity on magazine modification section

- v0.13: Public Beta Candidate 13
    * Update to assembly guide addressing how to install the magazine release between the variants, and some Walther part number references

- v0.12: Private Beta Candidate 12
    * Adjusted OEM magazine release function depth (v12; Ugly Ergo OEM v3). This should address the magazine "stickiness" from dropping free, along with potentially making PDP mag releases compatible.

- v0.11: Private Beta Candidate 11
    * Added OEM Ugly Ergos variant (v3)

- v0.10: Private Beta Candidate 10
    * Covered up OEM mag release spring per dev feedback (v12)

- v0.9: Private Beta Candidate 9
    * Tweaked OEM mag placement per dev feedback (v9)

- v0.8: Private Beta Candidate 8
    * Updated Walther OEM magazine variant (v8)

- v0.7: Private Beta Candidate 7
    * Restored OEM slide lock spring
    * Minor documentation update (again)

- v0.6: Private Beta Candidate 6
    * Added Walther OEM magazine variant (v7)
    * Minor documentation update

- v0.5: Private Beta Candidate 5
    * De-stressed takedown lever geometry
    * Minor geometry clean up
    * Addressed non-ergo model not receiving hammer channel update
    * Minor documentation update with introduction and information regarding partial last-round hold-open restoration

- v0.4: Private Beta Candidate 4
    * Walther Creed compatibility update

- v0.3: Private Beta Candidate 3
    * Refinements to slide lock restoration

- v0.2: Private Beta Candidate 2
    * Partial restore of the slide lock function

- v0.1: Private Beta Candidate 1
    * Initial commit
    * Added ergonomic variant

## License
No license has been selected as of 6/30/2023. No warranties expressed or implied. Use at your own risk.
