# MEPR
MPX Equivalent receiver Platform - printable receiver for the MPX

by nguyenkvvn

## Description
The MEPR is the "MPX Equivalent Printed Receiver". It is based off of the DS1913 model, and contains the necessary geometry to fit Sig Sauer MPX ambidextrous parts, as well as the upper receiver.

## Variants
- **MERP-X** - MPX receiver for builds using OEM Sig Sauer MPX lower-receiver parts. For use only with MPX Magazines.

## Materials Required
Please refer to the included assembly PDF for material guidance.

## Instructions
Please refer to the included assembly PDF for assembly and printing guidance.

## Change Log

- v1.0: Public Release 1
    * Promoted PB5 to v1.0

- v0.5: Private Beta Candidate 5
    * Added assembly PDF.
    * Addressed bolt-catch location issues.
    * Added front takedown stand-offs.

- v0.4: Private Beta Candidate 4
    * Addressed rear pin placement being so tight with the 1.85mm gap addressed
    * Attempted again to fix opening at bottom of the gap
    * Reconciled rear-pin retention geometry with above changes.
    * Return of the front takedown pin geometry to prevent detent from flying away

- v0.3: Private Beta Candidate 3
    * Introduced rear-pin retention by rotating it downwards 90 degrees.
    * Addressed 1.85mm gap at the back of receiver fitment.

- v0.2: Private Beta Candidate 2
    * Eliminated MERP-AK9 offering (for now)
    * Eliminated MERK-G9 offeering (for now)
    * Revised front takedown pin tolerance to better friction hold

- v0.1: Private Beta Candidate 1
    * Initial commit

## License
No license. No warranty expressed or implied. No license given to manufacture or commercialize.