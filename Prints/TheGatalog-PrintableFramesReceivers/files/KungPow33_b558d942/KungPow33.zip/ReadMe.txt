# KungPow33
A 3D Printable TT-33 Frame

by UberClay


## Description
A 3D printable TT-33 frame 

## Variants
- **54_norail** - Norinco M54 with no front rail
- **54_rail** - Norinco M54 with a front rail
- **213_norail** - Norinco M213 with no front rail
- **213_rail** - Norinco M213 with a front rail
- **57_norail** - Zastava M57 with no front rail



## Materials Required
You will need a set of each below for each [x] you make.
- x1 **Parts Kit** - A M54 or M213 (or TT-33) parts kit
- x1 **TT-33 RAILS** - Get them here: https://riptiderails.com/rail-kit-for-tokarev-tt-33.html
- x1 **Magazine**


## Instructions
1. Print a the frame rails up at a 30 degree angle nose up.  4 or more walls, 100% infill, 220/60c or your preferred print settings for PLA +
2. Print the Grips
4. Install rails
3. Assemble

See Assembly Guide PDF for detailed instructions

Credits:
Maple
Wunder9
RiptideRails
The DDRC Beta Team
The Gatalog


## License
no images, models, documents or other files licensed for commercial sale, use, exchange, subscription, download, or transfer, copyright 2025