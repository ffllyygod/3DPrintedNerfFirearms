#GeisterPistole Steyr M9/40

by Uberclay
original Steyr data refrence by Teruteru


## Description
A printable frame for the Steyr M9/40


## Materials Required
You will need a set of each below for each [x] you make.
- x1 **Parts Kit** - Procure a parts kit of your preference.



## Instructions
1. Print Rails up unless your support settings are dialed in
2. Print at 220/60, 100% infill, and 4 or more walls
3. Use support blockers on critical geometry.  See Assembly Guide for details



## License
no images, models, documents or other files licensed for commercial sale, use, exchange, subscription, download, or transfer, copyright UBERCLAY 2023


