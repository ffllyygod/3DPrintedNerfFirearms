CAG19 - a California legal, 3D printed Glock 19, in carbine configuration
Designed by WilhelmII
July 2021

Remix of FMDA DD19.2 Rev1.2

Designed to be 3D printed legally within California, as of 2021.

Included is a tutorial on the CA DOJ UNSA (Unique Serial Number Application) process + printing + assembly guide + shopping list (not including any of the parts kits for the frame).
Special instructions are required for inserting the steel block into the print.

Since this is an add-on of the FMDA DD19.2, use everything in their tutorial to assemble the frame (in terms of parts kits).
Functions the same as the original, same parts kits required, same rails, same magazines.

Total project cost including application fees, slide, parts kits, barrel, filament: ~$800


Side notes:

Some skeletonized Glock uppers with big slots cut out on the top side of the upper may not be compatible with the 16" barrel.
Watch out for slide bite on this particular design. Cali configuration forces your thumb in a weird position, make sure no skin resting on any part of the slide when firing.

The UNSA guide I have provided acts as a general outline and breaks down the entire application process into easier to understand steps.
None of the information provided should be taken as legal advice! Refer to the CA DOJ website for exact instructions.


Basic print settings used for the original design:

Filament: eSUN PLA+ (multiple fused colors)
Nozzle: 0.4mm
Layer Height: 0.2mm
Temp: 210/55C
Rest of the settings can be found in the PDF on a part per part basis.

Post process as needed. Only the underside of the frame where the front grip mounts too is required to be thoroughly sanded.
