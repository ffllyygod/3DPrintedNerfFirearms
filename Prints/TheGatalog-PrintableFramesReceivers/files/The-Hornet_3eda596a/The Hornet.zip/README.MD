#The Hornet DB9

by Uberclay
original file FMDA

## Description
A printable frame for the Diamondback DB9


## Materials Required
You will need a set of each below for each [x] you make.
- x1 **Parts Kit** - Procure a parts kit of your preference.
- x1 **AR15 detent spring** - https://bkingsfirearms.com/shop/ar15-lower-receiver-parts-kits/bkf-ar15-pivot-takedown-detent-spring/
- x1 **Mag catch spring**  -https://a.co/d/9syL0Op



## Instructions
1. Print Rails up and at a 30 degree angle.  See assembly guide for details.
2. Print at 220/60, 100% infill, and 4 or more walls (I use 8)



no images, models, documents or other files licensed for commercial sale, use, exchange, subscription, download, or transfer, copyright 2024