The BUBAR-10
	The BUBAR-10 is a 3D printable LR308 lower receiver. It is a modified version of the tried and true UBAR, and uses the same metal components to reinforce the lower.
	At the core of the BUBAR's design are these simple reinforcements - using hardware store metal parts, it solves the major design concerns that printed AR lowers face. Using a U-Bolt to reinforce the rear tower and rod end eye bolts to reinforce the front takedown lug, the BUBAR is a solid option for printable 308 lowers.

Printed Parts Checklist:
	
	BUBAR-10 Lower Receiver
		Two variants are avaliable:
		Standard and Low Shelf. The standard variant will be a little stronger, while the low shelf lower will be compatible with FRTs and the like.

Hardware Checklist:
	
	Refer to the "Shopping List" section of the build tutorial pdf.

Parts Kit Compatibility:

	Refer to the build tutorial pdf.


General Print Settings:

	This receiver has been tested to work well in eSun PLA+. In any material similar or superior to PLA+, this receiver should work as well.

**Note that all STL files are oriented and scaled properly, and changing their scale or orientation may result in your parts not fitting/working properly.**
**Note that you should follow these print settings in order to get the best possible results - changing nozzle size or layer height may cause you to have to hand fit things!**

My print settings for PLA+ were as follows:

	Walls: I used 8, but you're free to use whatever works best for your setup.
	Nozzle: 0.4mm
	Layer Height: 0.15mm or 0.16mm
	Temp: 230/60C
	Infill: 100% Recommended - while the UBAR might not need 100% fill, this ensures that you won't end up hurting the lower if you overtighten anything.
	Supports: On/full (tree supports are ok)
	Cooling fan: 20% normal, 50% on bridges. Off for the first 10 layers. Keep the fan speed low to prevent warp.
	Bed Adhesion: gluestick or hairspray recommended

	All other settings can/should be left as default or whatever you know works best with your printing setup.