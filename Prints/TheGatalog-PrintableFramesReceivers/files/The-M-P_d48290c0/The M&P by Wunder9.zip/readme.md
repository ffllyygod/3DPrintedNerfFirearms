# The M&P 
Smith & Wesson M&P 1.0/2.0 Frame

by Wunder9


## Description
The Smith & Wesson M&P 1.0/2.0 Frame by Wunder 9


## Materials Required
You will need a set of each below for each [x] you make.
- x1 **M&P9 or M&P40 1.0 or 2.0** - Procure a parts kit of your preference.


## Instructions
Suggested print settings:
Material: PLA+ (Recommended)
Layer height: 0.2mm or smaller (Recommended)
Infill: 99-100% (Use best judgement)
Walls: 4-10 (Use best judgement)
Support: Everywhere


## Change Log

BETA v0.03
	-Grip extension forward face made flush with rear of magazine well (for smoother magazine insertion)
	-First release to include f3d CAD file
BETA v0.02
	-Trigger pin hole diameter changed from 0.125 in to 0.15 in (fix trigger pin fit)
	-2.0 sear block notch geometry revised (non-mandatory, done to better align hole with locking block protrusion)
	-Slight adjustments to rear rail clearances (non-mandatory, adjusted tolarences to better fit 2.0 rear rails)
	-Magazine release angle changed from 18 degrees to 23 degrees (shifts magazine 0.04 in upwards to fix 40 cal chambering issues)
	-Magazine release moved 0.01 inch upward (done to help move magazine upwards)
	-Magazine well moved 0.02 inch rearwards (add clearance for angled mag release, assist in chambering)
	-Grip shortened 0.01 inch to account for higher magazine

BETA v0.01
	-Initial Release For M&P Beta Testers

