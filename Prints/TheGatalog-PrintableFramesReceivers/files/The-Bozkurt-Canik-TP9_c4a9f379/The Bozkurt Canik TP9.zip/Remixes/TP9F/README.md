TP9F

TP9 PDW w/ folding brace

based on the 17F

https://odysee.com/@AreWeCoolYet:7/The-Glock-17F

(all parts are identical to build except the frame and the hood)

30 round Beretta 92 mags will work in the TP9

https://gunmagwarehouse.com/kci-beretta-92fs-9mm-30-round-magazine.html

You may need to open the front of the feedlips slightly to increade the angle of the round for smooth feeding

Refrence the AWCY readme in the DOCS folder for instructions on building the folder portion of this remix

