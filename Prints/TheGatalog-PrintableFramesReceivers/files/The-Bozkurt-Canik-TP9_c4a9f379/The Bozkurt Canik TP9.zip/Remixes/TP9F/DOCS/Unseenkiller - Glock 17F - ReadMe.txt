                                                                                
                                                                                
             ▄████████  ▄█     ███  ▄████████  ▄█    ███  ▄████████             
            ███    ███ ███     ███ ███    ███ ███    ███ ███    ███             
            ███    ███ ███     ███ ███    █▀  ███    ███ ▀██    ███             
            ███    ███ ███     ███ ███        ███    ███   ▀   ▄███             
          ▀███████████ ███     ███ ███        ██████████     ▄███▀              
            ███    ███ ███     ███ ███    █▄   ▄▄    ███    ████                
            ███    ███ ███ ▄█▄ ███ ███    ███ ███    ███     ▄▄                 
             ▀█     ▀█  ▀███▀███▀   ▀██████▀   ▀██████▀     ▀██▀                
                                                                                
                                                                                
                       -*- Are We Cool Yet? Presents -*-                        
                                                                                
################################################################################
#                                                                              #
#                                   The 17F                                    #
#                                                                              #
#                      A Glock 17 chassis, able to fold.                       #
#                                                                              #
#                               by unseenkiller                                #
#                                                                              #
################################################################################
#                            /X> Release Notes <X\                             #
################################################################################
#                                                                              #
#                               [-+ Summary +-]                                #
#                                                                              #
#   The 17F was my first ever project (beta) through AWCY?, and I chose not    #
#   to progress this project (or release it) due to not having truly "loved"   #
#   it. I waited until I knew more about CAD and design, and revisited this    #
#     design and rebuilt it from the ground up, keeping only the concepts.     #
#             From there on out, it had been called "the 17F R2".              #
#                                                                              #
################################################################################
#                               /X> Credits <X\                                #
################################################################################
#                                                                              #
#                          [-+ Brought to you by +-]                           #
#                                                                              #
#                           ︻╦╤─ Unseenkiller ─╤╦︻                            #
#                                                                              #
#                           [-+ With the help of +-]                           #
#                                                                              #
#                         pla_ak_ak_ak, mattdaddy, and                         #
#                                                                              #
#                         [-+ Additional thanks to +-]                         #
#                                                                              #
#           ....about 269 other people in the public beta, lol, and            #
#                                                                              #
#                       the entire Are We Cool Yet? team                       #
#                                                                              #
################################################################################
#                       /X> BOM (Bill of Materials) <X\                        #
################################################################################
#                                                                              #
#                    [-+ McMaster / Amazon / Easy stuff +-]                    #
#                                                                              #
#                   1x Clevis Pin with Retaining Ring Groove                   #
#    Zinc-Plated Steel, 1/4" Diameter, 1-7/8" Usable Length - McMaster Part    #
#                               Number 92735A695                               #
#                                                                              #
#                             1x Ender Bed Spring                              #
#                                                                              #
#                                     SHCS                                     #
#                                   1x M3-30                                   #
#                                  1x M3 Nut                                   #
#                                   4x M4-25                                   #
#                                  4x M4 Nuts                                  #
#                                   3x M5-30                                   #
#                                   3x M5-35                                   #
#                                  6x M5 Nuts                                  #
#                                                                              #
#     (parts-dispensed.com has agreed to make and sell parts kits for this     #
#     build, consider giving them your business! I have turned down their      #
#   offer for profit sharing, so please be aware that buying through them is   #
#                         a benefit to you, not to me)                         #
#                                                                              #
#                             [-+ Normal Stuff +-]                             #
#                                                                              #
#                          Full Glock 17 minus frame                           #
#                            Glock 17 locking block                            #
#                                                                              #
#                             1x set of FMDA Rails                             #
#                                      OR                                      #
#                             1x set of PY2A Rails                             #
#                                                                              #
#               Picatinny rail mounted optic STRONGLY suggested                #
#                                                                              #
################################################################################
#                             /X> Instructions <X\                             #
################################################################################
#                                                                              #
#                         [-+ Printing Suggestions +-]                         #
#                                                                              #
#                   Print the frame rails down @ 100% infill                   #
#                                                                              #
#   Print the folding stock chassis right side up, not vertically, not flat    #
#   on it's side. This will feel like a waste of material with supports, but   #
#                your cheek and face will thank me. I promise.                 #
#                                                                              #
#    Print the hoods "rails down" (pretend it's installed and then flip it     #
#                                 upside down)                                 #
#                                                                              #
#                      Everything else is dealers choice!                      #
#                                                                              #
#                               [-+ Assembly +-]                               #
#                                                                              #
#    1) Assemble the Glock into the frame like you normally would (FMDA and    #
#                      PY2A guides included in release).                       #
#                                                                              #
#    2) Install the hood, taking care to put the M5 nut into the beavertail    #
#                                    first.                                    #
#                                                                              #
#   3) Put the spring in the button, put the button into the stock chassis,    #
#      thread the long M3 into the hole to retain the button and spring.       #
#                                                                              #
#    4) Attach the stock chassis to the folding base of your choose, slide     #
#           the clevis pin into the holes and retain with the e-clip           #
#                                                                              #
#    5) Bolt the folding latch and Stock Pad (or the Brace) to the back of     #
#                              the stock chassis.                              #
#                                                                              #
#    6) Attach the stock chassis to the hood via picatinny rail, using M5's    #
#                                  to secure.                                  #
#                                                                              #
#                            WARNING!!!!!!!!!!!!!!                             #
#                                                                              #
#      The folding latch takes a while to break in. It will feel stiff at      #
#   first, but after opening and closing it about a dozen times it gets much   #
#                                   easier.                                    #
#                                                                              #
################################################################################
#                                                                              #
#                 -`-,-{@  AWCY? - Stronger Together  @}-,-`-                  #
#                          (oven appreciation group)                           #
#                   Join us at: https://www.AreWeCoolYet.WTF                   #
#                                                                              #
################################################################################