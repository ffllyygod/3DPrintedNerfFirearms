#Bozkurt CANIK TP9

by Uberclay
original file FMDA

## Description
A printable frame for the Canik TP9


## Materials Required
You will need a set of each below for each [x] you make.
- x1 **Parts Kit** - Procure a parts kit of your preference.
- x1 **MAF P99 rails** - https://maf-arms.com/product/walters-p99-hand-rail/

(you may have to hand fit the rails slightly, Canik kits have some variance)
also uses Canik mags


## Instructions
1. Print Rails up unless your support settings are dialed in
2. Print at 220/60, 100% infill, and 4 or more walls

Pro-tip: https://www.youtube.com/watch?v=pFeDK-QyKF4&t=31s  (helpful vid on assembly ect)



no images, models, documents or other files licensed for commercial sale, use, exchange, subscription, download, or transfer, copyright UBERCLAY 2023, FMDA 2023







