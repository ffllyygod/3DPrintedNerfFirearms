DIY disassembly latch
These parts are often left out from parts kits, so here are the dimensions in .DXF and a drawing if you want to have it lasercut, milled, or file it yourself.
This should be 2mm thick, but 0.074" stock should be fine as well.