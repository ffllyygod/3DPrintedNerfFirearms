# PPX4
A 3D printable Beretta PX4 Storm frame

# Author
jmanjones

#### Thanks to:
- gerald.katz for feedback, advice, and room help
- Dr._Death for testing and beta help
- TyrannicalTy for testing and advice
- Concussisomniar for relentlessly printing and testing frames
- The rest of the beta room for various feedback and testing

## Description
This is a 3D printable Beretta PX4 Storm frame which uses 3D printed rails and no extra parts beyond a parts kit. It's been proven to be quite reliable and durable.

## Variants
- **PX4_940_FS_FSMag** - 9mm/.40S&W full size, takes full size PX4 magazines
- **PX4_940_FS_92Mag** - 9mm/.40S&W full size, takes full size Beretta 92 magazines
- **PX4_940_C_CMag**   - 9mm/.40S&W compact, takes compact PX4 magazines
- **PX4_940_C_FSMag**  - 9mm/.40S&W compact, takes full size PX4 magazines
- **PX4_940_45_45Mag** - .45 ACP standard or Special Duty, takes 9 or 10rd PX4 magazines

## Materials Required
- **Parts Kit** - Kits from the following models are supported
    - Full Size 9mm
	- Full Size .40 S&W
	- Full Size .45 ACP
	- Special Duty .45 ACP
	- Compact 9mm
	- Compact .40 S&W


**! Subcompact models are not supported !**

Keep in mind that:
	9/40 parts differ only in barrel and recoil spring.
	All parts interchange between all other models except slide, barrel, recoil spring, and trigger bar.
	The hammer spring cap on the compact is smaller than the full size one. The fullsize one will be around 34mm long, while the compact one will be about 24mm long.
	
- **Recommended Drill Bits**
    - #2 bit (0.221”/5.6134mm)
    - #20 bit (0.161”/4.0894mm)
    - #26 bit (0.147”/3.7338mm)
    - #31 bit (0.120”/3.048mm)

## Instructions
**! See the assembly guide pdf included in this release for assembly pictures and extra info !**

The assembly of the PPX4 will be essentially the same as a factory Beretta frame, so existing resources will be helpful if you experience any assembly issues.

Print settings:
- PLA+ recommended
- Print at 100% infill with at least 6 walls
- 0.2mm layer height (or smaller)
- 0.4mm nozzle is recommended, as there are some thin features
- 15° nose up (stl preoriented, recommended), or 0° (bottom of magwell planar with bed)

### Cleanup:
Remove supports and clean up any droop from the top of the magazine catch hole. The assembled magazine catch should move back and forth without any resistance, and magazines should drop free. The fit on the rails is designed to be perfect without fitting, but minor filing on the bottom or sides of the rails may be required. If your rails are too far out of spec, the decocker may not function reliably.

### Drill/ream suggestions:
- Drill out magazine catch center hole with #2 bit (0.221”/5.6134mm)
- Drill out slide catch hole with #20 bit (0.161”/4.0894mm)
- Drill out hammer plug pin hole with #26 bit (0.147”/3.7338mm)
- Drill out trigger pin hole and lower hammer unit support pin hole with #31 bit (0.120”/3.048mm)

For the above holes, only #1 and #2 feature movement, so the others can be tighter fits as desired. Take care not to crack the frame if anything is too tight.

### Slide assembly
- Drop the tip of the barrel in the complete slide, slide forward, and drop down, leaving the cam slot facing you
- Put the small end of the recoil spring assembly in the locking block
- Put the large end of the recoil spring in the slide and drop the locking block on top of the barrel, with the cam facing the slot in the barrel

### Hammer unit assembly
- Clip the hammer pin retaining spring over the pin on the right side of the hammer unit body
- Partially insert the lever assembly pin into the top hole of the hammer unit body from the left side
- Insert the spacer, hammer release lever (shiny side towards spacer), and firing pin catch lever (long bent side facing away from spacer)
- Push the lever assembly pin all the way in to the hammer unit body (the pin should ‘lock’ in place due to its rubber o-ring)
- Put the hammer, hammer strut, hammer strut pin, and hammer spring together
- Align the hammer assembly in the hammer unit
- Put the hammer pin through the left side. Move the hammer pin retaining spring down and let it sit in the groove in the hammer pin. The tab on the - pin should point up.
- Place the sear inside the hammer unit and partially insert the sear pin from the left side
- Place the straight end of the sear spring on the notch of the sear and line up the hole with the sear pin
- Push down on the sear spring and push the sear pin through it, flush in the hammer unit

### Disassembly latch
- Insert disassembly spring into recess
- Insert disassembly latch at an upwards angle, using it to push the spring down and to the center until the latch is centered in the frame and captive

### Slide catch
- Insert spring partially into the small hole
- Insert the slide catch with the long end of the spring on the top nub
- Tilt the slide catch up while pushing in to seat it
- Make sure the other end of the spring is fully inserted into the frame
- This should move without resistance

### Magazine catch
- Put magazine release spring on magazine release button and insert into desired side of frame
- Snap the magazine release button support on the stem of the magazine release button from the other side
- Insert the magazine release button pin through the support

### Trigger
- Insert the trigger into the frame
- Insert the trigger pin partially
- Place the trigger spring into the recess such that the two prongs are pointing downwards
- Push the spring down while fully installing the pin

### Trigger bar spring
- Insert the trigger bar spring all the way down into the recess to the right of the magwell, with the end of the spring facing the rear of the frame

### Trigger bar
- Pull the trigger and insert the trigger bar nub into the arm of the trigger through the clearance cut to the right of the trigger arm

### Hammer assembly
- Hold the trigger bar together with the hammer assembly while inserting into the frame
- Make sure the trigger bar spring is in the channel on the bottom of the trigger bar
- Insert the frame pin
- Insert the lower hammer unit retaining pin - don’t hammer it, use a tool to lift the bottom leg of the sear spring while gently tapping it in to avoid - bending it. It should click into place when fully inserted.
- Insert the hammer spring cap and hammer spring cap pin

When inserting the hammer unit assembly, make sure that the trigger bar spring rides in the ridge cut in the underside of the trigger bar.
When the hammer unit assembly is fully inserted, the frame pin and lower retaining pin holes should line up with the corresponding holes in the frame.
The cut on the end of the frame pin will be captured by the hammer pin retaining spring. You may need to give it a tap with a hammer to seat it fully. The head of the pin should lay flush with the grip.

### Final assembly
Now take your entire slide assembly and slide it onto your frame. The disassembly latch should click into the locking block.

Now ensure a live round has not made its way into the chamber and perform a full function check, ensuring the following is functional before firing:
- Disassembly latch
- Half cock/Full cock
- DA and SA trigger release
- Trigger reset
- Decocker
- Magazine catch
- Slide stop

## Change Log
- v2: add disassembly latch dimensions for DIY, fix area between hammer unit legs was too small, fix too forward relief area for trigger bar for FSUpper_92Mag_940, FSUpper_CMag_940, FSUpper_SCMag_940
- v52b: add PX4_940_C_FSMag
- v51b: add printable hammer spring cap for fullsize and compact
- v50b: opened up some internal tolerances around hammer unit, opened up .45 magwell a tad, re-added 92 magwell version
- v49b: opened up magwell for 9/40 and 45, reworked area behind trigger, widened mag catch pocket, fixed mag catch stop when fully pressed, various adjustments for printability, reworked trigger bar spring pocket, increased diameter of slide catch spring hole, increase rail length slightly

## License
Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)
https://creativecommons.org/licenses/by-nc-sa/4.0/