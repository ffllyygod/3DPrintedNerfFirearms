# SW40

by TyrannicalTy

## Description
The SW40 pistol frame is based off of myy previous SD40 pistol frame, utilizing the rear rail inserts that Vihn developed for the SW9. 

## Variants
- **SW40 Plain** - Redesigned and plain frame to accomodate remixes
- **SW40 Cobra** - Redesigned frame with Cobra stipple and texture

## Materials Required
You will need a set of each below for each [x] you make.
- x1 **Parts Kit** - Procure a parts kit of your preference.
- x1 **SD9/SW9 Front Rail Block** - Front rails for the frame
- x1 **SW9 Rear Rails** - Rear rail inserts for the frame.

## Instructions
1. My best results were with the rails up, barrel tilted up at 20 degrees. See renders and PDF. Others have printed the frame upside-down. Use 100% infill. Regular supports are recommended. Use your best settings.
2. Remove all supports.
3. Install the front rail block and pin it in.
4. Install mag catch and spring.
5. Install the trigger assembly and rear sear housing and pin in place.
6. Install the front locking block, along with the slide release lever.
7. Assemble the slide and frame together. Perform a function check.

*PROTIP*: If your trigger is "dead" after cocking, you will need to manually engage the trigger bar with the sear using a pick or screw driver coming up from the mag well. Refer to the first FAQ question on how to "fit" your sear.

## FAQ

**Q:** Why is it that my trigger isn't resetting? It's like it's binding or scraping on something.

> **A:** I found this happens when the sear and trigger bar are bone dry. Drop a dab of gun oil where the two parts interface in the sear housing, and try to get a reset again. You can also remove the trigger and sand the area where the trigger bar is rubbing. 

## License
No license has been selected as of 10/27/2021.
Note that this does NOT give you the license to manufacture these rails for commercial use.
