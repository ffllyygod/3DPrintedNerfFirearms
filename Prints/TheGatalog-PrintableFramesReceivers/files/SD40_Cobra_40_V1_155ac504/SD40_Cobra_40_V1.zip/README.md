# SD40

by TyrannicalTy
original file by FreeMenDontAsk

## Description
The SD40 pistol frame is based off of FMDA's SD9 pistol frames. The SD40, being a larger caliber, uses a magazine(SD40/SW40) with a wider body.  This means that the frame requires a wider grip with wider magazine opening. Furthermore, the frame has been strengthened to ensure it can survive the increased recoil. 

## Variants
- **SD40 Plain** - Redesigned and plain frame to accomodate remixes
- **SD40 Cobra** - Redesigned frame with Cobra stipple and texture

## Materials Required
You will need a set of each below for each [x] you make.
- x1 **Parts Kit** - Procure a parts kit of your preference.
- x1 **SD9/SW9 Front Rail Block** - Front rails for the frame

## Instructions
1. My best results were with the rails up, barrel tilted up at 20 degrees. See renders and PDF. Others have printed the frame upside-down. Use 100% infill. Regular supports are recommended. Use your best settings.
2. Remove all supports.
3. Install the front rail block and pin it in.
4. Install mag catch and spring.
5. Install the trigger assembly and rear sear housing and pin in place.
6. Install the front locking block, along with the slide release lever.
7. Assemble the slide and frame together. Perform a function check.

*PROTIP*: If your trigger is "dead" after cocking, you will need to manually engage the trigger bar with the sear using a pick or screw driver coming up from the mag well. Refer to the first FAQ question on how to "fit" your sear.

## FAQ

**Q:** Why is it that my trigger isn't resetting? It's like it's binding or scraping on something.

> **A:** I found this happens when the sear and trigger bar are bone dry. Drop a dab of gun oil where the two parts interface in the sear housing, and try to get a reset again. You can also remove the trigger and sand the area where the trigger bar is rubbing. 

## Change Log
- v1.0: Public Release 1
    * Packaged for final release.
    
- v0.6: Private Beta Canditate 6
    * Increased radius on front of grip for better ergonomics.
    * Loosened slot for take-down bar, as v0.5 was too tight. 

- v0.5: Private Beta Candidate 5
    * Tightened slot for take-down bar. 
    * Carved out clearance for mag release button. 
    * Increased radius for additional clearance for trigger bar reset.
    
- v0.4: Private Beta Candidate 4
    * Released with thumb pads added to v0.3. Awaiting feedback on the option. 

- v0.3: Private Beta Candidate 3
    * Released with full texture updated to v0.2 frame.
    * No thumb pads

- v0.2: Private Beta Candidate 2
    * v0.1 cracked after a few mags for 2 users. v0.2 flushed out the grip for strength and to eliminate weak point
    * Addressed trigger bar binding
    * Addressed slack in take-down bar spring
    * Released "Vanilla" distro

- v0.1: Private Beta Candidate 1
    * Initial distro
    * Full Cobra Texture with Thumb Pads

## License
No license has been selected as of 10/27/2021.
Note that this does NOT give you the license to manufacture these rails for commercial use.
