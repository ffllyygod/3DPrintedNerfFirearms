Introducing: The Regular 10/22 by YZY Prints and internetpizza
Remixed from parts by IvanTheTroll & Laff Dynamics 

NO IMAGES, INSTRUCTIONS, DOCUMENTS, NOR ANY OTHER FILES LICENSED FOR COMMERCIAL USE, SUBSCRIPTION DOWNLOAD, OR ANY PAID DISTRIBUTION WHATSOEVER.
COPYRIGHT 2025

This package is free of charge for download on Odysee.com.

Please contact yeezyprints@protonmail.com if you have paid money for this package.

Friends don’t let friends use DEFCAD.

The owner of DEFCAD, Cody Wilson, is a convicted pedophile.


## Description

The Regular 10/22 was designed and packaged by YZY Prints & 
internetpizza in early 2023. It is a design that utilizes OEM Ruger 10/22 
parts, a 3D printed receiver, and a 3D printed buttstock. 

The Regular 10/22 was designed out of necessity – there are dozens of 
tried and true rifle designs that utilize Ruger 10/22 OEM parts, but for 
the most part they resemble Star Wars set pieces. This package was 
designed to be a lightweight, sleek and streamlined rifle that is both 
minimalist and ergonomic while using as few additional parts as 
possible. With a 15 round mag and a Romeo 5 red dot, the build in the 
cover photo weighs in under 4 pounds – with an 18” barrel! 

The Regular 10/22 was designed using the LX-22 chassis by Laff 
Dynamics as a jumping off point, the 10/22 3D Printable Receiver 
uploaded to TheGatalog by IvanTheTroll, and a custom designed butt 
stock designed by both YZY Prints and internetpizza. All of Laff’s LX-22 
parts ecosystem should be compatible with this buttstock. 

As of late Summer 2024, the design has been tested well past 1,000 
rounds without any signs of imminent failure.


## Materials Required

You will need a set of each below for each [x] you make.
1x Ruger 10/22 Rifle Bolt, factory pins + factory buffer pin 
1x Ruger 10/22 Barrel Retaining V-Block 
2x Ruger 10/22 Barrel Retaining V-Block Screws 
1x Ruger 10/22 Charging Handle 
(please note: This design has been tested with an extended 
charging handle, but we cannot guarantee that every aftermarket 
charging handle will work) 
1x Ruger 10/22 Trigger + Magazine Release 
(please note: This design has been tested with an extended mag 
release with varying degrees of compatibility. Extended mag releases 
tend to cause the magazine to be somewhat tricky to remove, proceed 
with caution) 
1x Ruger 10/22 Barrel 
1x Ruger 10/22 Magazine 
1x Ruger 10/22 Receiver Takedown Screw 
3x M4 x 30mm bolts 
3x M4 x 10mm bolts 
Optional 2x #10 wood screws for TPU buttpad, ¾” L

## Instructions
The parts are correctly orientated in the STL file. This package has 
only been verified to work in the given orientation and print settings.  
The receiver, chassis, and receiver rail should be printed at 99% 
infill, 8+ walls.  

The included Laff Dynamics handguards should be printed 
according to his specifications, with 5-8 walls and 35-50% infill.  
The skeletonized grip and stock will use Infill Modifiers. Print 
settings for these are on page 7 of the attached PDF. 

Material choice is at your discretion, but it is highly suggested to 
use PLA+/PLA Pro from a reputable brand like Polymaker. 
Regarding the optional buttpad: You can print this out of whatever 
material you would like, however it is suggested that you use a TPU with 
a shore hardness of 90 and </=30% infill. A TPU with a shore 
hardness of 95 will be a stiffer buttpad, this is entirely up to user 
preference.

1.) Assemble the receiver. The 10/22 Receiver file that is 
included here has been extensively documented by 
IvanTheTroll. I’ve included the package in its entirety, 
unedited. Please refer to his README for additional 
information regarding the printed receiver. Once you 
have installed the trigger, bolt, charging handle, and 
barrel, you are ready to proceed. 

2.) JB Weld the Grip + Stock together. 

	a.  Apply JB Weld on the outside of the stock lugs and on 
	the inside of the hexagonal cutouts. The hexagonal 
	shape allows for excess JB Weld to collect and reinforce 
	the lugs in place

3.) Once the stock is epoxied together, it cannot be undone 
without breaking the printed parts, so use some caution 
here and go slowly. The fit between the lugs and the 
hexagonal cutouts should be almost perfect with next to 
no play. If your parts do not fit together without resistance 
you will need to do some hand fitment, or tune your 
printer. If you printed the TPU buttpad, you can install that 
now by drilling the wood screws into the printed stock. Do 
so very slowly – if you crack the stock from going too tight 
or too quickly, there is no easy way to fix it. 

4.) Install the chassis to the grip. 
a. You will tighten 3x M4x30mm socket head bolts into the 
grip. Add a touch of oil and go slowly – we are tapping 
bare plastic and it is very easy to overheat and rip out 
the fresh threads you just created.

For a detailed breakdown of how the receiver is assembled, please see the full PDF documentation attached in this package.

## Change Log

- v1.0: Version 1 Release


## License
This package, in its entirety, is released on a non-commercial basis. 
You may not: 
Re-upload, re-distribute, sell for profit or other monetary gain, put 
behind a paywall, make available to users on a monthly subscription 
basis, or otherwise use its likeness or namesake, in furtherance of a 
commercial endeavor or enterprise.  
If you paid money for this package, you got scammed. If you 
downloaded this from a website that required you to purchase a 
monthly or yearly subscription as a service, you got scammed. If you 
had to show identification before you could download this package, 
you got scammed. 
Please contact yeezyprints@protonmail.com if you feel this has 
happened to you, so that we may take appropriate legal action. 
