# SoundShock Neos
3D printable receiver compatible with the Beretta U22 Neos.

by SoundShock
Final revision by DBFirearms
Big thanks to Gerald.Katz for putting up with my bullshit on this frame lol

## Description
This frame is compatible with All lengths of U22 models including Carbine barrel. DBFirearms assisted with contouring with the original grip and style, and final dialing in of dimensions.
Remember to set your text mode to Wrap in your text editor when viewing this.

## Variants
- **Slantface** -  To look closer to the original frame. 
- **Railed** - Canceled varient due to lack of rigidity of the front of the frame in contact with the hot barrel. Reinforcement ideas included zipties and 70mm long support screws driven into the railed section.

## Materials Required
You will need a set of each below for each pistol you make.
- x1 **Complete U22 Upper Assembly** 
		-Slide
		-Barrel
		-Recoil spring
		-Firing pin
		-Firing pin spring
		-Top rail
		-Top rail screws
		-Barrel band
		-Barrel band screw
		-Rear sight assembly
		-Rear sight roll pin
		-Barrel band roll pins
- x1 **Complete U22 Lower Parts Kit** -  
		-Trigger
		-Trigger spring
		-Trigger bar
		-Trigger pin {medium length}
		-Ejector
		-Ejector pin {longest length}
		-Mag catch
		-Mag catch spring
		-Mag catch pin {short length}
		-Barrel nut
		-Barrel nut retainer
		-Retainer screw
		-Retainer spring
		-Safety lever
		-Safety right lever
		-Safety detent
		-Safety detent spring
		-Slide catch
		-Slide catch spring
		-Firing pin pusher pin
		-FPP spring
		-FPP spring caps
		-Firing pin block
		-Pin block screw {USE THE HEX SCREW FROM MGW IF YOU HAVE A FLATHEAD SCREW}
- x1 **U22 magazine** 
- x1 M3 hex nut

**Note:** The safety block is unused

## Tooling Required
- x1 2mm drill bit
- x1 3mm drill bit
- x1 hammer
- x1 2 - 4mm pin punch 
- x1 round profile and flat profile needle file
- x1 Flush cutters/filament cutters supplied with your printer

## Instructions 
### Preparation
1. Print this frame in the orientation and settings below.
    - **Material:** - PLA+ Esun/Inland recommended
    - **Nozzle** - 0.4mm
    - **Layer Height:** - 0.12-0.16mm
    - **Temp:** - 210C/60C
	- **Walls:** - 5 walls
    - **Infill:** - 99% (35% is proven to work with 8 walls but *is not recommended* as it was not tested for extreme use.)
    - **Supports:** - On (If using tree supports, press buildplate only. Otherwise use everywhere)
    - **Cooling Fan:** - 20% normal, 50% on bridges. Off for the first 10 layers. Keep the fan low to prevent warp. (This is copied from the old Glock 17.1 Instruction file, I have never changed my fan settings and I have no clue if this affects any warpage)
    - **Bed Adhesion:** - For newer tempered glass beds, you may find it possible to print with just a clean bed like me. For smooth glass, use masking tape, gluesticks, or hairspray. Remember that aerosols are flammable. 
    - **Orientation** - Print the frame upright. The top of the frame is the part with the firing pin block hole visible with the hex hole below on the bottom.
2. Import the frame into your slicer software with the orientation as described above.
3. Send to your printer, and start the print. 

- **Pro-tip**: To prevent the print from falling off the bed, pay close attention to the first layer, adjust the leveling knobs so that the filament 
sticks close to the bed. Do not adjust it too close, or the filament will bubble and you'll have extruder thunk. If it's way too close, the nozzle will crash into the glass 
bed and possibly damage it. Do not let this happen.

- **Pro-tip**: Read the assembly instructions fully before doing any steps to prepare yourself.



The following instructions were written prior to the PDF being finalized. I'm too lazy to pull all the instructions over. These were written in mind of the ReadMe file, the others we're written in mind of having the images to pair with in the  PDF.



### Post-Processing
4. When the print is complete, remove from the bed and cut out the support filament.
5. Use a 2mm drill bit on the trigger pin hole, ejector pin hole, and mag catch pin hole. Use a 3mm drill bit on the barrel nut retainer screw hole. Use a round profile file on the safety lever hole until the safety lever rotates smoothly with no twisting play. This part is MIM so it isn't exactly perfectly round.
6. Use a flat profile file on the barrel nut slot until the barrel nut fits smoothly. Use a fine knife to smooth the area in front of the barrel nut hole where there's a curve and point to make the retainer piece slot easier to put the piece in.
7. Use a round profile file on the firing pin pusher hole to let the pusher slide through freely. If it's too tight, it will bind and won't hold the striker back. *Don't insert the piece with the safety installed. You will need to take it back out. Inserting the pusher with the safety installed will make it impossible to use an angled pick tool to shove the pusher back out if it gets stuck.*
8. Use the 3mm drill bit on the hole on the rear of the receiver connected to the hexagonal hole, The rear M3 screw should slip through to interface with the M3 nut. If you're lazy, you can just ream straight through with an M3 tap. The final revision frame was tested with this exact method to 1000 rounds in a single session, with brief pauses to load the single magazine back up.
9. File the inside of the mag catch area until the mag catch can slide through cleanly. There is a half circle in front of the magcatch slot that goes further than the actual catch. This is intentional to make closing the mag catch possible if installed without the slot being fully cleaned out. Jab a thin screwdriver or pick and lift under the catch to close it.
10. File the insides of the magwell sides, and the front ramp until the mag slides through easily.
11. Clean up the slide catch area until the catch fits in and rotates flush to the side of the frame without the spring installed. 

### Installing the magazine release and ejector
12. Place the spring into the front of the mag catch and slide the mag catch in, then insert the pin into the catch hole above. The pin should be flush with the bottom of the receiver, it is normal for the pin to be sticking out of the top slightly.
13. Place the ejector into the slot behind the magwell area and hammer the pin flush into the side. The rollpin is super tight with the ejector, so expect to use lots of force.

### Installing the trigger assembly, safety, and slide-release
14. Place the slide catch spring on the slide catch with the bent end on the notch in the slide catch.
- **Pro-tip**: If the slide catch does not go all the way in, inspect where the catch is coming in contact with the frame. It's mostly small details which are hard to print neatly on FDM printers.
15. Stick the extended part of the torsion spring into the point part of the teardrop cutout, bend the spring inside until the slide catch can fall into the slot and be flush. 
16. Place the torsion spring on the trigger bar and insert onto the top hole on the trigger, the bar can rest on the front of the frame without issue for now.
17. Align the lower trigger hole with the trigger pin hole, push the trigger pin inside until it's flush to the side of the receiver.
18. Install the safety by putting in the detent and detent spring, then sliding into the left side and aligning the detent slots. Side the right lever onto the lever cylinder. The lever should look identical on both sides.
19. Put the firing pin pusher pin assembly into the hole with the large cylinder up. Place the firing pin block over the pin pusher. Rotate the trigger bar under the firing pin block. Screw the countersunk screw into the M3 tapped hole with an appropriate hex key until very tight.

**Pro-tip**: You may use low strength loctite on the rear pin block hex screw to ensure that the screw stays in place under heavy firing load. I found I began to get issues after 470 rounds of rapid fire because the screw got loose. I say low strength because Beretta used red loctite on the screw into the rear metal block originally, causing many U22s to become impossible to disassemble from a combination of a shallow and wide flathead slot. This is why MidwestGunworks sells hex head versions of this screw.

### Installing the barrel nut
20. Screw and install the barrel nut retainer and hold the barrel nut in place, then stick the grip in place, making sure to align the front two angled thingies that stick out of the trigger guard. The front thingy catches onto the receiver like an extractor and needs a thin flathead screwdriver to push off and remove if needed later. 
21. Use the grip screw to hold the grip in place, it should attach firmly into the ejector but not too firmly. If it's too tight the mag catch will get stuck and not work for some reason.

- **Pro-tip**: Test the mag catch and insert the magazine. If the mag is tight, use a round file on the front of the magwell *of the receiver* and not the grip, until it's loose again. The magazine should be able to launch itself out when empty with the slide catch installed and on a closed slide.

### Installing the slide and barrel
22. Slide the firing pin spring over the firing pin and slide it into the firing pin block. Slide the recoil spring over the firing pin spring and slide the slide on. Hold it back with the slide catch. Resist the urge to use the firing pin as a steel nerf dart, yes it will fire like this.
23. Place the barrel band on the barrel, screw the barrel band on.
24. Place the top rail on top of the barrel band and screw in the front screw so that the rail is flush to the barrel. Then insert and pin the rear sight assembly with one of the roll pins.
25. Once the rear sight is in, the middle holes of the barrel band should be aligned. Insert the pins into the appropriate holes then screw in the back rail screw. 
26. Place the barrel assembly onto the frame and screw the barrel screw until it't tight, then screw down the retainer. The barrel nut should have very little play.
27. Perform one last full function test- if your pistol passes, it is now ready for use. Congratulations. 

- **Amateur-tip**: Technially, only one middle barrel band pin is needed. Position probably doesn't matter but the rear hole is the best option since the rear sight pin isn't firmly aligned from needing to move for various sight adjustment.
- **Pro-tip**: The Beretta U22 can be dry fired safely due to the firing pin design. Pull the slide as far back as possible and you'll see it doesn't go past the circular breach face.

## Change Log

- v1.0.3: Assistance from DBFirearms accepted
	* recontoured and slightly extended rear of frame to line up with grip module
	* recontoured front of frame to line up with grip module
	* recontoured bottom of frame to line up with grip module
	* Mirrored front takedown part of frame to reflect oem with ratchet mech on left of frame instead of right.
	* Adjusted the ratcheting wheel/detent mech to function by locking in when button is not depressed
	* shrunk cavity for ratcheting wheel to reduce slop a little
	* Created recess for takedown lock button to tighten into
	* Moved recess for grip module latch to create better retention of grip module.
	* removed fillets from bottom of frame to better line up with grip module
	* Adjusted hole for grip module screw to better line up with ejector screw hole
	* Moved pin hole for ejector pin slightly to prevent ejector from tilting down after installation
	* Moved material forward around barrel to meet barrel face without a gap

- v1.0.2: Private testing feedback 1
	* Changed safety hole to give more room
	* Added spring hole for the barrel nut retainer screw (author notes:"THERE WAS A SPRING???")
	* Readjusted safety detent slots
	* Adjusted filets on beavertail
	* Lengthened rear pin block screw hole 
	* Removed non critical hole for barrel nut screw
	* Extended Barrel nut retainer tolerances

- v1.0.1: Pre-release 1
	* Adjusted trigger pin hole to fix dangerous delayed trigger response after extended firing sessions. After extended firing, the trigger would be unable to release the firing pin even when the trigger is fully pulled, and random movement or chance would drop the striker.
	* Adjusted trigger sidewall width to reinforce right side to prevent possible trigger pin hole eggholing

- v1.0.0: "Full release"
    * Original development progress was not written down besides in the developer's head.
	* Includes railed and unrailed versions.

## License
This file package is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0).
