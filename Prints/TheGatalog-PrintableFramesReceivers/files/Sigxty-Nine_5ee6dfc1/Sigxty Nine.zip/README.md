# Sigxty Nine
A 3D Printable frame for the P226, P228, P229, and P229-1

by UberPoor

## Description
A 3D printable series of frames with printable side panels and backstraps.

## Variants
- **P226** - Fullsize P226 compatible frame available with or without pic rail
- **P228/9** - Compact P228 or P229 frame available with or without pic rail
- **P229-1** - Compact P228 or P229 frame that is compatible with P229-1 magazines, available with or without pic rail

## Materials Required
Please follow the included Assembly Guide PDF for material manifest

## Instructions
Please follow the included Assembly Guide PDF for printing and assembly instructions

## Pedigree
The following models/geomtry were referenced in the development of this project:

* P228 Solid model
* P229-1 geometry provided by testers


