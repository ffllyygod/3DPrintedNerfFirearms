The Amigo Grande
v0.9

	The Amigo Grande is a 3D printable CETME C receiver. It is compatible with G3/PTR91 parts, but was designed around the large number of CETME C kits that are avaliable - some minor fitting may be required with G3 or PTR parts.
	Version 0.9 is the initial release of the Amigo Grande. Later versions will bring aestetic changes/remixes and more options, as well as any updates to documentation (FAQs and such) that are required.

	At the core of the Amigo Grande's design is its press-fit clambshell barrel mount - a simple, effective way to securely and rigidly attach the barrel and trunnion to the receiver, which allows the Amigo Grande to rival the accuracy of factory-built CETME C rifles.

	The Amigo Grande has been tested extensively in a wide variety of tests by several testers (700+ rounds total endurace, heat vs accuracy tests, 300yd shooting, different sorts of ammo, etc). Minimal viability testing was performed on 20% infill receiver - which held up to 80 rounds with zero issues. By all means, the Amigo Grande is overbuilt - but this helps make it safe.
	However, because of the nature of roller delayed guns (especially ones firing full-power rifle cartidges), making mistakes during assembly (especially when it comes to pressing and pinning the barrel into the trunnion) can result in an unsafe build.
	For this reason, the instructions for this build are made to be as clear and useful as possible. They are overly detailed, long-winded, and probably boring - but they should not be ignored, as assuming you know better than the instructions could might end poorly.

	If you have doubts, remember that you can always fire remotely. Exercise good judgement, don't shoot prints that exhibit signs of underextrustion or excessive warping.

	When it comes to selecting the proper scope/optic for your build, please refer to the "Treatise on Optic Selection" section of the build tutorial pdf.


Printed Parts Checklist:

	(Note that the "Remixed Parts" folder has some variants of these parts, if you'd like to change the look of your build. The PSG-Style handguard looks really cool!)
	
	Front Receiver
	Rear Receiver
	Handguard/Cocking Tube
	Barrel Mount Left - Refer to page 6 of the build tutorial to determine which sytle of mount you need to print.
	Barrel Mount Right - Refer to page 6 of the build tutorial to determine which sytle of mount you need to print.

Hardware Checklist:
	
	Refer to the "Shopping List" section of the build tutorial pdf.


General Print Settings:

	This receiver has been tested to work well in eSun PLA+. In any material similar or superior to PLA+, this receiver should work as well.

**Note that all STL files are oriented and scaled properly, and changing their scale or orientation may result in your parts not fitting/working properly. Especially with parts like the barrel mount and receivers, orientation is important!**
**Some cooling settings/filaments may cause the end of the handguard to warp slightly towards the end. This is generally acceptable, and will not negatively effect function. If warping seems extreme, reduce cooling settings/print speed.**
**Note that you should follow these print settings in order to get the best possible results - changing nozzle size or layer height may cause you to have to hand fit things!**

My print settings for PLA+ were as follows:

	Walls: 8 (Very important to set walls to 8 - you should be able to go higher, but going lower will signifcantly weaken the flanges that mate the receiver sections)
	Nozzle: 0.4mm
	Layer Height: 0.15mm
	Temp: 230/60C
	Infill For all part except rear receiver: 50% (If printing in flexible materials you should bump this up a little. Printing at 100% fill with PLA tends to just waste a lot of filament, but you can do so if you wish. This receiver is thick to reduce flex, and gets the strenght it needs from having 8 inner and out walls - 50% infill offers all the required stiffness)
	Infill For rear receiver: 100%. This can be printed at 50%, but in order to help this part be strong enough to withstand recoil when the gun isn't held tight into your shoulder, printing it at 100% is ideal.
	Supports: On/full (tree supports are ok)
	Cooling fan: 20% normal, 50% on bridges. Off for the first 20 layers. Keep the fan low to prevent warp.
	Bed Adhesion: gluestick or hairspray - since the big sections of this print have small footprints on the bed, using plenty of gluestick or hairspray is recommended.

	All other settings can/should be left as default or whatever you know works best with your printing setup.


Notes on printing barrel mounts:

	The barrel mounts for the barrel/trunnion in this build can be printed in more heat resistant materials to extend the number of rounds you can shoot between cooling breaks.
	Most testing of barrel mounts has been done with PLA+ - I would avoid printing the barrel mounts in any material that is less heat resistant than PLA+.
	In PLA+, the barrel mount can survive repeated (at least 6) 20 round dumps if allowed to cool between dumps *WITH ZERO LOSS IN ACCURACY*.
	If pushed to 40 rounds dumped, PLA+ barrel mounts may exhibit loss of accuracy if the barrel is torqued while things are still hot - for example, dumping 40 rounds then leaning the gun against a wall by its barrel can cause a shift.
	PLA+ mounts will work to 60 or 80 rounds, but accuracy will start to suffer and even after cooling accuracy will still be poor - groups may still be around 5" at 100 yards, but point of impact will have shifted. If you ever dump more than 40 rounds without a break on a PLA barrel mount, I reccommend you replace it - the documentation covers how to do this.
	Finally, testing has been done where a thin layer of RTV gasket maker is applied to the inside of the barrel mount to provide a heat barrier between the trunnion and mount. Testing shows that this barrier will reduce the loss of accuracy at 40 rounds dumped to zero. So while it isn't required, it seems to be quite helpful.
