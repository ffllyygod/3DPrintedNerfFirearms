# Triton 9 
The Triton 9 is a clamshell style PCC that takes glock mags. 

by DB Firearms

## Description
The Triton 9 is a 9mm pistol-caliber carbine (PCC) based on the FGC-9 V2, designed to incorporate Riptide Rails’ bufferless bolt. It shares several components with the FGC-9 V2, including the barrel, feed ramp, magazine release, and AR-15 fire control group. Additionally, it features Riptide Rails’ aluminum magazine release, aluminum feed ramp, aluminum charging handle, and brace/stock kit for enhanced performance and durability.



## Materials Required
*HARDWARE* kits available at dbdesignworks.com
- x4 M4x10mm Flat Head Screws (Handguard Retainer Screws) McMaster 91294A190
- x4 M4 Square Nuts (Handguard Retainer Nuts) McMaster 96887A329
- x2 M4x20mm Socket Head Screws (Barrel Clamping Screws) McMaster 91290A168
- x5 M4x12mm Socket Head Screws (Upper Receiver Top Screws) McMaster 91290A148
- x4 M4x35mm Socket Head Screws (Upper Receiver Front/Back Screws) McMaster 91290A182
- x1 M4x25mm Socket Head Screw (Upper Receiver Lower Clamp Screw) McMaster 91290A176
- x12 M4 Hex Nuts (Upper Receiver Clamping Nuts) McMaster 98676A200
- x1 Steel Shoulder Screw (Takedown Pivot Screw) McMaster 91259A168
- x1 8-32 Hex Nut (Takedown Pivot Nut) McMaster 96537A140
- x1 M3x16mm Socket Head Screw (Feed Ramp Screw) McMaster 91290A120
- x2 M3 Nut (Feed Ramp Nut - for printed feed ramp only & takedown latch) McMaster 90592A085
- x1 M4x26mm Dowel Pin (Mag Catch Pin) McMaster 91595A175
- x1 Compression Spring .75" Long (Mag Catch Spring) McMaster 9657K286
- x1 Compression Spring .375" Long (Takedown Latch Spring) McMaster 9657K622
- x1 M3x20mm Button Head Screw (Takedown latch Screw) McMaster 92095A185
- x1 M5x25mm Socket Head Screw (Grip Screw) McMaster 
- x1 M5 Square Nut (Grip Screw Nut) McMaster

*Optional Brace/Stock Hardware* Kits available from Riptide Rails
- x4 M3x15mm Button Head Screws (Brace End Attachment Screws) McMaster 91239A811
- x4 M3 Hex Nuts (Brace End Attachment Nuts) McMaster 90592A085
- x1 M5x30mm Socket Head Screw (Rail Lock Screw) McMaster 91290A254
- x1 M5 Nut (Rail Lock Nut) McMaster 94166A120
- x1 M2x10mm Dowel Pin (Button Retainer Pin) McMaster 91595A026
- x1 Compression Spring (Button Spring) McMaster 9657K623
- x2 Laser Cut Bars (DXF in Files) 
- x1 Laser Cut Locking Piece (DXF in Files)

*Other Components*
- x1 AR FCG (Hammer, trigger, disconnector, springs)
- x1 AR Safety Selector (Prefer Ambi) with Spring and Detent
- x1 Riptide Rails Charging Handle https://riptiderails.com/riptidecharginghandle
- x1 FGC9 Dedicated Barrel https://parts-dispensed.com/home/163-740-fgc-9-threaded-barrel#/155-barrel_options-standard 
- x1 Feed Ramp - Standard (Can Be Printed) https://riptiderails.com/FGC-9-MK-II-Feed-Ramp--Aluminum_p_101.html
- x1 Aluminum Mag Catch (Can Be Printed) https://riptiderails.com/fgc9magcatch
- x1 Riptide Rails Bolt https://riptiderails.com/riptide-fgc-9-mkii-enhanced-bolt-.html
- x2 Reinforcement Plates (Optional, can print version w/o) https://riptiderails.com/fcg-reinforcement-plates-w-awpins
- x1 Glock 9mm patterned magazine. 


## Printing Instructions
1. Load all files into your 3D printing slicer and print them in their default orientation using PLA filament. All files have been oriented and scaled properly. If using a specialty filament like nylon, rotate the model to a 45-degree angle for better results.  

2. Choose PLA+ or a stronger filament. Do not use PETG or silk filaments. Set your printer’s temperature as high as possible without losing accuracy, around 220°C (check your filament’s recommended settings).  Use cooling to prevent warping. The bed temp  should be set to around 60°C or whatever your filament recommends.

3. Use a layer height of 0.2 mm or smaller to capture the detailed geometry around the charging handle.  

4. Select a 0.4 mm nozzle to ensure precise parts, as the design includes 0.2 mm clearance for moving components.  

5. Enable FULL organic tree supports in your slicer, but block any supports for the charging handle area to avoid issues with small details. If you don't, there is a high probability that the charging handle will be difficult to use.

6. Use a strong wall/infill combination. 8 walls with 100% infill is the suggested combination.

7. These are print suggestions. If you have a better print profile, please use it. However, do not alter the print orientation of the model unless you know exactly what you're doing. Otherwise, you could experience print failures related to the design.

## Assembly Instructions
1. Upper Receiver (Barrel Installation): Test-fit the barrel into the left upper receiver half. It should fit tightly and will be secured when the receiver halves are clamped. Gently press the barrel into place by hand.

IMPORTANT: use a dab of blue thread locker on all fasteners on this build. Allow fasteners to cure for 24 hours before firing. Check your screw tightness after 100 rounds to verify no screws have come loose.

2. Rear Takedown Latch: Assemble the latch using its two pieces, bolt, and nut. Slide the spring onto the shaft, then position the latch at the rear of the left receiver half, ensuring the spring is compressed in its channel.   

3. Receiver Assembly: Align the right receiver half with the left, ensuring the latch spring is compressed into the right receiver’s channel. Press them together. There will be a gap at the front around the barrel. Secure the halves with the provided screws and nuts, tightening gradually and evenly to clamp the barrel without stressing the plastic. Insert your 4 M4 square nuts into the front handguard slots.

4. Handguard Installation: Slide the handguard onto the receiver’s front and secure it with the 4 M4 flat-head screws.

5. Test Takedown Latch: Pull the latch handle to check spring function. It should return to the closed position. If it sticks, apply lubricant (e.g., PTFE dry lube) to the latch shaft and work it manually until smooth.
 
6. Lower Receiver (Feed Ramp): Attach the feed ramp to the front of the lower receiver using its screw and nut. For an aluminum feed ramp, omit the nut.

7. Fire Control Group (FCG): Install the FCG as you would on an AR-15. If using reinforcement plates, secure one side of your anti-walk pin with the screw, and install to capture the reinforcement plate. Once all pins are installed, test the trigger for smooth operation. If binding occurs, slightly loosen the anti-walk pin screws. Apply blue Loctite to secure the screws.  

8. Safety Selector and Grip: Install the safety selector, detent, spring, and grip. Tighten the grip screw until snug, then add a quarter-turn. Avoid overtightening to prevent damaging the lower receiver.  

9. Magazine Release: Insert the magazine release button (long rod looking pice) into the lower receiver, then add the spring into its channel. Install the magazine release lever and secure it with its pin. Test magazine retention by inserting and removing a magazine. 

10. Connect Upper and Lower Receivers: Attach the lower receiver to the upper using the shoulder bolt and nut at the front. The nut should tighten against the bolt’s shoulder, allowing the lower to pivot. Press the lower into place at the rear until the latch secures it.  

11. Charging Handle: Insert the charging handle into the upper receiver. If tight, lightly sand the channel (after confirming all supports are removed). Attach the second handle piece with its bolt, then move the handle fully forward. Test for smooth operation, applying a small amount of PTFE dry lube if needed. Work the charging handle back and forth until you are satisfied there is no binding. 

12. Bolt Installation: Install your stroke limiter onto your bolt at this stage. This acts as a short stroke buffer limiting the travel of the bolt and improving the shooting experience. This slides upwards onto the bolt in front of the recoil pad after pulling out the ejector rod, then reinserting the ejector rod. Once installed, the bolt is ready to be added to the Upper Receiver. With the charging handle fully forward, place the bolt’s rear into the upper receiver, gently compressing it to pivot upward into position. Secure the lower receiver with the latch and test bolt movement.  

13. Optional Brace/Stock Assembly: Attach the metal bars to the brace/stock sides, with notches facing up, using four M3 screws and nuts. Slide the bars into the collapsible back piece, working them until smooth. Align a bar notch with the side slot, then install the locking piece as follows:
---Slot the spring retainer onto the locking piece.  

---Place the spring in the back piece’s channel.  

---Use the install tool to compress the spring and slide the locking piece into place, ensuring the spring retainer secures it.  

---Insert the button (divot facing out) and secure with the dowel pin. Test the locking mechanism.  

---Attach the brace/stock to the upper receiver’s rear with an M5 screw and nut.

14. Final Testing: Always test the assembly with snap caps to verify proper feeding. Never function check with live ammunition! Place a magazine with snap caps into the magwell. Pull the charging handle back until it reaches the rearward end of travel. Release the charging handle (DO NOT RIDE IT HOME). This should chamber a snap cap. Check safety selector and trigger function. Pull charging handle to eject snap cap. If all functions pass this test, the firearm is ready for use.

## Troubleshooting Guide

1. Charging Handle is binding: This can happen if there are leftover supports in the charging handle channel. The key here is understanding that you may have to clear these channels out a little bit. An angled pick is a great tool to scrape the channel a little bit. Another tip is to use some oil in the channel then rack the bolt around 50 times to wear in the plastic to the charging handle.

2. Takedown Latch disconnecting during live fire: The latch is designed for quick takedown for cleaning and inspection. However, it was reported during the beta that one user had issues with the latch staying closed. This was not an issue for the majority of beta testers. After first verifying that your latch is closing all the way, and all support material is removed, test again.  If you still experience this, you can print the supplemental non-sprung latch in the files supplemental folder. This will change it from a spring latch to a latch that closes with a screw and nut. 

3. Feeding Issues: The build was tested successfully with OEM Glock magazines, and menendez V3 magazines with metal feed lips. https://riptiderails.com/Menendez-Magazine-v30-Build-Kit_p_134.html Other issues may occur with aftermarket magazines. Verify your feed ramp is not damaged and try switching to an OEM magazine. 

4. The bolt is very difficult to remove: To remove the bolt, pull the charging handle to the rear with your left hand, and use your right hand to grip the front face of the bolt and pull it down. It should now pivot out easily. 

## Change Log

- v1.0: Initial Release

## License
Creative Commons License Share Alike NON Commercial
