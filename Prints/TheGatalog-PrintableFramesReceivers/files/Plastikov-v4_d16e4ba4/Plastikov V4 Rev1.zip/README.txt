Plastikov v4

	The Plastikov v4 is a 3D printable AKM-based build. It departs from traditional AK receiver design, and prior versions of the Plastikov, by adopting an enclosed receiver design.


Printed Parts Checklist:

	REFER TO THE MAIN BUILD DOCUMENT
	
Hardware Checklist:
	
	Refer to the "Shopping List" section of the build tutorial pdf.


General Print Settings:

	This receiver has been tested to work well in eSun PLA+. In any material similar or superior to PLA+, this receiver should work as well.

**Note that all STL files are oriented and scaled properly, and changing their scale or orientation may result in your parts not fitting/working properly.**
**Some cooling settings/filaments may cause some parts to warp slightly. This is generally acceptable, and will not negatively effect function. If warping seems extreme, refine cooling settings/print speed.**
**Note that you should follow these print settings in order to get the best possible results - changing nozzle size or layer height may cause you to have to hand fit things!**

My print settings for PLA+ were as follows:

	Walls: 8 walls recommended
	Nozzle: 0.4mm
	Layer Height: 0.15mm
	Temp: 230/60C
	Infill: Ideally 100% - though if you use 8 walls you can use lower infill if desired
	Supports: On/full (tree supports are ok)
	Cooling fan: 20% normal, 50% on bridges. Off for the first 20 layers. Keep the fan low to prevent warp (this is a guideline, your settings may vary).
	Bed Adhesion: gluestick or hairspray - since the big sections of this print have small footprints on the bed, using plenty of gluestick or hairspray is recommended.

	All other settings can/should be left as default or whatever you know works best with your printing setup.

NO IMAGES, INSTRUCTIONS, DOCUMENTS, NOR ANY AOTHER FILES LICENSED FOR COMMERICAL USE, SUBSCRIPTION DOWNLOAD, OR ANY PAID DISTRIBUTION WHATSOEVER.
COPYRIGHT 2024
