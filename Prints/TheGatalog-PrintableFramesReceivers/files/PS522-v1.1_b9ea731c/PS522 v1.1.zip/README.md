# PS522

Pond Side 522, a printable reciever for the Sig Sauer 522

by nguyenkvvn

## Description
The Sig Sauer 522, now mostly forgotten and long abandonded .22LR platform mimicking the look and feel of its bigger brother (the Sig Sauer 556), returns as the "Pond Side" 522 (PS522). The PS522 is easy to assemble, and is particularly conservative on its use of plastic. It uses all original parts from the 522, except for the manual bolt-hold open.

## Materials Required
Please see Assembly Guide PDF for materials and tools required.

## Instructions
Please see Assembly Guide PDF for assembly and printing instructions.

## Change Log

- v1.1: Public Release 1.1
    * Added PDF assembly guide
    * Centered and aligned the picatinny side plates

- v1.0: Public Release 1
    * Inserted link to video assembly guide

- v0.3: Public Beta Candidate 2
    * Added side panels

- v0.2: Public Beta Candidate 1
    * Addressed minor rear-fitment issue
    * Added aesthetic enhancements to blank face of reciever

- v0.1: Private Beta Candidate
    * Initial commit

## License
No license specified.
