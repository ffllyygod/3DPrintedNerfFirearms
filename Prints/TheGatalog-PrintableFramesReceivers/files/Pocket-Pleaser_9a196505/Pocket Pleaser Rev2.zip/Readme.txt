The Pocket Pleaser: A Ruger LCP (GEN 1) 3D Printed Frame

By: Kukitan (AKA you're favorite cabbage - Kapusta)

A 3D printed frame for the Ruger LCP family of pocket pistols (GEN 1 Currently - More Supported in the future). This combines the frame and frame insert into one 3D printed component, giving us a strong enough platform to make a printed LCP viable.

Required Tools & Materials:
 - Pin punch set
 - Gunsmith Hammer
 - Thin needle nose pliers or tweezers
 - Small head Phillips screw driver

 - x1 LCP Parts Kit (No Gen 2 or Max kits! Not compatible yet)
 - x1 Rail Insert (https://kabbagepatch.myshopify.com/products/pocket-pleaser-rail-insert) or (https://linktr.ee/Kukitan)
 - x1 5/16" #4-40 Machine Screw (Phillips)
 - x1 1/4" #4-40 Machine Screw (Phillips)
 - PLA Plus/Pro or equivalent filament

How To Print:
 1. 0.16 Layer Height (0.2 will be fine, but this was designed for 0.16)
 2. 3 or more walls with 100% infill, 220C more more hotend temp, tree supports recommended
 3. Print frame nose down with trigger guard and front of grip touching build plate (default file orientations)
 4. Rest of files are default file orientation

See Assembly Guide PDF for detailed assembly instructions, and starter guide for more information on each section. 

	Happy testing and stay safe!



Changelog:

2-3-25
	-Reinforced frame in more spots
	-Proper slicer orientation
	-Updated guide with new part recommendations and print settings
	-Open Beta Time!!!

8-16-24
	-Updated guide and new assembly/disassembly video are linked on last page. 
	-Fixed issue with geometry in magwell near magazine feed lip location. The magazine's swell outward a little during feeding and the magwell being too tight causes too much friction. Better feeding now!
	-Mags sit a tad bit higher now to also aid in feeding.
	-Mag catch position adjusted so that mags click in easier and dont need to be forced in like in the case of the Promag magazines.
	-Some extra thickening in the rails area for added strength.

8-11-24
	-New side plate mounting system. No more screws! Slots in from the top following the grooves and is held in place when slide is installed. Still keeps flex to a minimum!
	-Improved geometry in the cavity where the trigger sits. Added some material behind the trigger, on the frame, to act as a trigger stop.
	-Butt plug improved look and installation. Use the ________________ screw for installation from the top.
	-Made cuts in magwell that'll still keep mags tight but reduce friction for those with snug fits...hopefully. So far my Promags run better in this revision.
	-Trigger Stop insert for those with a longer legged trigger bar. Glue it in if you want it to be more permanent. Shorter Legged trigger bars don't need this insert. If you're not sure which you need, try without it first and see if you get proper function.
	-Smoothed out the rear of the grip so it sits in your hand nicer. More pleasant to hold!


7-27-2024
	-Adjusted magwell angle a touch. Promags should feed a little better now. ProMags still suck though...
	-Thickened up areas in the frame that I missed.
	-Added some fillets at bottom of magwell for a nicer feel
	-Flared magwell a little bit, tacticoooooooool
	-Fixed an oopsie I noticed on my last range trip. Weird bit of geometry was hanging up the hammer sometimes on my older style LCP kit.

7-21-2024
	-Updated magwell and grip geometry to improve ergos. Removed some hard edges so it feels nicer to hold and shoot. Magazine to frame fit improved. Nicer transition between the two now. This was a very nice feeling change!
	-Thicker side panel is now default with the text. Love how it feels now!
	-Opened up slide lock cavity a bit so it moves easier.
	-Updated some lines on the frame, getting model ready for grip texture!
	-Thickened some internals so that some of the thinner portions near the rails are reinforced.
	-Removed hole in the left size of the frame for the trigger pivot. Can remove the pivot now without needing to jam a punch to it, and removing the hole gives us back some needed strength in that area.

7-7-2024
	- Adjusted trigger guard thickness. A bit more chonky but adds rigidity still tweaking.
	- Adjusted catch/trigger bar position. The Gen 1 LCP seems to have 2 different styles of trigger bar. The older style has a shorter leg and the newer one is longer. 
	  New potion is a compromise between the two. Newer style bar will feel better but both work. May make 2 frames at release that are optimized for both styles. So far the trigger bar is the only noteworthy difference that can affect function.
	- Adjusted magwell dimensions to give frame a tiny bit more strength in thinner areas. Also moved mag catch slightly so both OEM and aftermarket fit better. MAGS WILL ALWAYS BE A BIT LOOSE! Just a Ruger design "feature" at this point lol
	- Adjusted alot of ofter small dimensions to improve overall feel of the action.