
    ____  ____     ______________  _________    ____  __  ________
   / __ \/ __ )   / ____/  _/ __ \/ ____/   |  / __ \/  |/  / ___/
  / / / / __  |  / /_   / // /_/ / __/ / /| | / /_/ / /|_/ /\__ \ 
 / /_/ / /_/ /  / __/ _/ // _, _/ /___/ ___ |/ _, _/ /  / /___/ / 
/_____/_____/  /_/   /___/_/ |_/_____/_/  |_/_/ |_/_/  /_//____/  
                                                                  

## Legal Notice & Compliance Statement

DBDESIGNWORKS is a sole proprietorship based in and operating under the laws of the State of Idaho, USA.

These 3D-printable files are provided **exclusively for lawful personal use** by individuals who are:
- Not prohibited from possessing or manufacturing firearms under federal law (including 18 U.S.C. § 922(g)), and
- Fully authorized under all applicable federal, state, and local laws in their jurisdiction of residence to manufacture firearm components or complete firearms.

**These files are not intended for, and are not offered or distributed to, residents of any state or jurisdiction where the possession, manufacture, download, or use of these files is prohibited or requires a specific license that the user does not possess.** This includes, but is not limited to, the State of California.

By downloading, accessing, or using any file from this repository or website, you expressly represent and warrant that:
1. You are a law-abiding adult in full compliance with all federal, state, and local laws governing firearms and firearm-related items in your jurisdiction.
2. You are not located in, and will not use these files in, any jurisdiction where such activity is illegal.
3. You will not distribute, share, or sell these files in violation of any law.

**DB Design Works complies with all applicable federal and Idaho state laws.** We make no representation that these files are legal in your specific state or locality. It is solely your responsibility to determine the legality of these files, to verify your own eligibility, and to ensure full compliance before downloading or using them.

These files are provided **"AS IS"** without any warranty, express or implied. DB Design Works disclaims all liability for any loss, damage, injury, or legal consequence arising from the use or misuse of these files. Any unlawful use is strictly prohibited and is a violation of this notice.

If you are unsure whether you may legally download or use these files in your jurisdiction, do not download them.


++++++++FNS 9/40 Full Size Frame by DB Firearms++++++++


This frame is designed to turn your FNS 9/40 parts kit back into functional firearms. YAY! This is for now only for the Full Size (and long slide) models and I don't have plans to support the compact frames or magazines.
This frame was loosely based on the gatalog release of the TMS-FNS. Thanks to the original developers for the hard work on that frame. Many things have been changed and I did end up completely starting over, only using small pieces of those original frames on this one. 


There are 2 styles of frames in the files. Textured, and Blank. If you prefer to add your own texture, the blank STL should provide that jumping off point.

NOTES ON MAGAZINES: The FNS and 509 magazine bodies (9mm) are the same and will both lock into either frame. However, the baseplates are different. The FNS frame was designed around the FNS baseplate and the 509 was designed around the 509 baseplate. 509 mags will lock into the FNS frame but FNS magazines will not lock into the 509 frame without swapping baseplates.  

NOTES ON FINDING KITS: There are two main sources for kits that will vary daily and weekly. 
1. Gunbroker search: "FNS Repair parts" or "509 Repair Parts". There are weekly auctions that end on sundays and kits will often appear there weekly. 
2. Everygunpart: This company will have inventory that fluctuates daily. If you are searching for a kit, it's best to look often. https://everygunpart.com/?acc=ad1288236b3a6b1d28115a1f92ab8bb6 (This is an affiliate link. I get 10% in credit back if you use it. Use code REFSV2648 for 10% off)

IMPORTANT INFO, LOCKING BLOCK PIN: The FNS and 509 locking block pin is one of the dumbest designs ever. It is a tapered pin that is seemingly impossible to remove. Instead of re-installing it, I would suggest replacing it with a roll pin that is similar in diameter and length. Harbor Freight sells a roll pin kit that has a bunch of sizes. Or, you can get this one but it's over-priced: https://www.apextactical.com/unlocking-block-pin-set-forfn-509-fns-c-pistols


PRINT ORIENTATION: 
-All frames have been pre-oriented in their ideal print orientation(Rails Down, upside-down on build plate). If you are printing in a Nylon based filament, you may choose to rotate it 45 degrees. 

PRINT SETTINGS: 
-Frame should hold up fine in PLA+ as it's rather thick. However, be cool and print in this filament and your frame will last long time: https://amzn.to/3MP8L12
-Print on the hotter side to ensure good layer adhesion. PLA+(220c)
-No raft or brim needed unless you have difficulty with build plate adhesion
-Use Organic Supports

ASSEMBLY INSTRUCTIONS: 

HELPFUL TOOLS
- Needle files, sandpaper (various grits), deburring tool
- Roll-pin punch set and small hammer
- Small pick or dental pick
- Bench block or soft-jaw vise
- Calipers
- Gun oil / grease

1. Magazine Catch
Test-fit the magazine catch.
- File or sand the frame slot until the catch slides smoothly without binding.
- Install the Z-style magazine catch spring from the TOP of the frame into the rectangular gap in the catch. Center it so spring pressure holds it in place.
- Test with a magazine: it must lock securely and drop freely when released. Adjust filing or spring position if needed.

2. Rear Sear / Trigger Assembly (Sear Housing Block)
This sub-assembly often comes apart and must be correctly rebuilt.

Reference Video (works for both FNS and 509):
https://www.youtube.com/watch?v=6k0mqYeOn4s

3. Install Sear Assembly + Trigger and Trigger Bar
- Make sure the sear cage retaining clip is securely in place.
- Attach the trigger and trigger bar to the lower pivot pin on the sear assembly.
- Carefully drop the complete unit into the frame. The pocket for this at the back of the frame is designed to be a tight fit.
- Verify the trigger bar is correctly routed and nothing is binding.

4. Install the Slide Stop (Slide Catch) Lever
Insert the slide stop lever by dropping it in from the top. It should seat cleanly. File the channel lightly if it is tight.

5. Install the Slide Stop Spring
- The two small loops face forward (toward the muzzle).
- The long leg faces rearward, rests on top of the slide stop lever, and should be angled slightly downward.
- Confirm proper orientation and tension.

6. Install the Locking Block
Multiple parts (trigger bar, sear, etc.) must nest inside perfectly.

- Lower the locking block straight down into the frame.
- Look through the pin holes to verify nothing is misaligned or pinched.
- Do NOT force it. Realign parts if there is resistance.

7. Install the Sear Retaining Pin (Fire Control Pin)
This is a roll pin.

- Support the frame well (use jig or bench block).
- Gently drive the pin through until it is centered.
- Caution: 3D printed frames crack more easily than factory frames. Use light taps only.

8. Install the Trigger Pin
- The grooved end goes in first, inserted from the RIGHT side of the frame.
- Route: through slide stop → trigger → slide stop spring → slide stop again → out the left side.
- Use a pick if needed to help the spring leg seat into the groove for retention.

9. Install the Locking Block Retainer Pin
- Factory tapered pin installs left to right only. It's terrible to install. 
- Recommended Upgrade: Replace with a properly sized roll pin for easier future disassembly. See previous comment for more details.

CAUTION: Excessive force can split the frame around this area.

10. Install the Takedown Lever
- Press the takedown lever into its slot.
- Use a small pick to guide the short forward leg of the slide stop spring into the retaining groove on the lever.
- Rotate the lever to the 6 o'clock position (straight down).

11. Install the Complete Slide Assembly
Ensure the slide is fully assembled (barrel, recoil spring, striker, etc.) first.

- Align the slide rails with the frame rails and slide it on.
- Pull the slide fully rearward and lock it open using the slide stop.
- Rotate the takedown lever counter-clockwise (upward) to lock the slide onto the frame.

12. Thorough Function Check (Unloaded + Snap Caps Only)
Perform these checks before live fire:

- Magazine insertion, lock, and drop
- Slide stop operation (locks back on
Perform a final visual inspection, then proceed to range testing at a safe location.  


Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself. 

https://dbdesignworks.com
