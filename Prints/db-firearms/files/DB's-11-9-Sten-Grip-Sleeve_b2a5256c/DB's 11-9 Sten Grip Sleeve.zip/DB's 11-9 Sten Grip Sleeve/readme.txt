DB Firearms Presents: 

DB's 11/9 Sten Grip Sleeve

Compatibility: This is expected to fit on Mac 11/9 lower receivers that use Sten style magwells. These are most commonly produced by Velocity Firearms.
It may fit other frames but is untested on them.

There is also an extended magazine release that is compatible with Sten magazines, MPA Polymer magazines, and ProMag magazines. 

NOTE: promag magazines designed for MPA Defender 9mm will work but the sides need to be sanded to fit the magwells. 
----------------------------------------------------
Print Instructions: Print them as the files load in your slicer. The sleeve is upside-down. The mag release is on its side. 
----------------------------------------------------
Materials: Tested in PLA+ and NylonX. This will work fine in PLA+ but it's suggested to print in a nicer filament for longevity. It's a grip!
----------------------------------------------------
Hardware: You can use the factory flat head grip screw to install it, however, it will need to be sanded down. WHY? Well, ergonomics. 
I made the grip as thin as possible which meant that I had to remove some thickness where the grip screw goes. So it needs to be shorter.
Grip screw length needs to be about 9mm. You can install the grip screw and feel inside the magwell to see how much to remove. Remove material until
the screw no longer protrudes into the magwell.

Regarding the mag release pin, you can use the roll pin from the oem mag release. however, it also needs to be cut down. I suggest using M3x16mm pin
to make it look nicer. I install the pin by reaming it first to fit the pin. Do not force it or it will crack. 

Regarding the mag release spring - use the factory one 
----------------------------------------------------
Installation: 
Begin by removing your factory rear grip extension. There should be a flat head screw in the back. Once removed, also disassemble the mag release to retreive the spring.
Slide the printed grip sleeve in place. It should be snug but not too tight. However, these grips all vary in thickness so yours may be looser or tighter than mine. 
You can now install the rear screw that has been modified as suggested above. 
Lastly, install your spring and magazine release, ensuring that the magazine release overtravel tab slots up into the grip and is held in place. You can choose to install
your factory magazine release instead of the extended one if you'd like. however, the extended one is much easier to manipulate. 
Now, you can install your mag release pin to keep the release in place. Test with an empty magazine to ensure the magazine locks into place. 

DONE. 

Please share your prints on social media and tag me - especially on x/twitter. 

License: Creative Commons share-alike NON COMMERCIAL
DB Firearms USA