
    ____  ____     ______________  _________    ____  __  ________
   / __ \/ __ )   / ____/  _/ __ \/ ____/   |  / __ \/  |/  / ___/
  / / / / __  |  / /_   / // /_/ / __/ / /| | / /_/ / /|_/ /\__ \ 
 / /_/ / /_/ /  / __/ _/ // _, _/ /___/ ___ |/ _, _/ /  / /___/ / 
/_____/_____/  /_/   /___/_/ |_/_____/_/  |_/_/ |_/_/  /_//____/  
                                                                  

++++++++The DB Slab AR Grips by DB Firearms++++++++

These are two low poly grips for AR patterned firearms. The standard grip is longer for big hands and the mini grip is quite a bit
shorter for smaller hands or a more compact firearm. 

PRINT ORIENTATION & SETTINGS: 
-I print my grip upside down with supports on build plate. There should be a small amount of support inside the top mounting
channel of the grip. Remove and you're ready to install

Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself. 

https://db-firearms.com
