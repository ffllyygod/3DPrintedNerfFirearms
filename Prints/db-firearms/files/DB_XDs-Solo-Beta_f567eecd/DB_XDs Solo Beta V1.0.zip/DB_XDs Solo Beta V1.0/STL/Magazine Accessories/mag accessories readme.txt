Sleeves: Use the sleeve for the magazine capacity of your round, it is designed to be a tight fit on OEM Springfield magazines. There is removable material on the inside-back of the sleeve you can file down to get a snug fit.

For the +2 extension, you'll want a 3mm x 30mm screw to keep the mag body from moving back. 