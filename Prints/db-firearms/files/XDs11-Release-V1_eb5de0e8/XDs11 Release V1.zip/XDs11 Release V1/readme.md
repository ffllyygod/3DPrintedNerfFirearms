
    ____  ____     ______________  _________    ____  __  ________
   / __ \/ __ )   / ____/  _/ __ \/ ____/   |  / __ \/  |/  / ___/
  / / / / __  |  / /_   / // /_/ / __/ / /| | / /_/ / /|_/ /\__ \ 
 / /_/ / /_/ /  / __/ _/ // _, _/ /___/ ___ |/ _, _/ /  / /___/ / 
/_____/_____/  /_/   /___/_/ |_/_____/_/  |_/_/ |_/_/  /_//____/  
                                                                  
## Legal Notice & Compliance Statement

DBDESIGNWORKS is a sole proprietorship based in and operating under the laws of the State of Idaho, USA.

These 3D-printable files are provided **exclusively for lawful personal use** by individuals who are:
- Not prohibited from possessing or manufacturing firearms under federal law (including 18 U.S.C. § 922(g)), and
- Fully authorized under all applicable federal, state, and local laws in their jurisdiction of residence to manufacture firearm components or complete firearms.

**These files are not intended for, and are not offered or distributed to, residents of any state or jurisdiction where the possession, manufacture, download, or use of these files is prohibited or requires a specific license that the user does not possess.** This includes, but is not limited to, the State of California.

By downloading, accessing, or using any file from this repository or website, you expressly represent and warrant that:
1. You are a law-abiding adult in full compliance with all federal, state, and local laws governing firearms and firearm-related items in your jurisdiction.
2. You are not located in, and will not use these files in, any jurisdiction where such activity is illegal.
3. You will not distribute, share, or sell these files in violation of any law.

**DB Design Works complies with all applicable federal and Idaho state laws.** We make no representation that these files are legal in your specific state or locality. It is solely your responsibility to determine the legality of these files, to verify your own eligibility, and to ensure full compliance before downloading or using them.

These files are provided **"AS IS"** without any warranty, express or implied. DB Design Works disclaims all liability for any loss, damage, injury, or legal consequence arising from the use or misuse of these files. Any unlawful use is strictly prohibited and is a violation of this notice.

If you are unsure whether you may legally download or use these files in your jurisdiction, do not download them.


++++++++The XDS11: A Springfield XDs and 1911 Hybrid Frame by DB Firearms++++++++


These frames are designed to turn your Springfield XDs (9mm/.40/.45) parts kits back into functional firearms. YAY!
They do not use the normal XDs magazines. They require a 1911 style single stack magazine and magazine catch assembly.


There are 2 styles of frames for this release. Mod.1 is for all calibers of XDs Mod.1 kits. This will encompass the majority of kits available. Mod.2 is for all calibers of XDs Mod.2 kits. Mod.2 kits are mainly different at the front locking block area.

Both Mod.1 and Mod.2 frames have blank and textured versions. Feel free to use the blank .stl frame versions to customize your frame!
I really like this light on this frame, it fits really nicely: https://amzn.to/4vroYdB
A print all of my final frames in this filament and it's easy to print and much more robust than PLA+: https://amzn.to/4xpsebB
NOTES ON MAGAZINES AND MAG CATCHES: Any single stack 1911 magazine should fit and function in this frame. However, they are all sort of different specs with some being tighter or looser in the magwell. Also, some may require the tuning of the slide stop or magazine follower to have full functionality. You will also have to modify the magazine catch of your kit to make the 1911 magazines work. Also, you may have to file down the inside of your trigger guard if you find that the trigger bar rubs on the magazine. Some magazines are slightly thicker and do cause small fitment issues you'll need to dial in.

Any 1911 style magazine catch should work fine. Since the original tolerances for these magazine catches was in steel, there are sometimes issues with mounting them in plastic. They are just a tiny bit undersized and will need to be hand fit to operate smoothly. 

PRINT ORIENTATION: 
-All frames have been pre-oriented in their ideal print orientation(Rails Down, upside-down on build plate). If you are printing in a Nylon based filament, you may choose to rotate it 45 degrees. 

PRINT SETTINGS: 
-Frame was tested with PLA+ and proved to be very robust. 
-Print on the hotter side to ensure good layer adhesion. PLA+(220c)
-No raft or brim needed unless you have difficulty with build plate adhesion
-Use Organic Supports

ASSEMBLY INSTRUCTIONS: 

### Important Notes Before Starting
- Ensure **all support material** has been completely removed and any rough edges have been lightly sanded or deburred.
- Use a soft mallet or hammer with a plastic/brass punch when tapping parts. Avoid direct metal-to-metal strikes on the frame.
- All pins are installed from right to left unless otherwise noted.
- Work on a stable surface.

### Step-by-Step Assembly

1. **Install the Magazine Catch**  
   Begin testing fitment of the magazine catch. The left side is smaller than the right side. It is crucial that the left side is NOT reamed to the same size as the right side. The left side being smaller will retain the magazine catch. Use drill bit or small round needle file to get the magazine catch fitted correctly. it should be smooth in its hole and not have any significant resistance. There is a small cutout on the right inside for the retainer screw. Make sure no extra supports are stuck in that cutout. Then, using a small flat screwdriver, push and gently rotate the retainer screw to secure the magazine catch. Test that it functions smoothly and insert and release your magazine a few times. 

2. **Install the Sear / Trigger Assembly**  
   Push the rear sear cage (housing) into the frame, aligning the holes in the side of the frame with the holes in the sear cage.  
   Insert the rear pin from the right side and seat it fully.

3. **Modify and Install the Slide Catch (Slide Stop)**  
   Use the cutting guide photo to slightly modify the slide catch. Place the slide catch into position (the through-hole should be next to the trigger on the left side). Temporarily install the trigger pivot pin from the left side of the frame to capture the slide catch. Then, test that your cuts were successful by installing a magazine and checking that the slide catch tab is resting on the magazine follower and not contacting the magazine body at all. Once you're satisfied with fitment, remove the trigger pivot pin for now and move on to the next step.  

4. **Install the Front Locking Block / Rail Assembly**  
   Ensure the slide catch spring is properly seated in the side of the front locking block/rail combo.  
   Insert the front locking block/rail assembly into the frame. It is a snug fit — gently tap it into place with a soft mallet if needed.
   Insert the trigger pivot pin from the right side and tap it through until it is centered in the frame. You may need to wiggle around the slide catch to line it up with the pin. It will self-center in place when it's in the middle of the frame. 

5. **Install the Locking Block Pin**  
   Insert the locking block pin last. This pin is best installed from left to right. Ensure the slide catch spring leg is UNDERNEATH this pin. 
   After installation, verify that the slide catch has proper spring pressure. The leg of the slide catch spring should sit on top of the slide catch, pressing it downward. Adjust if necessary.

6. **Function Check – Magazine**  
   Insert an empty magazine. It should lock firmly into place via the magazine catch.  
   The magazine should also push the slide catch upward when fully seated.

7. **Install the Takedown Pivot Pin**  
   Insert the takedown pivot pin. You may need to rotate/spin it to clear the retaining spring.  
   Using firm thumb pressure, push it down until it snaps into place.  
   With the pivot pin rotated upward (disassembly position), install the slide onto the frame.

8. **Final Function Check**  
   Pull the slide fully rearward and lock it back using the slide catch.  
   Rotate the takedown pivot pin counter-clockwise to the locked (horizontal) position.  
   Release the slide and allow it to go forward.  
   Perform a full function check: dry-fire, magazine insertion/removal, slide lock/release, and takedown lever operation.

### Safety Reminder
After assembly, always treat the firearm as if it is loaded. Verify the pistol is unloaded before any further handling or testing. Test all functions thoroughly before live firing.  

If anything feels tight, gritty, or does not function smoothly, stop and disassemble to inspect the parts.

---
TROUBLESHOOTING: 
Magazines are hard to insert/get caught going past mag catch: The 1911 magazine catch spring is really stiff and can lead to issues when there is a small amount of binding. The magazine catch may require some break in period in the plastic frame. You can do this by hand or remove material but that's the main solution to this issue. 

Magazines don't lock back on empty: Remove slide and insert magazine. See where the slide stop lever is hitting the magazine follower. If the follower is steel, you can sometimes bend the plate upwards on it to help activate the slide stop further. Or, sometimes 1911 magazine springs get worn out and need to be replaced. A fresh magazine spring will overcome the spring force of the mag catch spring. 

9mm slide doesn't fit on 45 frame: The front locking blocks are different between calibers. Don't mix caliber lower parts and slides. 

Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself. 

https://dbdesignworks.com
