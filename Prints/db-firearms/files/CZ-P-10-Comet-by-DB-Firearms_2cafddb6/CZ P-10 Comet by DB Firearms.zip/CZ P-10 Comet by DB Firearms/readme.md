    \_\_\_\_  \_\_\_\_     \_\_\_\_\_\_\_\_\_\_\_\_\_\_  \_\_\_\_\_\_\_\_\_    \_\_\_\_  \_\_  \_\_\_\_\_\_\_\_

   / \_\_ \\/ \_\_ )   / \_\_\_\_/  \_/ \_\_ \\/ \_\_\_\_/   |  / \_\_ \\/  |/  / \_\_\_/

  / / / / \_\_  |  / /\_   / // /\_/ / \_\_/ / /| | / /\_/ / /|\_/ /\\\_\_ \\

 / /\_/ / /\_/ /  / \_\_/ \_/ // \_, \_/ /\_\_\_/ \_\_\_ |/ \_, \_/ /  / /\_\_\_/ /

/\_\_\_\_\_/\_\_\_\_\_/  /\_/   /\_\_\_/\_/ |\_/\_\_\_\_\_/\_/  |\_/\_/ |\_/\_/  /\_//\_\_\_\_/

 



++++++++CZ P-10 Comet by DB Firearms++++++++





This frame is designed to turn your CZ P10C 9mm \& 40 parts kit back into a functional firearm. YAY!

This was a ground-up project performed by DB Firearms using a parts kit and photos to closely resemble the aesthetics of the OEM frame but there are some differences, mostly aesthetic.



Sourcing Kits: I'd always recommend first searching everygunpart.com. NOTE: I am sponsored by them and using the following link will search for CZ parts kits an if you purchase I will get a small kickback to use on their site: https://everygunpart.com/handgun-kits/semi-auto.html?manufacturer=835\&acc=ad1288236b3a6b1d28115a1f92ab8bb6



If you don't find anything there (their inventory changes daily) you can search gunbroker for listings using the following search keywords: "CZ Repair Parts"



Why the P10C only?:

There are other versions of this frame with different magazine sizes and slide sizes. Namely the P10F and P10S as well as a 45ACP variant. The C variant is the only one I can currently afford a kit of. Perhaps in the future I will put out the full size and subcompact versions. in theory, this frame will work with the same parts as the P10F and P10C but the slides wouldn't quite fit the frame. Also, the F magazine will fit in this frame but will have a gap at the bottom.



PLEASE READ \*\*\*IMPORTANT\*\*\* MAGAZINE CATCH COMPATIBILITY



The earlier P10 frames had an ambidextrous magazine catch that could be pushed from either side of the frame. It included a spring, a triangular piece held in by a pin, and the mag catch body. CZ had a lot of issues with this part and ended up swapping the parts for a much simpler setup, which includes a reversible magazine catch, a spring and detent, and a bar that retains the assembly. I have designed this frame to use the newer, more superior parts. If your kit has the older style magazine catch, you'll need to source the following extra parts:

* Reversible Magazine Catch Spring P-10C SKU: 315100000002 https://shop.cz-usa.com/315100000002.html
* Reversible Magazine Catch Plug P-10C SKU: 0550035001 https://shop.cz-usa.com/0550035001.html
* Reversible Magazine Catch P-10C SKU: 0550032002  https://shop.cz-usa.com/0550032002.html
* Magazine Catch Pin P-10/P-09/P-10 Reversible SKU: 311152252506 https://shop.cz-usa.com/magazine-catch-pin-p-07-p-09311152252506.html



Frame textures: The frame is pre-textured using blender. However, if you want to texture your own, blank STL's are included as part of this release.



PRINT ORIENTATION:

-All frames have been pre-oriented in their ideal print orientation(Rails Down, upside-down on build plate). If you are printing in a Nylon based filament, you may choose to rotate it 45 degrees (printed upside down, at 45 degrees on the nose. there is a small flat area there).



PRINT SETTINGS:

-Frame should hold up fine in PLA+ as it's rather thick. However, be cool and print in this filament and your frame will last long time: https://amzn.to/3MP8L12

-Print on the hotter side to ensure good layer adhesion. PLA+(220c)

-No raft or brim needed unless you have difficulty with build plate adhesion

-Use Organic Supports



Required Tools:

* Roll pin punches (or standard pin punches) in sizes: 1/16", 1/8", and 3/16" — for driving all frame pins (grip safety, sear, ejector, trigger, locking block, etc.). Use brass or polymer-tipped to avoid marring the frame.
* Small hammer or brass mallet — for controlled tapping of punches when driving pins in/out (never use a steel hammer directly on pins).
* Slave pin (or temporary alignment pin) — about the same diameter as the magazine catch pin (slightly smaller works best); a long Allen key/hex wrench is commonly used as a makeshift slave pin for the magazine release installation.
* Small flathead screwdriver or dental pick/punch — for compressing/depressing springs (e.g., slide catch spring, magazine spring during prep, or pushing spring legs under pins).
* Pliers (needle-nose recommended) — for holding nuts/screws if needed, or gently bending spring legs.
* Safety glasses — mandatory; multiple small springs are under tension and can fly out.
* Stable work surface — preferably with a soft mat or rag to catch parts and prevent scratches; you can also work inside a clear plastic bag for high-tension springs.
* 

Optional but highly recommended:

* Small container — to organize pins, springs, and parts during the process.



Required Parts:

Parts Diagram here: https://gallowayprecision.com/images/manuals/p-10-manual.pdf

1. Magazine Release Assembly:

* Magazine catch
* Magazine catch plug
* Magazine catch spring
* Magazine catch pin



2\. Trigger Assembly

* Trigger Bar
* Trigger bar pin
* Trigger with safety assembly installed
* 



3\. Front Insert Assembly:

* Front Insert
* Disassembly plate
* Disassembly plate retainer
* Disassembly plate spring
* Slide stop spring
* Slide stop
* Front insert pin
* Insert coiled pin



4\. Rear Insert Assembly:

* Rear insert
* 2x Rear insert coiled pins
* Trigger bar disconnector
* Trigger bar disconnector spring
* Trigger bar spring pin
* 2x trigger bar springs





5\. Assembled/Complete Slide with barrel and recoil spring



6\. Complete magazine in caliber and capacity of choice

* 9mm 15rd
* 9mm 10rd cucked (dimples can be drilled out and it adds 5rds of capacity)
* 40S\&W 12rd
* 40S\&W 10rd cucked (dimples can be drilled out and it adds 2rds of capacity)



-----ASSEMBLY STEPS-----

This video is far from perfect but may be helpful in assembly. it shows the older style magazine release not supported by this frame: https://www.youtube.com/watch?v=a4Dkgps4dec



Before proceeding with assembly, remove all support material and REAM PINS. Reaming the pins is a necessary step to ensure that pins do not crack the rear rails. Please take the time to do this. you can install the pin in a drill chuck and spin it in the hole to ream perfectly to size.



1\. Install the Magazine Release

* Ensure the magazine catch fits correctly in its channel. If not, use a needle file to gently remove material until it slides freely.
* Install the small spring and pin into the magazine catch in its channel, and carefully place them in the frame.
* Use a small punch in the side of the magazine catch to depress the spring and pin. With tension on these parts, push the plug down in its channel until it's pressing on the punch.
* Continue to put downward pressure on the plug and quickly pull the punch out of the side of the magazine catch. The plug should drop down about 2-3mm and retain the magazine catch. If that fails, try the procedure again.



2\. Install the rear assembly with trigger assembly attached

* Ensure that your entire rear assembly is intact, along with the trigger bar and trigger as one unit.
* Drop it into place, and push down on the trigger bar disconnector to allow the whole assembly to slide into place.
* Install both rear insert coiled springs. Hammer in gently from the right side of the frame until they are both flush with the frame. The more forward pin needs extra attention as it can wander off course. Make sure it's lined up before finishing hammering through the left side.



3\. Install the front insert assembly

* Add the slide stop to the front insert and then install the slide stop spring on the left side in its channel.
* Fromo the underside, drop in the disassembly plate retainer and spring into its channel.
* Drop the assembly into the frame (slide stop should be under spring pressure at this point and will want to push the insert up at the back.
* Install the front insert pin which will go through the frame and trigger.
* Install the coiled front insert pin and hammer into place.
* Slide the disassembly plate in. Using a punch, depress the retainer. The lip should be facing towards the back of the frame. It will click into place when properly retained.



4\. Pre-Check Before Final Springs/Pins

* Verify the trigger will pull down the sear.
* Check that the slide catch lever has spring tension (push up, release—it should snap downward).
* Check that the disassembly plate can be pulled down and it returns up under spring pressure.



5\. Final Functional Checks

* Install the slide from the front of the gun, pull back and ensure it's retained on the frame by the disassembly plate.
* Rack the slide and ensure it returns to battery
* Verify the trigger releases the striker.
* Insert the magazine, rack the slide—it should lock back on empty.
* Confirm the magazine drops free.
* Test with snap caps for feeding/ejection. If all functions correctly, the pistol is ready.





-----ASSEMBLY OF +2 MAGAZINE EXTENSION-----

The magazine baseplate is intended to be used on 15 round magazines to increase capacity to 17rds.



Required Tools \& Parts

* M3x14mm socket head cap screw (1)
* M3 nut (1)
* Small flathead screwdriver or punch (for depressing the factory retainer)
* Allen wrench/hex key (for the socket head screw)
* Safety glasses



Assembly Steps

1. Remove the Factory Baseplate

* Point the bottom of the magazine away from your face/body.
* Depress the exposed portion of the magazine baseplate retainer (visible through the hole in the bottom of the factory baseplate) using a small screwdriver or punch.
* While holding the spring down, carefully slide the factory baseplate forward/off the magazine tube.
* Slowly release pressure on the spring—control it as the baseplate comes free.
* Keep pressure on the internal baseplate lock/retainer
* The magazine spring and follower should be partially compressed in the tube.



2\. Prepare the Magazine

* Push the magazine spring fully into the bottom of the tube (compress it downward) to create clearance.
* Hold it compressed with the baseplate lock (nub facing out).



3\. Install Extension

* Slide extension onto the bottom of the magazine tube from the front.
* Push it fully backwards until it seats firmly against the front of the magazine tube.
* Ensure it aligns straight and sits flush with no wobble.The lock and spring should fall down into the extension and be retained



4\. Secure the Assembly

* Install the M3x15mm grub screw from the bottom in its hole.
* Tighten the screw gradually with an Allen wrench.
* Tighten until screw protrudes in front of the back side of the magazine body.



5\. Final Checks

* Ensure the follower moves freely up/down.
* Insert the magazine into your unloaded P-10C.
* Rack the slide a few times (with snap caps if testing function).
* Verify smooth insertion, lock-back on "empty," and free drop when the slide is locked back.
* If the magazine binds or doesn't drop free, recheck alignment, tightness, and spring orientation.



TROUBLESHOOTING:



Depending on material and print orientation, there is a chance that the trigger might bind on the trigger guard if the filament drooped there. Use a small knife (exacto) to remove material until the trigger no longer binds.



Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself.



https://dbdesignworks.com

