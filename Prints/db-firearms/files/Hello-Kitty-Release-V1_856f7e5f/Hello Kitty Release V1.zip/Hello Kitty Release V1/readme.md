
    ____  ____     ______________  _________    ____  __  ________
   / __ \/ __ )   / ____/  _/ __ \/ ____/   |  / __ \/  |/  / ___/
  / / / / __  |  / /_   / // /_/ / __/ / /| | / /_/ / /|_/ /\__ \ 
 / /_/ / /_/ /  / __/ _/ // _, _/ /___/ ___ |/ _, _/ /  / /___/ / 
/_____/_____/  /_/   /___/_/ |_/_____/_/  |_/_/ |_/_/  /_//____/  
                                                                  
## Legal Notice & Compliance Statement

DBDESIGNWORKS is a sole proprietorship based in and operating under the laws of the State of Idaho, USA.

These 3D-printable files are provided **exclusively for lawful personal use** by individuals who are:
- Not prohibited from possessing or manufacturing firearms under federal law (including 18 U.S.C. § 922(g)), and
- Fully authorized under all applicable federal, state, and local laws in their jurisdiction of residence to manufacture firearm components or complete firearms.

**These files are not intended for, and are not offered or distributed to, residents of any state or jurisdiction where the possession, manufacture, download, or use of these files is prohibited or requires a specific license that the user does not possess.** This includes, but is not limited to, the State of California.

By downloading, accessing, or using any file from this repository or website, you expressly represent and warrant that:
1. You are a law-abiding adult in full compliance with all federal, state, and local laws governing firearms and firearm-related items in your jurisdiction.
2. You are not located in, and will not use these files in, any jurisdiction where such activity is illegal.
3. You will not distribute, share, or sell these files in violation of any law.

**DB Design Works complies with all applicable federal and Idaho state laws.** We make no representation that these files are legal in your specific state or locality. It is solely your responsibility to determine the legality of these files, to verify your own eligibility, and to ensure full compliance before downloading or using them.

These files are provided **"AS IS"** without any warranty, express or implied. DB Design Works disclaims all liability for any loss, damage, injury, or legal consequence arising from the use or misuse of these files. Any unlawful use is strictly prohibited and is a violation of this notice.

If you are unsure whether you may legally download or use these files in your jurisdiction, do not download them.


++++++++The Hello Kitty: A Springfield Armory Hellcat(and Pro) Frame by DB Firearms++++++++


These frames are designed to turn your Springfield Hellcat and Hellcat Pro parts kits back into functional firearms. YAY!
These are not designed to be a 1:1 representation of the OEM hellcat aesthetically(more of a homage). However, these are functional frames. The main frame was edited from the "poorcat" by InsertMeow. Special thanks to IMA for the base for this frame.


There are 3 styles of frames in the files.
Hellcat: Original hellcat frame  for the compact mags (13rd or 11rd)
Hellcat X: For OG hellcat parts kits, but using the "Pro" 17rd magazines (Short slide long mag)
Hellcat Pro: For Pro kits, with longer slides. Only compatible with Pro mags which are 17rds.

NOTES ON KITS AND MAGAZINES: OEM mags are very nice and I suggest you try to get those first. The Mec-Gar mags are also good but might fit a little bit tighter. Don't buy promag. 


PRINT ORIENTATION: 
-All frames have been pre-oriented in their ideal print orientation(Rails Down, upside-down on build plate). If you are printing in a Nylon based filament, you may choose to rotate it 45 degrees. 

PRINT SETTINGS: 
-Frame was tested with PLA+ and proved to be very robust. 
-Print on the hotter side to ensure good layer adhesion. PLA+(220c)
-No raft or brim needed unless you have difficulty with build plate adhesion
-Use Organic Supports

ASSEMBLY INSTRUCTIONS: 

### Important Notes Before Starting
- Ensure **all support material** has been completely removed and any rough edges have been lightly sanded or deburred.
- Use a soft mallet or hammer with a plastic/brass punch when tapping parts. Avoid direct metal-to-metal strikes on the frame.
- All pins are installed from right to left unless otherwise noted.
- Work on a stable surface.

### Step-by-Step Assembly

1. **Install the Magazine Catch**  
   Insert the magazine catch spring into its pocket and push it down until it bottoms out.  
   Install the magazine catch and bend the spring leg into its groove on the catch.  
   *(This is the same procedure as on a Gen 3 Glock pistol.)*

2. **Install the Sear / Trigger Assembly**  
   Push the rear sear cage (housing) into the frame, aligning the holes in the side of the frame with the holes in the sear cage.  
   Insert the rear pin from the right side and seat it fully.

3. **Install the Slide Catch (Slide Stop)**  
   Place the slide catch into position (the through-hole should be next to the trigger on the left side).  

4. **Install the Front Locking Block / Rail Assembly**  
   Ensure the slide catch spring is properly seated in the side of the front locking block/rail combo.  
   Insert the front locking block/rail assembly into the frame. It is a snug fit — gently tap it into place with a soft mallet if needed.
   Insert the slide catch pin from the right side and tap it through until it is centered in the frame.

5. **Install the Locking Block Pin**  
   Insert the locking block pin last.  
   After installation, verify that the slide catch has proper spring pressure. The leg of the slide catch spring should sit on top of the slide catch, pressing it downward. Adjust if necessary.

6. **Function Check – Magazine**  
   Insert an empty magazine. It should lock firmly into place via the magazine catch.  
   The magazine should also push the slide catch upward when fully seated.

7. **Install the Takedown Pivot Pin**  
   Insert the takedown pivot pin. You may need to rotate/spin it to clear the retaining spring.  
   Using firm thumb pressure, push it down until it snaps into place.  
   With the pivot pin rotated upward (disassembly position), install the slide onto the frame.

8. **Final Function Check**  
   Pull the slide fully rearward and lock it back using the slide catch.  
   Rotate the takedown pivot pin counter-clockwise to the locked (horizontal) position.  
   Release the slide and allow it to go forward.  
   Perform a full function check: dry-fire, magazine insertion/removal, slide lock/release, and takedown lever operation.

### Safety Reminder
After assembly, always treat the firearm as if it is loaded. Verify the pistol is unloaded before any further handling or testing. Test all functions thoroughly before live firing.  

If anything feels tight, gritty, or does not function smoothly, stop and disassemble to inspect the parts.

---

Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself. 

https://dbdesignworks.com
