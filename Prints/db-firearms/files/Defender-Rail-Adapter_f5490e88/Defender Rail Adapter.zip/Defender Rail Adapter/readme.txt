Defender Rail Adapter by DB firearms

Required Hardware: 
3x 8-32 x 11/16" flat head screws to attach to back of defender (MCM 92210A166)
2x M4 flat head screws (the ones that usually come with a piece of MLOK rail)
2x M4 Nuts to attach the rail to the adapter

One section of aluminum MLOK rail with 3 slots

Assembly: First install the nuts in the pockets, then screw the plate onto the back of your defender. Blue loc-tite is suggested.
Next, install your rail with the 2 M4 screws that come with the rail. Tighten and you're done!

Enjoy

dbdesignworks.com