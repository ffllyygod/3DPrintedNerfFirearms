Sig SP2022 DB Edits

This frame is an edit of HerzAnHerz and nguyenkvvn's SP2022 frame released on the Gatalog here: 
https://odysee.com/@TheGatalog-PrintableFramesReceivers:9/SP2022-HerzAnHerz-v1.0:e
That frame was an edit of the original frame by homethearmless here: https://grabcad.com/library/sig-sp2022-frame-1

I have great respect for all that were involved in bringing this frame forward. I take ZERO credit
for this functional frame. I only modified it to my liking. 

Changes made: 
I went through the whole .step file to clean up stray geometry and try to make it as easily editable as possible.
Redesigned the trigger guard to match more closely to the OEM frame, added new front grooves to trigger guard.
Added a small hump behind trigger to reduce over-travel and improve slide unlocking (now much smoother when trigger depressed)
Added grip panel sections for stippling. I've included a blank STL and a version that I tried to mimick the OEM texture
Edited the frame slightly in lots of areas to more closely resemble the OEM frame
Recontoured the front of the grip slightly to make texturing easier

A lot of this is cosmetic stuff - so nothing groundbreaking. But if you print it in black nobody will know your frame is not OEM. That was my goal. 

All other print settings and assembly instructions should refer to the original files here: 

https://odysee.com/@TheGatalog-PrintableFramesReceivers:9/SP2022-HerzAnHerz-v1.0:e

dbdesignworks.com