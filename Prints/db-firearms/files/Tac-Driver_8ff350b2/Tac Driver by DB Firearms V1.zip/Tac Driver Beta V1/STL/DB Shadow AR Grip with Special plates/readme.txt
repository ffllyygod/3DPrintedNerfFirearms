
    ____  ____     ______________  _________    ____  __  ________
   / __ \/ __ )   / ____/  _/ __ \/ ____/   |  / __ \/  |/  / ___/
  / / / / __  |  / /_   / // /_/ / __/ / /| | / /_/ / /|_/ /\__ \ 
 / /_/ / /_/ /  / __/ _/ // _, _/ /___/ ___ |/ _, _/ /  / /___/ / 
/_____/_____/  /_/   /___/_/ |_/_____/_/  |_/_/ |_/_/  /_//____/  
                                                                  

++++++++The DB-Shadow AR Grip DB Firearms++++++++

This is a great little AR grip that lets you use CZ Shadow pattern grip panels on an AR-15 patterned gun. Additionally, there 
are two seperate grip panels - a blank set and a dotted set. From there you can modify and stipple to your heart's desire. Or
you can use OEM style grip panels as well. 

PRINT ORIENTATION & SETTINGS: 
-I print my grip upside down with supports on build plate. Grip panels should be printed flat, right side up with supports on 
the build plate as well. Sometimes the grip panels don't come out clean on the bottom, you may need to clean them up a little. 
However, I can't modify them too much for printability because I wanted to retain the OEM grip panel fitment. Hence the strnage
geometry on the bottom of the grip panels. 

SCREW AND HEAT SET INSERT SPECS: 
-This grip will also support OEM spec grip screws, which are M3.5x8mm. However, heat-set inserts are required to make this work.
If you don't want to fuss around with it, you can order a set of heat-set inserts and grip screws from my site at 

https: db-firearms.com

If you'd like a bunch of them, feel free to order in bulk at McMaster Carr. The design is modeled to use the following screws and 
inserts: 

M3.5 x 8mm Button Head Screw: McM 92095A160
M3.5 x 3.81mm Heat Set Insert: McM 94180A502


ASSEMBLY INSTRUCTIONS: 
Remove supports from the grip and melt in your heat-set inserts using a soldering iron. Ensure they are both flush and square with
the grip side. 

Remove supports from grip panels and test fit - if they don't sit flush, you may need to remove any loose material from the back 
until you get a flush fit. Install grip panel screws and tighten securely. 

Install on your AR or other gun as usual. 

Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself. 

https://db-firearms.com
