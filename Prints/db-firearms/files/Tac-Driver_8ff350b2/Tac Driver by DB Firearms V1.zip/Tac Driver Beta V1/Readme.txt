
    ____  ____     ______________  _________    ____  __  ________
   / __ \/ __ )   / ____/  _/ __ \/ ____/   |  / __ \/  |/  / ___/
  / / / / __  |  / /_   / // /_/ / __/ / /| | / /_/ / /|_/ /\__ \ 
 / /_/ / /_/ /  / __/ _/ // _, _/ /___/ ___ |/ _, _/ /  / /___/ / 
/_____/_____/  /_/   /___/_/ |_/_____/_/  |_/_/ |_/_/  /_//____/  
                                                                  

++++++++Tac Driver by DB Firearms++++++++

What is this? Reinforced lower receiver for Sol Invictus Tac 9 Upper Receivers

HUGE THANKS TO CTRLPEW and the beta testers of the Tac Daddy. I used the base cad of that for this heavy remix. 

Changes from Tac Daddy: 
Started by removing all external features of Tac Daddy, then proceeded to change some small geometry on the internals, moving ejector slightly, increasing tightness of upper and reducing
the amount of space the upper had for recoil, reduce likelyhood of breaking the charging handle. Changed magazine fitment and lock in location to aid in more reliable feeding. 

THEN, complete external overhaul, changed the rear to make it modular and allow the use of a steel reinforcement plate in the back to absorb and transfer recoil, make a more robust frame. 

All external features have been worked over to give it some DB style. I hope you like it! I sure do. 


REQUIRED HARDWARE:

****  Don't wanna scrounge together all this hardware? Go get a hardware kit at https://dbdesignworks.com  ****

(5) M4 Nuts for rear attachment McMaster PN: 98676A200
(2) M4x30mm Socket Head Screws for rear attachment McMaster PN: 91290A180
(3) M4x20mm Socket Head Screws for rear attachment McMaster PN: 91290A168
(1) M5 Square Nut for grip screw attachment McMaster PN: 96887A331
(1) M5x20mm Socket Head Screw for grip McMaster PN: 90128A256

OPTIONAL IF PRINTING DB SHADOW GRIP
(2) M3.5 x 8mm Button Head Screw McMaster PN: 92095A160
(2) M3.5 x 3.81mm Heat Set Insert McMaster PN: 94180A502


REQUIRED OEM COMPONENTS: 
AR Fire Control Group(Hammer and spring, trigger and spring, disconnector and spring, 2 pins
Any AR Pistol Grip, but not with a big beaver tail. I have included the DB Shadow grip if you'd like to try that one printed. 
Any AR-15 free float handguard if desired
Complete Tac 9 Upper kit, which includes the ejector, charging handle, etc. These are sold at either:
MAF ARMS: https://maf-arms.com/product/tac-chime/ or https://maf-arms.com/product/tac-chime-with-8-resonator/
Parts Dispensed: https://parts-dispensed.com/home/234-tac-9-upper-complete or https://parts-dispensed.com/home/213-tac-9-upper-complete

EXTRA REQUIREMENT: 
There is a steel plate in the files that is meant to be laser cut. To make it easier for you to build, i have some of these available (black powder coated) for purchase on my site: https://dbdesignworks.com
This plate will GREATLY increse the strenght of the design. If you prefer to have it laser cut yourself, you can get it from sendcutsend or another service. I've included the .dxf file
for use. You'll want to have it cut out in .187" Stainless Steel.

PRINT ORIENTATION & SETTINGS: 
All files have two different orientations based on your material. They are already oriented for your various slicers. Details: PLA+ filament, print the lower upside down on build plate flat. 
Rear pieces, print them flat on their flat side :) If you are printing in Nylon CF, you can try the other orentations in the files. 

Materials: Suggested PLA+ or better. I like NylonX and this design is built for it. However, it's a tricky filament to get right. Start with PLA+ and if you love the design, look at more
exotic filaments to print in. Print as hot as you can to ensure strength. You will need supports on the build plate for the lower. But the other pieces don't need supports. I suggest the organic
or tree supports.

ASSEMBLY INSTRUCTIONS: 
For a visual representation of assembly, I suggest downloading the Tac Daddy manual here and looking at the instructions for the upper assembly: 
https://odysee.com/@TheGatalog-PrintableFramesReceivers:9/TacDaddy-Release-Package:7

To assemble the lower, just install your FCG, your ejector, your magazine release. Very easy. Then add the rear plates like a sandwich, install bolts, tighten to hand tight. Don't over do it. 
You can use loctite if you want to on the nuts. 

Now you can slot the upper into the lower and add the front takedown bolt. Make sure your recoil block is aligned so your rod is smooth. Give it some testing with snap caps and take it out to the range!

Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself. 

https://dbdesignworks.com
