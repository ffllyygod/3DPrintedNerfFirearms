
    ____  ____     ______________  _________    ____  __  ________
   / __ \/ __ )   / ____/  _/ __ \/ ____/   |  / __ \/  |/  / ___/
  / / / / __  |  / /_   / // /_/ / __/ / /| | / /_/ / /|_/ /\__ \ 
 / /_/ / /_/ /  / __/ _/ // _, _/ /___/ ___ |/ _, _/ /  / /___/ / 
/_____/_____/  /_/   /___/_/ |_/_____/_/  |_/_/ |_/_/  /_//____/  
                                                                  
## Legal Notice & Compliance Statement

DBDESIGNWORKS is a sole proprietorship based in and operating under the laws of the State of Idaho, USA.

These 3D-printable files are provided **exclusively for lawful personal use** by individuals who are:
- Not prohibited from possessing or manufacturing firearms under federal law (including 18 U.S.C. § 922(g)), and
- Fully authorized under all applicable federal, state, and local laws in their jurisdiction of residence to manufacture firearm components or complete firearms.

**These files are not intended for, and are not offered or distributed to, residents of any state or jurisdiction where the possession, manufacture, download, or use of these files is prohibited or requires a specific license that the user does not possess.** This includes, but is not limited to, the State of California.

By downloading, accessing, or using any file from this repository or website, you expressly represent and warrant that:
1. You are a law-abiding adult in full compliance with all federal, state, and local laws governing firearms and firearm-related items in your jurisdiction.
2. You are not located in, and will not use these files in, any jurisdiction where such activity is illegal.
3. You will not distribute, share, or sell these files in violation of any law.

**DB Design Works complies with all applicable federal and Idaho state laws.** We make no representation that these files are legal in your specific state or locality. It is solely your responsibility to determine the legality of these files, to verify your own eligibility, and to ensure full compliance before downloading or using them.

These files are provided **"AS IS"** without any warranty, express or implied. DB Design Works disclaims all liability for any loss, damage, injury, or legal consequence arising from the use or misuse of these files. Any unlawful use is strictly prohibited and is a violation of this notice.

If you are unsure whether you may legally download or use these files in your jurisdiction, do not download them.


++++++++PX4DB Storm: A Full-Size Beretta PX4 Storm Frame by DB Firearms++++++++


The main frame was edited from the "PPX4" by jmanjones. Special thanks to jmanjones for the base for this frame. I would not have pursued this project without his massive contribution. You should download those original files as well to see the other frame options available, such as compact, 45acp, hybrid frames, and ones using 92 magazines. https://odysee.com/@TheGatalog-PrintableFramesReceivers:9/PPX4:6


There are 2 different frames in the download (blank and textured). Feel free to use the blank STL to make your own textured/stippled frame. 

For detailed instructions on assembly, please refer to the original PPX4 referenced above. 

Frame Additions over the OEM style: 
-This is specifically designed to pair seamlessly with the Vantage Point Armory rail-mounted compensator found here: https://vparmory.com/products/rail-mounted-compensator-for-beretta-px4-storm-pistols?variant=50801206591809
-There is a reinforcement section on the left side of the frame to help improve stability of polymer at the thin wall where trigger bar resides. Common area for frame flex, even in OEM frames. 
-Redesigned the backstrap of the frame to improve ergonomics and reduce overall size of frame
-Added a beaver tail (mostly cosmetic) to increase grip height slightly, allow you to get higher up at the back of pistol.
-Added texture panels all over the frame to improve grip
-Redesigned the trigger guard for a more modern rectangular look with undercuts for support hand and a texture spot on front for support finger.
-Added a built in flared magwell to improve quick reloads while retaining OEM magazine baseplate compatibility.
-Thickened front of frame for added strength to deal with the built in compensator. 

PRINT ORIENTATION: 
-Both frames have been pre-oriented in their ideal print orientation(Rails Down, upside-down on build plate). If you are printing in a Nylon based filament, you may choose to rotate it 45 degrees. For this purpose there is a small 45 degree flat spot on the nose of the frame. 

PRINT SETTINGS: 
-Frame was tested with PLA+ and proved to be very robust. 
-Print on the hotter side to ensure good layer adhesion. PLA+(220c)
-No raft or brim needed unless you have difficulty with build plate adhesion
-Use Organic Supports

ASSEMBLY INSTRUCTIONS:

No assembly instructions will be provided as part of this release. Please refer to the original PPX4 release files for detailed assembly instructions. Those are linked above for your reference. 

Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself. 

https://dbdesignworks.com
