░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▓████▓▓░░░░░░▒▓████▓▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█████████░░░░▒████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█████████░░░░▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█████████░░░░▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█████████░░░░▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒████████▓░░░░▒█████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▓█████████▓░░░░░██████████▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░▒▓▓█████████████████████████████████░░░░░░▒█████████████████████████████████▓▒░░░░░░
░░░▒▓███████████████████████████████████▓░░░░░░░░▒███████████████████████████████████▓▒░░░
░░▓████████████████████████████████████▒░░░░░░░░░░▒████████████████████████████████████▓░░
░▓█████████████████████████████████▓▒░░░░░░░░░░░░░░░░▒▓█████████████████████████████████▓░
░██████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓█████████▒
▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒████████▓
▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒████████▓
▒█████████▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒█████████▓
░▓███████████████████████████████████████▓░░░░░░▒████████████████████████████████████████░
░░████████████████████████████████████████▓░░░░▒████████████████████████████████████████▒░
░░░▓███████████████████████████████████████░░░░▒███████████████████████████████████████▒░░
░░░░░▒████████████████████████████████████▓░░░░▒████████████████████████████████████▓░░░░░


DB FIREARMS PRESENTS: The POF-USA Drop in Trigger Cut Jig for the Hoffman Tactical Super Safety.

Catchy name, right? 
-----------------------------------------------------------
Description: This is a very simple marking jig to be used to guide your cut for these triggers. This will work with all of the various POF-USA drop-in triggers. 

WARNGING: Do not blame me if things don't mesh well. However, in testing, this will pass all functions of the super safety when cut correctly using the jig. 
 
-----------------------------------------------------------
Printing Instructions: 

-The models should drop into your slicer with correct orientation already.
-Print in PLA+ with 100% solid infill. Use a smaller layer height if you want a more accurate print, though it's not entirely necessary
-If you are keeping the jig on the trigger while cutting, the PLA will definitely begin to melt with the heat. If you begin your cuts and remove the jig except for checking your work, the jig should hold up ok in PLA+. If you're worried about melting, you can print several to switch them out. 
-----------------------------------------------------------
Usage Instructions:

The jig has an arrow on one side. That arrow should be pointing towards the back and left side of the trigger. Once the jig is installed in the correct orientation, look at the top of the trigger with the arrow on the jig pointing towards you. You should see that the jig cutout exposes part of the trigger tail on the left side. The jig should be nearly flush with the back of the trigger. It can only really be installed in one direction, but if you're confused, check the photo in the zip file. 

Once you have installed the jig, you can use a scribe or sharp knife to mark lines in the steel where you should remove material. Alternatively, you can attach the jig to the trigger by using some hot glue around the edges to keep the jig secure. I found that using a fresh Dremel cutoff wheel made quick work of the material removal. However, it is hardened steel, so it may be tough to remove if you are using hand tools. Finish the cuts with a file to ensure everything is square. Use a second jig if your first one melts to check that everything looks good. Once done, your trigger tail should be 2mm/.08" wide to work correctly. That 2mm portion of the trigger tail should extend about 7mm/.28". Refer to the photo to check your work. Photo is of the bottom side of the trigger tail. Additionally, you can very gently round the top back corner of the trigger to smooth out function with super safety.


dbdesignworks.com

License: Creative Commons Share Alike NON COMMERCIAL


