
    ____  ____     ______________  _________    ____  __  ________
   / __ \/ __ )   / ____/  _/ __ \/ ____/   |  / __ \/  |/  / ___/
  / / / / __  |  / /_   / // /_/ / __/ / /| | / /_/ / /|_/ /\__ \ 
 / /_/ / /_/ /  / __/ _/ // _, _/ /___/ ___ |/ _, _/ /  / /___/ / 
/_____/_____/  /_/   /___/_/ |_/_____/_/  |_/_/ |_/_/  /_//____/  
                                                                  

++++++++Scorpion Bullpup P90ish Grips by DB Firearms++++++++

These grips are designed to turn your scorpion bullpup into a p90ish style bullpup. These grips cover the front pic rail and add a
foregrip (Check renders). It prints as one piece and bolts together on the factory grip mounting point. Not much else to it - just 
a fun grip for a totally hated gun. But if you're here, maybe you don't hate it.

This release was only tested by me and there could be some small tolerance or fitment issues you will have to resolve with a knife and files.

PRINT ORIENTATION & SETTINGS: 
-I print both panels flat on build plate with supports on build plate. The inside of the grip half facing the build plate. 

REQUIRED HARDWARE: 
(6) M4 x 30mm Button Head Hex Drive Screws. McMaster 91239A156
(6) M4 Nuts. McMaster 94166A110

Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself. 

https://db-firearms.com
