░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▓████▓▓░░░░░░▒▓████▓▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█████████░░░░▒████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█████████░░░░▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█████████░░░░▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█████████░░░░▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒████████▓░░░░▒█████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▓█████████▓░░░░░██████████▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░▒▓▓█████████████████████████████████░░░░░░▒█████████████████████████████████▓▒░░░░░░
░░░▒▓███████████████████████████████████▓░░░░░░░░▒███████████████████████████████████▓▒░░░
░░▓████████████████████████████████████▒░░░░░░░░░░▒████████████████████████████████████▓░░
░▓█████████████████████████████████▓▒░░░░░░░░░░░░░░░░▒▓█████████████████████████████████▓░
░██████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓█████████▒
▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒████████▓
▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒████████▓
▒█████████▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒█████████▓
░▓███████████████████████████████████████▓░░░░░░▒████████████████████████████████████████░
░░████████████████████████████████████████▓░░░░▒████████████████████████████████████████▒░
░░░▓███████████████████████████████████████░░░░▒███████████████████████████████████████▒░░
░░░░░▒████████████████████████████████████▓░░░░▒████████████████████████████████████▓░░░░░


DB FIREARMS PRESENTS: Safe Stickers
-----------------------------------------------------------
Description: These little guys are a simple solution to store multiple firearms in your safe. After installing an adhesive Velcro pad on one side, you can stand your weapon vertically in your safe, slide the stick into your gun barrel, and move the stick upwards until the stick makes contact with the top of your safe. If your safe has a shelf with no vecro on it, use the other side (either hook or loop) of the Velcro dot to keep the stick in place. This will allow you to fit many more weapons in your safe. 

There are multiple sizes .22, .30, .45, and 9mm. However, you can use the smaller size for any of the gun barrels and it will still work ok. The larger ones are simply more rigid in the larger barrels.    
-----------------------------------------------------------
Printing instructions: 

-The models should drop into your slicer with correct orientation already. I would not suggest adjusting the orientation. Sticks are designed to print on a 250mm or larger build plate. 
-You don't need to print these solid. 2 walls, 2 top/bottom layers, and 10% infill will work fine. However, if you want a more rigid stick you can use a higher infill. 
-No Supports are needed.
-Use cheap PLA filament, this doesn't need any special filament.
-----------------------------------------------------------
Assembly instructions:
Push the stick into the barrel until it snaps into place. This can be made easier if you place the barrel upside-down on a table and force the stick in. Push until it snaps in. 
Clean the Top of the barrel with some rubbing alcohol, then place one of the adhesive Velcro pads on. I used .59" ones from amazon. https://www.amazon.com/JUMINIZ-0-59inch-Diameter-Fastener-Classroom/dp/B0CJG34D6P

Install guns in safe, make sure there is a shelf above for sticks to mount to, add the other Velcro dot to the safe under-shelf, push stick up...you get the idea. Here's what I based this design off of: https://www.storemoreguns.com/rifle-rods-gun-rack-system/

dbdesignworks.com

License: Creative Commons Share Alike NON COMMERCIAL


