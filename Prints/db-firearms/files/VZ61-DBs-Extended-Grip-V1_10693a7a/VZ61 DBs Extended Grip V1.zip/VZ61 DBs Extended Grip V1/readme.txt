VZ61 DB Extended Grip

This is a basic VZ61 grip that has been extended for larger hands.
Grooves have been added to the front and back to improve grippiness. 

Print Settings:
PLA+ or better. I suggest CF Nylon for a long lasting grip
Print orientation: Print with the small section on the back bottom of grip flat on build plate.
I've pre-oriented the STL for convenience. 
Supports: on build plate

Installation: This will install like a normal VZ61 grip. If you find it tight, you may have to gently
tap it on or file the top grooves to ensure it seats down fully on your lower.

ENJOY
DBdesignworks.com

NOTE: if you are good at applying texture to models and want to give this a try,
please share your results with me. I'd love to see what you come up with!

dbdesignworks.com