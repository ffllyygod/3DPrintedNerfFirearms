    \_\_\_\_  \_\_\_\_     \_\_\_\_\_\_\_\_\_\_\_\_\_\_  \_\_\_\_\_\_\_\_\_    \_\_\_\_  \_\_  \_\_\_\_\_\_\_\_

   / \_\_ \\/ \_\_ )   / \_\_\_\_/  \_/ \_\_ \\/ \_\_\_\_/   |  / \_\_ \\/  |/  / \_\_\_/

  / / / / \_\_  |  / /\_   / // /\_/ / \_\_/ / /| | / /\_/ / /|\_/ /\\\_\_ \\

 / /\_/ / /\_/ /  / \_\_/ \_/ // \_, \_/ /\_\_\_/ \_\_\_ |/ \_, \_/ /  / /\_\_\_/ /

/\_\_\_\_\_/\_\_\_\_\_/  /\_/   /\_\_\_/\_/ |\_/\_\_\_\_\_/\_/  |\_/\_/ |\_/\_/  /\_//\_\_\_\_/

 



++++++++Springfield XD-M 45/10mm DBmod by DB Firearms++++++++





These frames are designed to turn your Springfield XD-M 45ACP parts kits back into functional firearms. YAY!

The main frame was edited from the work of 458SOCOM (THE XD KING) Be sure to thank 458SOCOM for his hard work in making these a reality!



Sourcing Kits: I'd always recommend first searching everygunpart.com. NOTE: I am sponsored by them and using the following link will search for XD parts kits an if you purchase I will get a small kickback to use on their site: https://everygunpart.com/handgun-kits/semi-auto.html?manufacturer=69\&acc=ad1288236b3a6b1d28115a1f92ab8bb6



If you don't find anything there (their inventory changes daily) you can search gunbroker for listings using the following search keywords: "Springfield Repair Parts"



XD-M Vs Standard XD:

The main difference in this newer pistol is the auto takedown feature. This allows you to take the gun down without pulling the trigger. Additionally, this frame will also work with the slides from XD-M Elite models. This means if you can find a 10mm slide, it will work without modification on this frame. This frame WILL NOT work with the Elite trigger group. The XD-M uses the same mags as the XD in 45!



PLEASE READ \*\*\*IMPORTANT\*\*\* FRAME EXPLANATION

Full Size Frame: This frame is for the XD-M 4.5" slides. it's setup to use full size 13 round 45ACP or 15 round 10mm magazines There is also a +2 mag extension in files

Compact-X Frame: This frame is for the 3.8" slide but uses only the full size 13rd/15rd magazines and is not compatible with shorter mags.

Comact Frame: This frame is for the 3.8" slide but can use any magazine. It Will also fit 13rd mags but will have a gap and the mag will stick out all funny.



LAST NOTE: There are some tuning steps required to get the takedown mechanism to work correctly. This is an artifact of removing the grip safety from the equation. DO NOT SKIP THE TUNING STEPS. If you don't want to mess with the tuning of the auto-takedown mechanism, you can omit those parts with no ill-effects to the system. This will mean you'll just have to pull the trigger to remove the slide. The parts to omit are the disassembly bar, disassembler and spring.

Frame textures: The frames are pre-textured using blender. However, if you want to texture your own, blank STL's are included as part of this release.



PRINT ORIENTATION:

-All frames have been pre-oriented in their ideal print orientation(Rails Down, upside-down on build plate). If you are printing in a Nylon based filament, you may choose to rotate it 45 degrees (printed upside down, at 45 degrees on the nose. there is a small flat area there).



PRINT SETTINGS:

-Frame should hold up fine in PLA+ as it's rather thick. However, be cool and print in this filament and your frame will last long time: https://amzn.to/3MP8L12

-Print on the hotter side to ensure good layer adhesion. PLA+(220c)

-No raft or brim needed unless you have difficulty with build plate adhesion

-Use Organic Supports



Required Tools:

* Roll pin punches (or standard pin punches) in sizes: 1/16", 1/8", and 3/16" — for driving all frame pins (grip safety, sear, ejector, trigger, locking block, etc.). Use brass or polymer-tipped to avoid marring the frame.
* Small hammer or brass mallet — for controlled tapping of punches when driving pins in/out (never use a steel hammer directly on pins).
* Slave pin (or temporary alignment pin) — about the same diameter as the magazine catch pin (slightly smaller works best); a long Allen key/hex wrench is commonly used as a makeshift slave pin for the magazine release installation.
* Small flathead screwdriver or dental pick/punch — for compressing/depressing springs (e.g., slide catch spring, magazine spring during prep, or pushing spring legs under pins).
* Pliers (needle-nose recommended) — for holding nuts/screws if needed, or gently bending spring legs.
* Safety glasses — mandatory; multiple small springs are under tension and can fly out.
* Stable work surface — preferably with a soft mat or rag to catch parts and prevent scratches; you can also work inside a clear plastic bag for high-tension springs.
* 

Optional but highly recommended:

* Small container — to organize pins, springs, and parts during the process.
* Flat needl file or sandpaper (e.g., 400-1000 grit) — only if tuning the takedown system (as noted in step 10, for minor material removal on the frame rail area).
* X-Acto blade for trimming the rear rail down when doing the tuning steps.



Required Parts:

Parts Diagram here: https://support.springfield-armory.com/manuals/xd-m-manual?section=6ginKU0zJTLrzVR8majAfQ\&topic=49bvsojftyypSS3oxOuIOh

1. Magazine Release Assembly:

* Magazine latch (catch body)
* Magazine catch button (external paddle/release)
* Magazine catch spring
* Magazine catch pin



2\. Grip Safety Assembly(most parts of grip safety are deleted:

* Grip safety pin



3\. Disassembly/Takedown System (XD-M specific):

* Disassembly lever (external lever on left side)
* Disassembler (internal lifter/push bar that captures the sear)
* Disassembly lever spring
* Disassembly bar (internal forked bar that interacts with the lever)



4\. Fire Control Group:

* Trigger
* Trigger bar
* Trigger spring



5\. Sear \& Safety Components:

* Sear
* Striker safety lever (drop safety)
* Sear spring (main power spring)
* Striker safety lever spring (thinner spring)
* Sear pin



6\. Ejector \& Related:

* Ejector
* Smaller ejector pin (retains spring legs)



7\. Slide Stop / Slide Catch Lever:

* Slide catch lever (slide stop)
* Slide catch spring (or slide stop spring)



8\. PINS PINS PINS

To recap, your kit should have a total of 6 Pins (all frame pins)

* Sear pin (long pin for sear, springs, ejector, striker safety lever)
* Grip safety pin
* Trigger pin / Locking block pin (often shared or separate in some diagrams)
* Front locking block pin (looks the same as trigger pin/interchangeable)
* Magazine catch pin
* Ejector Pin (smallest and shortest pin)



9\. Front Locking Block (metal insert that houses trigger group and interfaces with slide)



10\. Assembled/Complete Slide



11\. Complete magazine in either 13rd or 10rd capacity depending on your frame choice. (45ACP mags)



-----ASSEMBLY STEPS-----

Before proceeding with assembly, remove all support material and REAM PINS. Reaming the pins is a necessary step to ensure that pins do not crack the rear rails. Please take the time to do this. you can install the pin in a drill chuck and spin it in the hole to ream perfectly to size.



1\. Install the Magazine Release

This step is tricky, like on all XD frames. Use a slave pin (slightly smaller than the magazine catch pin works well; a long Allen key is ideal).

* Drop in the magazine latch with the latch facing rearward.
* Hold it in place with the slave pin.
* Pull the slave pin out ~3/4 of the way so it only holds one side.
* Insert the magazine catch spring: shorter leg up/rearward, longer bent leg up/forward. Nest it in the center of the latch.
* Gently push the spring down and retain it through the center with the slave pin.
* Once the latch is half-secured and the spring captured, push the latch slightly aside and slide in the magazine catch button from the outside.
* Push the latch forward to align the holes, then drive the permanent pin through the frame (pushing out the slave pin). This may take several attempts.



2\. Install the Disassembler, Disassembly Lever Spring, and Grip Safety Pin

* Start from the right side of the frame. Insert the grip safety pin just far enough to protrude slightly inside.
* Add the disassembler, then the disassembly lever spring (long leg forward, short leg against the back of the frame).
* Slide the pin the rest of the way through until centered/flush.
* Push the disassembler rightward against spring pressure.
* Bend the long leg of the spring back/over to hook into the designated spot on the back of the disassembler. This forces the disassembler fully forward (it will be corrected later).



3\. Install the Sear Pin, Striker Safety Lever, Sear, and Bundled Springs  From the right side, insert the sear pin just far enough to protrude slightly inside.

* Rotate the disassembler backward slightly against spring pressure so the pin can seat.
* Add the striker safety lever to the pin, then slide the pin further until roughly flush with the lever's side.
* Add the sear, sliding the pin just far enough to protrude slightly into the sear.
* Install the bundled springs:
*  	Thinner spring for the striker safety lever—hook it on top to push the lever downward.
*  	Sear spring (wraps around as shown in diagrams).
* Slide the pin through until flush on the other side of the sear.
* Add the ejector, then finish driving the pin through the frame until flush on both sides of the rear rail (no protrusion).



4\. Install the Smaller Ejector Pin

* From the left side, push the ejector pin in about halfway.
* Press both spring legs down underneath the pin.
* Finish driving the pin flush on the left side of the rails.
* If successful, the sear and striker safety lever should now have spring pressure.



5\. Install the Trigger Assembly and Related Parts

* Attach the trigger to the trigger bar.
* Before fully inserting the bar through the trigger, ensure the trigger spring is installed with its hook on the underside of the trigger bar.
* Insert the assembly into the frame, pushing the back of the trigger bar into position next to the sear.
* Place the slide catch lever in position (it rests loosely at this point).
* Add the disassembly bar to the inside right of the frame: forks facing downward, resting in its channel.



6\. Install the Front Locking Block

* Hook one leg of the slide catch spring into the small hole on the left side of the front locking block area.
* Install the front locking block: pivot the rear down first, then the front.
* Watch for interference with the trigger or disassembly bar—keep them aligned.
* Once seated, verify all parts remain in position.



7\. Install the Trigger Pin

* Insert from the right side through the trigger.
* Near the end, you’ll meet resistance from the slide stop spring. Push the spring leg to clear the hole.
* Drive the pin fully through until retained by the groove.



8\. Pre-Check Before Final Springs/Pins

* Verify the trigger drops the sear.
* Check that the slide catch lever has spring tension (push up, release—it should snap downward).
* If no tension, inspect whether the slide stop spring is caught between the locking block and frame. Reinstall the locking block if needed.



9\. Install the Disassembly Lever

* Install the front locking block pin.
* Rotate the disassembly lever to clear the slide stop spring, then press it fully into place.
* Its small tab should interact with the forks of the disassembly bar (pushing/pulling it).
* Test rotation: move to 12:00 (vertical), then back to 9:00 (horizontal). It should move the disassembly bar smoothly.



10\. Test and Tune the Takedown System

* Set the disassembly lever to 12:00.
* Pull the trigger—the sear should not move.
* Press the back of the sear downward with your thumb—it should catch in the takedown position.
* Rotate the lever to 9:00—it should release the sear.
* Watch for the disassembler moving during lever rotation.
* If the disassembler fails to capture the sear properly, the slide may stick later. Gently file the angled surface where the striker safety lever rests on the frame (right side, front of rails) until function is smooth. You will want to remove material here until the system functions as required.
* When correct, the slide removes without trigger pull, and the disassembler captures/releases the sear reliably.



11\. Final Functional Checks

* With the disassembly lever at 12:00, install the assembled slide and manually lock it back using the slide catch.
* Rotate the lever to 9:00 and drop the slide.
* Verify the trigger releases the striker.
* Insert the magazine, rack the slide—it should lock back on empty.
* Confirm the magazine drops free.
* Test with snap caps for feeding/ejection. If all functions correctly, the pistol is ready.





-----ASSEMBLY OF +2 MAGAZINE Extension-----

The magazine extension should add 2 rounds of capacity and is intended to be used on 13 round magazines.



Required Tools \& Parts

* M2x10mm Socket Head Screw (1)
* Small flathead screwdriver or punch (for depressing the factory retainer)
* Allen wrench/hex key (for the socket head screw)
* Safety glasses



Assembly Steps

1. Remove the Factory Baseplate

* Point the bottom of the magazine away from your face/body.
* Depress the exposed portion of the magazine baseplate retainer (visible through the hole in the bottom of the factory baseplate) using a small screwdriver or punch.
* While holding the spring down, carefully slide the factory baseplate forward/off the magazine tube.
* Slowly release pressure on the spring—control it as the baseplate comes free.
* Remove the internal baseplate lock/retainer (small plastic insert with nipple on bottom) if present. You won't reuse it.
* The magazine spring and follower should now be accessible but still partially compressed in the tube.



2\. Prepare the Magazine

* Push the magazine spring fully into the bottom of the tube (compress it downward) to create clearance.
* Hold it compressed with your thumb or a tool if needed.



3\. Install Magazine Extension

* Slide the extension onto the bottom of the magazine tube from the rear (back edge first).
* Push it fully forward until it seats firmly against the back lip/tab of the magazine tube.
* Ensure it aligns straight and sits flush with no wobble.
* Ensure the magazine spring is flush on the base of the extension so the spring doesn't twist or bind inside it.



4\. Secure the Assembly

* Insert the M2x10mm socket head screw from the bottom to block the magazine from sliding off the extension



6\. Final Checks

* Ensure the follower moves freely up/down.
* Insert the magazine into your unloaded XD-M pistol.
* Rack the slide a few times (with snap caps if testing function).
* Verify smooth insertion, lock-back on "empty," and free drop when the slide is locked back.
* If the magazine binds or doesn't drop free, recheck alignment, tightness, and spring orientation.



-----TROUBLESHOOTING-----

The most common issue you may experience is with the automatic takedown system. Refer to tuning steps to get this running correctly. If, after everything is working properly, the sear is still catching the striker and not allowing takedown, this is a sign that your rear rails are out of spec or your frame is warped. You will be able to use a small pick at the back of the slide to push the striker down and remove the slide. From here, you have two options. Option 1 is to file the rails to let the slide sit higher. Option 2 is to remove the auto-disassembly parts. Up to you!





Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself.



https://dbdesignworks.com

