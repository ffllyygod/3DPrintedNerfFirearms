DB's Integrated Rail/Red Dot mount for Southern Tactical VZ61 Receivers
Mounts to existing holes on back of receiver. Designed for RMR footprint red dot sight.

NOTE: will likely have fitment issues with Czechpoint receiver, but may work.
It was not tested on Czechpoint receivers. 

Required Hardware: 

2x #8x.5" bolts for ST receiver rear.
2x M3x10mm bolts to mount red dot
2x M3 nuts to mount red dot
2x red dot pins for RMR mount. You can yank these out of the mount that came with your RMR
(note: you can use this without the pins but the pins do help make it secure)
1x M4x20mm flat head screw to mount rear rail
1x M4x15mm flat head screw to mount rear rail
2x M4 nuts
1x M3x45 dowel pin or rod to stiffen red dot mount
1x 5 slot aluminum picatinny rail for MLOK

Printing Suggestions: I strongly urge you to print this in something other than
PLA,something stronger. Will PLA work? Yes. I'm just not convinced it has the longevity
that you will be satisfied with. I suggest a Nylon filled filament like Polymaker PA6 or
Matterhackers NylonX. Print in the orientation given in the files. 

Assembly Suggestions: 
1. After removing any supports, insert the 3mm rod into the mount to help stiffen it. 
It should tap in without any reaming. However, if it's too tight, you can drill the hole out
first and then install the rod. If you have to drill it out, you may want to add some glue to the rod.
Otherwise, glue should not be required.

2. Install the dowel pins to mount your red dot. These should pull out of your existing mount with a pair of plyers. 
They will press in. 

3. Install the M3 nuts on the bottom of the mount, then install your RMR style red dot. Use the M3 screws to secure
the Red dot to the mount. Blue threadlocker is suggested.

4. Install the M4 screws in the back of your mount before proceeding. Then, push the mount from the back onto your ST receiver. 
Install the back screws to secure the mount. Blue threadlocker is suggested. Try not to over-tighten these as it will bend the mount.

5. Now, install your rail with the M4 flat head screws to finish your installation. Once again, a dab of blue threadlocker is suggested.

DONE

THis is a free file. If you paid for it, the seller violated the creative commons license. Report to DB on Social Media. 

