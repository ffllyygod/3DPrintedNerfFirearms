DB Firearms Presents: 

DB's JMAC AB Brace End

Version: Beta 1.1
Changelog: 1- initial release
1.1-Added support for the Raised style of brace which requires a shorter mount section. 

Special thanks to: Dogenado for editing the brace end to fit raised braces.

Description: This is a brace end (loosely copied from a strike industries brace) designed to fit
on a JMAC AB. It uses the cross hinge pin hole to secure to the AB. It requires some M6 hardware. 

This was designed using a clone brace, so I am hoping to get some feedback on a real JMAC AB to make sure it's fully compatible. 

Print Suggestions: Do not recommend a weak filament as the brace is not super robust. This will work best in a nylon CF filament or another filament with very good layer adhesion. Print in the suggested orientation that the file will load in your slicer. It is at 45 degrees. Use supports everywhere - Tree/organic supports are suggested. 

Hardware: 
1x M6x25 button head bolt. https://www.mcmaster.com/97763A436/
1x M6 thin hex nut. https://www.mcmaster.com/96315A116/

Optional extras: 
1x Hyperion heat set QD Socket. https://hyperion2a.com/product/heat-set-quick-disconnect-inserts/
1x 1" brace strap from Phase 5. https://phase5wsi.com/sb-ar-pistol-brace-upgrade-strap-1-inch-clone.html

Assembly: This was designed to be very snug on the AB. You may want to gently tap it on until the cross hole lines up correctly with the brace. Use a soft faced mallet or something plastic to tap it on. 
Install the cross bolt and use some loc-tite on it, don't over-tighten. Just snug (around 5 in lb)
Install your hyperion heat set QD socket with a soldering iron in the back of the brace end
Install your 1" brace strap. 

Please provide all feedback via X https://twitter.com/ArthurClaudeen