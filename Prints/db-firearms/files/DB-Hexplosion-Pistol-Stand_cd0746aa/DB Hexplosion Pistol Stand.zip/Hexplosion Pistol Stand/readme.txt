HEXPLOSION Pistol Stand by DB Firearms

Description: Simple pistol stand. This will obviously not fit all pistols.

Known compatibility: 
Glock 9mm/40 near perfect fit
2011 (LOOSE FIT SIDE TO SIDE)

DOES NOT FIT:
Sig P320
Most metal magazine double stack pistols.


May fit your model. If not, it has the .step file so you should be able to modify the magwell tower to fit your frame. 


Printing: Print with base flat on bed. For a nice finish, I suggest to turn on Ironing on top layers. This will give a nice flat texture on the top of the hexagons.
Material: this should work in pretty much any filament. I used PLA+. 
Infill: Recommended 2+ walls and top/bottom layers minimum with 25% infill. Feel free to increase amount of walls for a more rigid stand.

No supppots necessary. 

dbdesignworks.com

License: Creative Commons Non Commercial share-alike. 