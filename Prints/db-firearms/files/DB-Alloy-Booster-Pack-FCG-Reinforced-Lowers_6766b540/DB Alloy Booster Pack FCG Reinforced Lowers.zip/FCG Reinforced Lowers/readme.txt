DB ALLOY
Fire Control Group Reinforcement BOOSTER PACK

For full documentation, please refer to the original DB Alloy download on Odysee
HERE: https://odysee.com/@db-firearms:4/DB-Alloy-Official-Release-1.0:4

Summary: these are lower receivers for the DB Alloy that are compatible with the
metal fire control group reinforcement plates found here: https://odysee.com/@db-firearms:4/DBs-FCG-Reinforcement-Dev-Pack-V1:4

These plates should help solve the most common FCG issues with 3d printed receivers using
AR-15 hammer, trigger, safety selector. 

Instructions: Print in the orientations that come pre-loaded with .stl files
Print according to original instructions in DB Alloy release Instructions. 

Required components: 
2x reinforcement plates
anti walk trigger and hammer pins with screws on ends
I also suggest an ambidextrous safety selector. 

Installation: Install the plates in place, then install your FCG, tighten screws with some blue loc-tite
Install safety selector in the same manner and enjoy!

If you paid for these files, it is a violation of the license. Share your build with me on 
social media! dbdesignworks.com

Have Fun,
DB