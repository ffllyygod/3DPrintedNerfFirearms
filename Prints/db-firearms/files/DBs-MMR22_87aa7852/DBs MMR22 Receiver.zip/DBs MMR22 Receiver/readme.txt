Introducing: DB's MMR22 (MULTI-MODEL RECEIVER 22)

This receiver is designed to work with the following 22LR parts kits:

Rossi RS22
Mossberg 702 Plinkser
Mossberg 715 (All Variants)
Citadel TRAKR (All Variants)
Magtech 7022

When purchasing parts kits for these guns, please note the shape of the barrel, you want the perfectly
round breech end for your kit. If your barrel has something different, like a flat spot on the bottom, it will
require modification in CAD to work with this printable receiver. 

SAFETY WARNING: THis receiver must be printed in a high quality filament. The walls are not thick and require
good layer adhesion and strength. If you are printing in PLA+, please choose a good brand, dry your filament, and print hot.

BY PRINTING THIS DESIGN YOU ASSUME ALL RESPONSIBILITY FOR YOUR SAFETY

Required Components:
One of the above complete parts kits. You need everything minus the receiver. 

Required Extra parts:
2x M5 square nuts for securing the receiver in the stock or chassis (front and back)


----SELECTING YOUR RECEIVER----
There are two receivers, one has a rail. The other does not. If you are printing this design to use in the Mossberg 715
you will want to print the rail-less receiver so it fits. Otherwise it will not work for you.

----PRINT ORIENTATION----
The receivers have been oriented already for slicing. However, if you find this orientation challengning, you can try a straight horizontal
orientation. Do not print the receiver vertically, it will not have the required strength. 

----MATERIALS----
Print in PLA+ or better. I suggest a carbon fiber nylon like NylonX for a long lasting design

----PRINT SETTINGS----
I do not typically provide detailed print settings. You should know and understand your machine and its capabilities. You want a strong print
so choose settings that support that goal. Solid Infill and printing 5-10 degrees hotter is a good start. Use organic/tree supports to support 
your model in printing. Use a brim so your print does not come off the build plate during printing.

---POST PROCESSING----
Remove support material and then snap off the little tabs designed to stabilize the receiver during printing. Now let's get going!

----ASSEMBLY INSTRUCTIONS----

This will assemble just like a standard receiver. here is a good video outlining the process: https://www.youtube.com/watch?v=lCGUmXrmTrQ

1. You will want to first drop an m5 nut into the front of your receiver inside the barrel hole. Then, install your barrel by slowly 
spinning it until it is fully seated in your receiver. Then, gently tap in the two pins to secure it.
Be careful during this process to avoid damaging your receiver. Reaming these holes should not be necessary. 

2. Install the recoil guide rod and spring in your bolt. Push the face of the bolt into the front of the receiver. While doing so, compress the spring and plunger.
Push them both down until you can get the guide rod into its corresponding hole. PLEASE TAKE CAUTION TO AVOID CRIMPING THE SPRING.

3. Before you forget, add your charging handle by tilting the bolt down slightly and sliding it in, then push the bolt back up. Then
don't forget to add your buffer in the back.

4. Next, pull your bolt all the way back and slot in your trigger pack. Pushing the bolt forward will slot it into the sheet metal
guide in the trigger pack. Push the bolt forward. At this stage you are ready to install the trigger pack pins.

5. Install your trigger pack pins gently. These are a press fit. You should be able to tap them in very easily but ensure that you are  supporting
the back of the receiver with a table so it doesn't bend out when tapping in. The plastic in this area is thin. It is what it is, be careful you big gorilla!

6. slot the other M5 nut into the back of your receiver. Install the receiver in your stock and tighten down the two M5 screws to secure it. Don't over-tigten as this will
cause your receiver to bend and crack. Go till tight and then another 1/4 turn and call it good.

7. At this stage you may find that your bolt is a little bit sticky. If not, congrats! If it is, have no fear, we need to bed in the bolt to your receiver. 
Since this is plastic, we never know how the tolerances are going to turn out. In order to bed this bolt into the receiver, use some of your favorite lube and work the bolt
until things free up and you can pull the bolt back and have it snap forward on its own. Do that about 100 times and you're good to go!

8. Extra steps for Mossberg 715, you will need to do some stuff with the mag release and screw your clamshell together. if you need help, here's a good video: https://www.youtube.com/watch?v=eH4TDaJkLpQ&t=650s

DONE, enjoy! 

DBDESIGNWORKS.COM