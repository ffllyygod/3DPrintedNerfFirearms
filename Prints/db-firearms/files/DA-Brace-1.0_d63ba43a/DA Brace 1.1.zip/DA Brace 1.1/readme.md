# DA Brace (DAEDALUS ALLOY)
by DB Firearms
V1
## Description
This pistol stabilizing brace was originally designed for the DAEDALUS project. It has been revised to fit the DB Alloy with a custom hinge and brace bodies. This version is not compatible directly with the DAEDALUS anymore and is a standalone version for the DB ALLOY.

## Variants
It comes in standard length, +1", and +2". It also comes with two dropped versions where the brace is lower than the standard version for better cheek weld.  

## Additional Hardware Required

Consider supporting the developer buy purchasing a hardware kit at https://dbdesignworks.com/store/p/da-brace

- x1 M5x30mm Button Head Screw (Rail Clamp Screw)
- x1 M5 Nut (Rail Clamp Nut)
- x1 2mmx30mm Dowel Pin (Brace Button Retainer)
- x1 4mmx40mm Dowel Pin (Brace Hinge Pin)
- x1 Compression Spring: .3" OD, .375" Long (Brace Button Spring)
- x1 1/4" x1/2" magnet


## Instructions
1. Print all parts in the orientation that loads in your slicer. This can be printed in other orientations if you have a bed slinger, or have other reasons. It's an awkward part...hopefully you can find a decent way of printing. The way it loads in your slicer is how I printed it.

2. Once all of your parts are printed, you're ready to assemble. Start by attaching the hinge to your brace, then gently hammer in the hinge pin. It should not need to be reamed to size, it is slightly oversized. It will however be tight. Install the magnet in the side of your brace. It can be held in place with a small amount of super glue. It is designed to be held against the upper receiver magnetically. 

3. Install your brace button with the compression spring underneath. Slot in the 2mm pin to retain the button. The latch portion should clip into the brace body when closed. If it does not or if you have poor button retention, refer to troubleshooting at the bottom of this readme.

4. Slide your brace onto the rail of your DB ALLOY and install the M5 screw and nut. Tighten down until snug. You can add some blue thread locker to this screw to keep it secure.
 
## Troubleshooting
All of your issues related to the brace latching are likely a result of either support material interfering with the button latching into the hinge portion, or the latch not completely latching onto the hinge due to excess material. To solve this, file down the flat face of the latch that is perpendicular to the button face. See image 1 in files. Continue to remove material slowly and re-test to ensure that you get the latch button to move all the way UP into the hinge to lock the brace.

## Change Log

- v1.0 Initial Release

## License
Creative Commons Share-alike Non Commercial. Please don't share files during the beta process.
