    \_\_\_\_  \_\_\_\_     \_\_\_\_\_\_\_\_\_\_\_\_\_\_  \_\_\_\_\_\_\_\_\_    \_\_\_\_  \_\_  \_\_\_\_\_\_\_\_

   / \_\_ \\/ \_\_ )   / \_\_\_\_/  \_/ \_\_ \\/ \_\_\_\_/   |  / \_\_ \\/  |/  / \_\_\_/

  / / / / \_\_  |  / /\_   / // /\_/ / \_\_/ / /| | / /\_/ / /|\_/ /\\\_\_ \\

 / /\_/ / /\_/ /  / \_\_/ \_/ // \_, \_/ /\_\_\_/ \_\_\_ |/ \_, \_/ /  / /\_\_\_/ /

/\_\_\_\_\_/\_\_\_\_\_/  /\_/   /\_\_\_/\_/ |\_/\_\_\_\_\_/\_/  |\_/\_/ |\_/\_/  /\_//\_\_\_\_/

 



++++++++Springfield XD 9/40 INFINITY by DB Firearms++++++++





This frame is designed to turn your Springfield XD 9mm \& 40 parts kit back into a functional firearm. YAY!

The main frame was edited from the work of 458SOCOM (THE XD KING) Be sure to thank 458SOCOM for his hard work in making this a reality!



Frame textures: The frames are pre-textured using blender. However, if you want to texture your own, blank STL's are included as part of this release.



PRINT ORIENTATION:

-All frames have been pre-oriented in their ideal print orientation(Rails Down, upside-down on build plate). If you are printing in a Nylon based filament, you may choose to rotate it 45 degrees (printed upside down, at 45 degrees on the nose. there is a small flat area there).



PRINT SETTINGS:

-Frame should hold up fine in PLA+ as it's rather thick. However, be cool and print in this filament and your frame will last long time: https://amzn.to/3MP8L12

-Print on the hotter side to ensure good layer adhesion. PLA+(220c)

-No raft or brim needed unless you have difficulty with build plate adhesion

-Use Organic Supports



Required Tools:

* Roll pin punches (or standard pin punches) in sizes: 1/16", 1/8", and 3/16" — for driving all frame pins (sear, ejector, trigger, locking block, etc.). Use brass or polymer-tipped to avoid marring the frame.
* Small hammer or brass mallet — for controlled tapping of punches when driving pins in/out (never use a steel hammer directly on pins).
* Slave pin (or temporary alignment pin) — about the same diameter as the magazine catch pin (slightly smaller works best); a long Allen key/hex wrench is commonly used as a makeshift slave pin for the magazine release installation.
* Small flathead screwdriver or dental pick/punch — for compressing/depressing springs (e.g., slide catch spring, magazine spring during prep, or pushing spring legs under pins).
* Pliers (needle-nose recommended) — for holding nuts/screws if needed, or gently bending spring legs.
* Safety glasses — mandatory; multiple small springs are under tension and can fly out.
* Stable work surface — preferably with a soft mat or rag to catch parts and prevent scratches; you can also work inside a clear plastic bag for high-tension springs.
* 

Optional but highly recommended:

* Small container — to organize pins, springs, and parts during the process.
* Flat needle file or sandpaper for cleaning up supports and holes.



Required Parts:

Parts Diagram here: https://support.springfield-armory.com/manuals/xd-manual?section=5eXqvXArGn7v1UekmSa03C\&topic=2roRtopNEBwbc6mOqAHNCM

1. Magazine Release Assembly:

* Magazine latch (catch body)
* Magazine catch button (external paddle/release)
* Magazine catch spring
* Magazine catch pin



2\. Fire Control Group:

* Trigger
* Trigger bar
* Trigger spring



3\. Sear \& Safety Components:

* Sear
* Striker safety lever (drop safety)
* Sear spring (main power spring)
* Sear pin



4\. Ejector \& Related:

* Ejector
* Smaller ejector pin (retains sear spring leg)



5\. Slide Stop / Slide Catch Lever:

* Slide catch lever (slide stop)
* Slide catch spring (or slide stop spring)



6\. PINS PINS PINS

To recap, your kit should have a total of 5 Pins (all frame pins)

* Sear pin (long pin for sear, spring, ejector, striker safety lever)
* Trigger pin / Locking block pin (often shared or separate in some diagrams)
* Front locking block pin (looks the same as trigger pin/interchangeable)
* Magazine catch pin
* Ejector Pin (smallest and shortest pin)



7\. Front Locking Block (metal insert that houses trigger group and interfaces with slide)



8\. Assembled/Complete Slide



9\. Complete magazine (Full size only) in 16rd for 9mm or 12rd for 40S\&W. It is not recommended that you use promag magazines.



-----ASSEMBLY STEPS-----

Before proceeding with assembly, remove all support material and REAM PINS. Reaming the pins is a necessary step to ensure that pins do not crack the rear rails. Please take the time to do this. you can install the pin in a drill chuck and spin it in the hole to ream perfectly to size.



1\. Install the Magazine Release

This step is tricky, like on all XD frames. Use a slave pin (slightly smaller than the magazine catch pin works well; a long Allen key is ideal).

* Drop in the magazine latch with the latch facing rearward.
* Hold it in place with the slave pin.
* Pull the slave pin out ~3/4 of the way so it only holds one side.
* Insert the magazine catch spring: shorter leg up/rearward, longer bent leg up/forward. Nest it in the center of the latch.
* Gently push the spring down and retain it through the center with the slave pin.
* Once the latch is half-secured and the spring captured, push the latch slightly aside and slide in the magazine catch button from the outside.
* Push the latch forward to align the holes, then drive the permanent pin through the frame (pushing out the slave pin). This may take several attempts.



2\. Install the Sear Pin, Striker Safety Lever, Sear, and Sear Spring

* From the right side, insert the sear pin just far enough to protrude slightly inside.
* Add the striker safety lever to the pin, then slide the pin further until roughly flush with the lever's side.
* Add the sear, sliding the pin just far enough to protrude slightly into the sear.
* Install the sear spring.
* Slide the pin through until flush on the other side of the sear.
* Add the ejector, then finish driving the pin through the frame until flush on both sides of the rear rail (no protrusion).



3\. Install the Smaller Ejector Pin

* From the left side, push the ejector pin in about halfway.
* Press sear spring leg down underneath the pin.
* Finish driving the pin flush on the left side of the rails.
* If successful, the sear and striker safety lever should now have spring pressure.



4\. Install the Trigger Assembly and Related Parts

* Attach the trigger to the trigger bar.
* Before fully inserting the bar through the trigger, ensure the trigger spring is installed with its hook on the underside of the trigger bar.
* Insert the assembly into the frame, pushing the back of the trigger bar into position next to the sear.
* Place the slide catch lever in position (it rests loosely at this point).



5\. Install the Front Locking Block

* Hook one leg of the slide catch spring into the small hole on the left side of the front locking block area.
* Install the front locking block: pivot the rear down first, then the front.
* Watch for interference with the trigger or disassembly bar—keep them aligned.
* Once seated, verify all parts remain in position.



6\. Install the Trigger Pin

* Insert from the right side through the trigger.
* Near the end, you’ll meet resistance from the slide stop spring. Push the spring leg to clear the hole.
* Drive the pin fully through until retained by the groove.



7\. Pre-Check Before Final Springs/Pins

* Verify the trigger drops the sear.
* Check that the slide catch lever has spring tension (push up, release—it should snap downward).
* If no tension, inspect whether the slide stop spring is caught between the locking block and frame. Reinstall the locking block if needed.



8\. Final Functional Checks

* Verify the trigger releases the striker.
* Insert the magazine, rack the slide—it should lock back on empty.
* Confirm the magazine drops free.
* Test with snap caps for feeding/ejection. If all functions correctly, the pistol is ready.





-----ASSEMBLY OF +2 MAGAZINE EXTENSION-----

The +2 magazine extension is intended to be used on 16rd mags to add an additional 2 rounds to your capacity.



Required Tools \& Parts

* M2x20mm grub screw or dowel pin (1)
* Small flathead screwdriver or punch (for depressing the factory retainer)
* Allen wrench/hex key (if selecting the grub screw method)
* Safety glasses



Assembly Steps

1. Remove the Factory Baseplate

* Point the bottom of the magazine away from your face/body.
* Depress the exposed portion of the magazine baseplate retainer (visible through the hole in the bottom of the factory baseplate) using a small screwdriver or punch.
* While holding the spring down, carefully slide the factory baseplate forward/off the magazine tube.
* Slowly release pressure on the spring—control it as the baseplate comes free.
* Remove the internal baseplate lock/retainer (small plastic insert with nipple on bottom) if present. You won't reuse it.
* The magazine spring and follower should now be accessible but still partially compressed in the tube.



2\. Prepare the Magazine

* Push the magazine spring fully into the bottom of the tube (compress it downward) to create clearance.
* Hold it compressed with your thumb or a tool if needed.



3\. Install Magazine Extension

* Slide extension onto the bottom of the magazine tube from the rear (back edge first).
* Push it fully forward until it seats firmly against the back lip/tab of the magazine tube.
* Ensure it aligns straight and sits flush with no wobble.
* Ensure that the spring is seated flat on the bottom of the extension to prevent the follower from binding.



5\. Secure the Assembly

* Install the dowel pin or grub screw at the back of the extension to prevent the extension from sliding off. You may want to add some super glue if you're using the dowel pin method.



6\. Final Checks

* Ensure the follower moves freely up/down.
* Insert the magazine into your unloaded XD pistol.
* Rack the slide a few times (with snap caps if testing function).
* Verify smooth insertion, lock-back on "empty," and free drop when the slide is locked back.
* If the magazine binds or doesn't drop free, recheck alignment, tightness, and spring orientation.





-----TROUBLESHOOTING-----

The most common issue you may experience is that the trigger does not allow you to fully drop the striker. If the trigger travel is not sufficient to do that, you'll want to tune the trigger slightly. First, you can remove the slide by following the normal takedown method. However, when you get to the step of removing the slide, you'll need to insert a small flat head screwdriver into the rear of the slide to push the sear down and release the striker.



Now, inspect the locking block to notice that there is a face visible above the trigger where the trigger will hit the locking block. That face can be gently filed down until it increases trigger travel. Remove about half the material, re-install, and check trigger function again.



Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself.



https://dbdesignworks.com

