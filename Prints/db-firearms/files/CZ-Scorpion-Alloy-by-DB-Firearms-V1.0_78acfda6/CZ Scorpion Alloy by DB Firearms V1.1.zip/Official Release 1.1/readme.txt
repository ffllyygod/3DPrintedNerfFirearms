
    ____  ____     ______________  _________    ____  __  ________
   / __ \/ __ )   / ____/  _/ __ \/ ____/   |  / __ \/  |/  / ___/
  / / / / __  |  / /_   / // /_/ / __/ / /| | / /_/ / /|_/ /\__ \ 
 / /_/ / /_/ /  / __/ _/ // _, _/ /___/ ___ |/ _, _/ /  / /___/ / 
/_____/_____/  /_/   /___/_/ |_/_____/_/  |_/_/ |_/_/  /_//____/  
                                                                  

++++++++CZ Scorpion Alloy by DB Firearms++++++++

CHANGELOG: 1.0 First Release
1.1: Edited rear receiver to accept stocks (added notch), added safety cutouts in receiver.
DISCLAIMER: This is a DIY project - you are doing it yourself. Congrats! Because of this, you take all responsibility for injury, loss of property, damage to property, 
or damage to your family when you spend 3 hours tapping holes in your garage. It's your party so don't blame me if something goes wrong. 

The next generation in hybrid 3d printed designs - the Scorpion Alloy is a 3d printed CZ Scorpion receiver paired with a laser cut metal cage
that reinforces the receiver and makes it much more robust and safe. It is fully DIY and can be made with a hobbyist grade printer. In order to simplify
this release, please refer to the original CZ Scorp release by AWCY? for additional files including printable handguards, grips, and stocks/braces. 

Some changes were made to these files beyond the metal inserts, though they started from the AWCY? Scorp - special thanks to the AWCY? team that worked
on this project originally. Changes made were to slim down the profile of the receiver to match the OEM Scorpion width. Additionally, the top rail is now
to spec - so it will work with the Bullpup receiver kit. 

FOR A FULL RECEIVER HARDWARE KIT VISIT db-firearms.com

REQUIRED HARDWARE: 
(27) M3 x 6mm Flat Head Screws : https://www.mcmaster.com/91294A126/ (METAL INSERT SCREWS)
(4) M4 x 12mm Socket Head Screws : https://www.mcmaster.com/91290a148/ (TOP RECEIVER SCREWS)
(1) M4 x 40mm Socket Head Screw : https://www.mcmaster.com/91290A184/ (TOP TRUNNION SCREW)
(1) M4 x 35mm Socket Head Screw : https://www.mcmaster.com/91290A182/ (BOTTOM TRUNNION SCREW)
(1) M4 x 22mm Socket Head Screw : https://www.mcmaster.com/91290A170/ (REAR RECEIVER SCREW)
(7) M4 Nuts : https://www.mcmaster.com/90593A003/ (RECEIVER NUTS)

NOTE: THIS PARTS LIST DOES NOT CONTAIN ANY OF THE PARTS FOR THE REST OF THE SCORPION - SPECIFICALLY YOU WILL NEED A SPRING TO GO BEHIND THE STOCK RELEASE
BUTTON IN THE REAR. REFER TO ORIGINAL SCORP DOWNLOAD FOR ADDITIONAL DETAILS

THE ABOVE HARDWARE + THE METAL PLATES TAPPED AND READY FOR INSTALL ARE AVAILABLE AT db-firearms.com

PRINT ORIENTATION: 
The receivers have been designed to be printed at 45 degree angles and small support blocks have been added for the grip mounting point. Files should be oriented correctly
in the STL. 
If you have issues with this orientation you can try others. I also have printed with receiver FLAT on build plate - internal surface down on build plate. This results
in a strong and visually appealing receiver though the inside can take some post processing.

PRINT SETTINGS: 
-Use PLA+ or better. ABS or filled nylon is preferred to prevent warping on warm days or if left in vehicle. 
-Print on the hotter side to ensure good layer adhesion. PLA+(210c) ABS(250c) 
-Use a raft or brim if you have difficulty with build plate adhesion or warping
-Supports on build plate should be sufficient

INSTRUCTIONS FOR METAL INSERTS: 
-The metal inserts are designed to be laser cut. For ordering instructions please refer to the instructions in the laser cut folder. 
-Once you receive your inserts from the laser cutter, you will need to tap the holes with an M3 tap. Your best bet would be to ensure that the holes are 
to spec - drill them to 2.5mm if they don't measure that already.
-Tap holes with M3x.5 tap. If you do not have experience tapping holes, it can be difficult in Stainless Steel. So, to ensure success you can stick to the following tips:

TAPPING TIPS: 
-Use fresh taps. Get a pack of several high quality ones.  
-Use tapping fluid - if you don't have some, order some good stuff to keep your taps fresh and cool
-Use a tap holder
-go slow 1/2 to 1/4 turn at a time, and back off to clear chips. 
-M3 taps are small and typically don't work well with power tools like impact drivers or hand drills. 


ASSEMBLY INSTRUCTIONS: 
-Once you have all of your parts and your threads are all tapped (congratulations) you are ready to proceed. Start by test fitting your metal pieces. They should
fit together like a puzzle with the rear plate, side plate, and front trunnion clamp all together. The trunnion clamp should be oriented with the flat on the round
piece up.
-First insert the side plates into your print and ensure they're sat all the way against the print. Clear any stray plastic that may prevent your metal plates from sitting down
all the way. 
-Second, insert your back plate and push in and down. it may take some force to get it down flush with the back inside wall of the receiver. 
-Press in your trunnion piece last and ensure it fits flush with receiver. 
-Install the metal insert screws one at a time. I use blue thread locker ensuring caution to not allow it to touch the plastic of the receiver.
-Don't over-tighten these or it could split or crack your print. Tighten until snug and the metal plates are sunk down flush with print. You can install
these all and then slowly tighten them one at a time until tight. 
-Glue shims are included to cover the gaps left by installing the plates near the front trunnion. You glue them in with super glue if printing in PLA, but if printing
in ABS you can use acetone to fuse them in. They are aesthetic and the receiver will operate without them. 

-From here it's standard scorpion stuff. Join your receiver sides together with the trunnion barrel assembly in the middle. Since you have metal plates clamping
the trunnion now, you will reach a point where if you over tighen the screws it will deform the plastic. Be careful and don't go too hard on them.

Questions or concerns? Message me on twitter.

Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself. 

https://db-firearms.com
