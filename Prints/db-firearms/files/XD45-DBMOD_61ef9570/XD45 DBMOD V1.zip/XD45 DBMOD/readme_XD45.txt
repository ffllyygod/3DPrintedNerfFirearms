
    ____  ____     ______________  _________    ____  __  ________
   / __ \/ __ )   / ____/  _/ __ \/ ____/   |  / __ \/  |/  / ___/
  / / / / __  |  / /_   / // /_/ / __/ / /| | / /_/ / /|_/ /\__ \ 
 / /_/ / /_/ /  / __/ _/ // _, _/ /___/ ___ |/ _, _/ /  / /___/ / 
/_____/_____/  /_/   /___/_/ |_/_____/_/  |_/_/ |_/_/  /_//____/  
                                                                  

++++++++XD45 DBMOD++++++++


This is an aesthetically pleasing and ergonomic XD45 Full Size frame compatible with XD45 Parts Kits only. 
Other XDM/MOD.2/SUBCOMPACT Coming soon in a separate release.

This frame is entirely possible thanks to 458SOCOM and the team that helped develop and test the base frame. I wouldn't have picked up this project without them ALL CREDIT TO THEM!!!

NOTE: This build will not use the grip safety - SORRY. 

PARTS REQUIRED: 

1. XD-45 parts kit, should include the following parts 
	-Trigger
	-Trigger Bar
	-Trigger Spring
	-Front Locking Block
	-Slide Catch Spring
	-Slide Catch
	-Takedown Lever
	-Ejector
	-Sear
	-Mag Catch & Button
	-Mag Catch Spring & Pin
	-Sear Spring
	-Firing Pin Safety Lever
	-Rear sear pin
	-Rear grip safety pin (only the pin)
	-2x locking block/trigger pins
	-Ejector Pin
	-Complete slide and barrel assembly
	-Magazine (full size 13rd)


PRINTED PARTS: 
1. Frame
2. Optional +2 Magazine Extension (with M2x10mm Socket head bolt to secure mag body)

PRINT ORIENTATION: 
-Frame has been pre-oriented in its ideal print orientation(Rails Down, upside-down on build plate). If you are printing in a Nylon based filament, you may choose to rotate the frame 45 degrees. 

PRINT SETTINGS: 
-Frame was tested with PLA+ and proved to be very robust. 
-Print on the hotter side to ensure good layer adhesion. PLA+(220c)
-No raft or brim needed unless you have difficulty with build plate adhesion
-Use Organic Supports

ASSEMBLY INSTRUCTIONS: 
-This is a very simple frame to assemble. This is a good video that might help if you get stuck: https://www.youtube.com/watch?v=eXggcrtJiIs&pp=ygUXWEQgY29tcGxldGUgZGlzYXNzZW1ibHk%3D

1. after removing all supports, check that your magazine catch button slides without any interference in the pocket for it. If not, take a needle file and gently remove material until there is no more friction with the magazine catch. Next, add your magazine catch and spring. Install the pin about halfway through the mag catch and capture the spring. Now, you should be able to insert your magazine catch button. Finish installing the pin and it should capture the button in place. 
2. Assemble your trigger bar on the trigger, adding the trigger spring, and drop it into the frame. 
3. Add your slide stop on the frame, then install the front locking block (with spring nested on the left) over the whole assembly. The slide stop should find its place to the left of the locking block/rail. Add the two pins to secure the trigger, slide catch, and locking block.
4. Add your rear firing pin safety lever and sear combo, and install pin halfway. Add the sear spring in the middle of the sear and slot the ejector in place. Finish installing the pin until it is flush on both sides.  
5. Install the front ejector pin so it protrudes about 2mm past the ejector. Now, tension the sear spring on the ejector pin and push the pin until it's flush with the rear rails on the left side. 
6. Install the grip safety pin at the back of the frame. You'll need to move the sear forward slightly with your finger so it doesn't block that hole anymore. 
7. Check that your trigger is able to pull down the sear. Next, install the takedown lever by rotating and pushing in. Keep it in the up position.
8. Install slide and lock back with the slide catch. Rotate takedown lever and release slide. Check trigger function. 
7. Check magazine retention and ejection. 



Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself. 

Creative Commons License Share-Alike Non-Commercial. 

https://dbdesignworks.com
