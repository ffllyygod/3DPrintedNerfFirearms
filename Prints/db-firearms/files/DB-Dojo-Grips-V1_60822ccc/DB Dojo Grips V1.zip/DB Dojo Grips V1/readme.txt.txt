░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▓████▓▓░░░░░░▒▓████▓▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█████████░░░░▒████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█████████░░░░▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█████████░░░░▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░█████████░░░░▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒████████▓░░░░▒█████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▓█████████▓░░░░░██████████▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░▒▓▓█████████████████████████████████░░░░░░▒█████████████████████████████████▓▒░░░░░░
░░░▒▓███████████████████████████████████▓░░░░░░░░▒███████████████████████████████████▓▒░░░
░░▓████████████████████████████████████▒░░░░░░░░░░▒████████████████████████████████████▓░░
░▓█████████████████████████████████▓▒░░░░░░░░░░░░░░░░▒▓█████████████████████████████████▓░
░██████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓█████████▒
▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒████████▓
▓████████▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒████████▓
▒█████████▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒█████████▓
░▓███████████████████████████████████████▓░░░░░░▒████████████████████████████████████████░
░░████████████████████████████████████████▓░░░░▒████████████████████████████████████████▒░
░░░▓███████████████████████████████████████░░░░▒███████████████████████████████████████▒░░
░░░░░▒████████████████████████████████████▓░░░░▒████████████████████████████████████▓░░░░░


DB FIREARMS PRESENTS: The DOJO Grips
-----------------------------------------------------------
Description: A nice more vertical pistol grip for AR-patterned guns. Includes a beaver tail and will only fit on designs that
support a beaver tail. 

Although these grips are a homage to the Die Free Co. Kung Fu Grip, they are NOT the same.
-----------------------------------------------------------

DOJO: This is about the same width as the Kung Fu. However, the backstrap is wider and the frontstrap is more narrow than 
the Kung Fu. This should be a good fit for most hands. Additionally, styling in general has been tweaked to fit DB's 
preferences. 

DOJO XW: This is XtraWide. And it's like gripping a soda can. This is good for folks that like a fat grip or with the biggest 
of hands. You might hate it if your hands are smaller. It has the same width for the whole grip area instead of tapering 
smaller like the above DOJO grip. 
-----------------------------------------------------------
Printing instructions: 

-These models should drop into your slicer with correct orientation already. However, the suggested orientation would be with the base flat on the build plate. 
-Use 100% Solid Infill as the walls are only around 4mm wide all the way up. So, this should not take a great deal of filament. 
-Use organic supports on build plate. 
-PLA+ or better filament is suggested
-----------------------------------------------------------
dbdesignworks.com

License: Creative Commons Share Alike NON COMMERCIAL


