# DB Alloy Collapsible Brace

by DB Firearms
V1

## Description

This pistol stabilizing brace was originally designed for the Triton 9. It has been revised to fit the DB Alloy with a custom brace body. This version is not compatible directly with the Triton 9 and is a standalone version for the DB ALLOY.

## 

## Hardware Required

For convenience, you can get all of the brace hardware, including high quality rails, at Riptide Rails. 

https://riptiderails.com/mp-17-collapsible-bracestock-bars-and-locking-plate.html



* x4 M3x15mm Button Head Screws (McMaster 92095A119) Brace Attachment Screws
* x4 M3 Hex Nuts (McMaster 90592A085) Brace Attachment Nuts
* x1 M5x30mm Socket Head Screw (McMaster 91290A254) End Clamp Screw
* x1 M5 Nut (McMaster 90593A004) End Clamp Nut
* x1 M2x10mm Dowel Pin (McMaster 91595A026) Button Retainer Pin
* x1 Compression Spring (McMaster 9657K623) Button Spring



You will also need 2x laser cut steel brace bars and 1x laser cut steel locking plate. These can be sent out to sendcutsend in DXF form (in files) with .125" Stainless Steel 





## Instructions

1. Print all parts in the orientation that loads in your slicer. This can be printed in other orientations if you have a bed slinger, or have other reasons. 
2. Slide the bars into the collapsible back piece, notches facing up, working them until smooth. Align a bar notch with the side slot, then install the locking piece as follows:

---Place the spring in the back piece’s channel.

---Use the install tool to compress the spring and slide the locking piece into place.

---Remove the locking tool and insert the button (divot facing out) and secure with the 2mm dowel pin. Test the locking mechanism.

3\. Attach the metal bars to the brace sides using four M3 screws and nuts.

4\. Attach the brace/stock to the upper receiver’s rear with an M5 screw and nut.

## Change Log

* v1.0 Initial Release

## License

Creative Commons Share-alike Non Commercial. Please don't share files during the beta process.

