    \_\_\_\_  \_\_\_\_     \_\_\_\_\_\_\_\_\_\_\_\_\_\_  \_\_\_\_\_\_\_\_\_    \_\_\_\_  \_\_  \_\_\_\_\_\_\_\_

   / \_\_ \\/ \_\_ )   / \_\_\_\_/  \_/ \_\_ \\/ \_\_\_\_/   |  / \_\_ \\/  |/  / \_\_\_/

  / / / / \_\_  |  / /\_   / // /\_/ / \_\_/ / /| | / /\_/ / /|\_/ /\\\_\_ \\

 / /\_/ / /\_/ /  / \_\_/ \_/ // \_, \_/ /\_\_\_/ \_\_\_ |/ \_, \_/ /  / /\_\_\_/ /

/\_\_\_\_\_/\_\_\_\_\_/  /\_/   /\_\_\_/\_/ |\_/\_\_\_\_\_/\_/  |\_/\_/ |\_/\_/  /\_//\_\_\_\_/

 



++++++++DB Alloy MP Open Beta by DB Firearms++++++++





PLEASE REFER TO THE ORIGINAL PDF README FOR ASSEMBLY INSTRUCTIONS. THERE ARE A FEW DIFFERENCES YOU WILL WANT TO REVIEW HERE FIRST HOWEVER



REPORT ISSUES IN THE BETA CHAT ONLY (Not via X or reddit DM's or email)





Magazine Compatibility: The single feed mac bolts are only compatible with STEEL MP5 magazines. Plastic magazines like AC Unity will not work, the feed lips are too thick. My suggestion is to use the SDI Imports/MAC magazines, Zenith magazines, KCI magazines, or HK magazines. All others have NOT been tested. If you try other brands, please report back with how they worked.



REQUIRED MODIFICATION: SHORT STROKE BUFFER. Please install the MPRTech short stroke buffer in the files, printed in TPU 20% infill, 6 walls. DO NOT SKIP. If you skip, your bolt will smack the mag and cause carnage.



Super Safety Compatibility: Due to the MP5 magazine using the full width of the upper to feed, there is no room for a trip bar like the ones used out of titanium. Nightalliance is using a custom trip that will go between the upper and lower. For now, I've rolled the super safe compatible lowers into the design for all models. THIS WILL REQUIRE TRIMMING YOUR REAR ATTACHMENT BOLTS TO 17MM (or installing shorter bolts)



Hardware Changes vs original DB Alloy: All hardware is the same. However, there are a few small additions:

1. For the handguard, you'll need an additional 2 M4x25mm screws and 2 M4 nuts
2. For the magazine release, you'll want to use an AR-15 magazine catch assembly. It will be cut down to size. Refer to photo to reference how much to cut off the bar.
3. See Above for super safe compatibility.



Frame Insert Changes vs original DB Alloy: The front and rear inserts have been modified to allow for swappable accessories. When installing the rear inserts, you'll want to first add your rail of choice at the back before adding the through-bolts. The same for the front. Choose from a front rail, forward grip, or handguard dovetail. Install that before adding the front insert.



Upper Receiver Modification: In order to allow room for the MP5 magazine and the feed ramp, you will need to trim the underside of your upper receiver sheet metal. Start by removing your bolt. Print and add the jig to the upper. Mark with a scribe the new pocket for the magazine cut. Remove jig and cut with a Dremel cutoff wheel. (save this wheel to modify the mag catch as well)



Known issues: 

1. It seems that in order to allow for multiple brands of magazines, some will be closer to the bolt than others. This causes some extra friction when feeding the first round from a full magazine. This will break in over time. Expedite the process of break in with lots of lubrication. Bring some lube to the first shooting session. If your bolt gets stuck back on the first round feeding, try wiggling the mag a bit and it should come forward. Don't ride the bolt home, slingshot it if possible.
2. There are several heights of feed ramp to experiment with. If you get a misfeed where the bullet is stuck at the top of the barrel, try one of the shorter feed ramps which should give a more gradual approach for the bullet exiting the magazine. 





MODDERS: If you choose to make your own accessories, please share them with DB for use in the final release. If you got these files somewhere other than the DB Firearms Odysee, you've been bamboozled.





https://dbdesignworks.com

