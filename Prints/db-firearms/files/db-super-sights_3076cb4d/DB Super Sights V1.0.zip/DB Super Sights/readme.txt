
    ____  ____     ______________  _________    ____  __  ________
   / __ \/ __ )   / ____/  _/ __ \/ ____/   |  / __ \/  |/  / ___/
  / / / / __  |  / /_   / // /_/ / __/ / /| | / /_/ / /|_/ /\__ \ 
 / /_/ / /_/ /  / __/ _/ // _, _/ /___/ ___ |/ _, _/ /  / /___/ / 
/_____/_____/  /_/   /___/_/ |_/_____/_/  |_/_/ |_/_/  /_//____/  
                                                                  

++++++++DB SUPER SIGHTS++++++++

Super simple fixed sights for your basic sight picture. Works best on builds with fixed 1913 Pic rails. 
Prints as one piece with the option to insert bright 1.75mm filament in the front sight for a better sight picture.

REQUIRED HARDWARE: 
(2) M3x30mm Socket Head Cap Screws
(2) M3 Nuts

PRINT ORIENTATION: 
-Print with front of sights flat on build plate. STL has been pre-oriented for simplicity

PRINT SETTINGS: 
-Use PLA+ or better. ABS is preferred to prevent warping on warm days or if left in vehicle. 
-Print on the hotter side to ensure good layer adhesion. PLA+(220c) ABS(250c) 
-No raft or brim needed unless you have difficulty with build plate adhesion
-NO SUPPORTS REQUIRED

ASSEMBLY INSTRUCTIONS: 
-For front sight, insert filament in hole after pre-drilling to size. Use Super Glue to secure filament in hole. Trim excess
with exacto knife once dry to match profile of sight. 
-Slide sights into position then insert M3 bolts through holes. Reaming should not be required unless you used supports.
-Tighten bolts to secure. 

Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself. 

https://db-firearms.com
