DB FIREARMS PRESENTS: 

DB9 Alloy Lage Edition
This version allows for the use of the Lage semi-automatic upper receivers in the DB9 Alloy. Some variation is in place from the original DB9 Alloy. Specifically, the following differences exist:
1. The side plates are different to contour the Lage upper. You will need to order new side plates via sendcutsend or another provider.
2. The lower receivers have the front bottom rail removed. 
3. The rear insert has been modified to slot into the lage upper
4. The front insert has had the bottom rail removed. 
5. The Glock feed ramp has been modified to slot into the Lage upper. If you are using a metal feed ramp you will need to file the sides of the ramp until it fits in the upper. 

Instructions: Please use the original DB Alloy PDF contained in the files for instructions on printing & assembly. 
---------------------------
Parts:
1. Side plates must be ordered. I suggest Sendcutsend. Upload the DXF files to their website and select the following:
	Material: Stainless Steel 304 Series
	Thickness: .125"
	Plate Tapping: tap the holes on the LEFT-PLATE, large holes set to M4 x 0.7 and small holes set to M3 x 0.5
	Coating: Optional powder coating available. 
2. Hardware: This will use the same hardware kit as the DB9 Alloy, so you can use that if you already have it. Refer to PDF for full parts list breakdown. IF you'd like to order the kit, check out dbdesignworks.com. It will use one less bolt in the rear, so you can keep that for extras. 
3. Upper: Any Lage semi-auto receiver should work. However, if you're using the optional Lage side rails on your upper, they will interfere with side plates. You can either shim them out with a washer or sand down your plate to allow them to work. 
4. Glock version - make sure you pick up a magazine release spring. 
5. AR Fire control group, safety selector, detent and spring. 
---------------------------


Special thanks to the following beta testers: 
Krrawn, B Z, Claire, Sarge013, 458Socom