DB's Fire Control Group(FCG) Reinforcement Plates
These plates can be used to reinforce lower receivers that utilize AR-15 fire control groups. They require:
Metal Plates
Anti Walk/Anti Rotation FCG Pins with the screws on either end
Ambidextrous Safety(recommended)
---------------------------------------------------------------------
Instructions for Ordering Plates: 

DXF Files: To be used to send to services for laser cutting. Suggestion is SendCutSend. 
For Sendcutsend, make sure you have the settings set to MM.The plates are the same left to right, so make sure and order an even
amount of plates at minimum 2, so you have a set. 

Thickness and materials: We are shooting for a plate as close to 1mm as possible. So, SendCutSend materials
that will work would be:

Grade 5 Titanium .040"(1.02mm)
Grade 2 Titanium .040"(1.02mm)
304 Stainless Steel .048"(1.22mm)
