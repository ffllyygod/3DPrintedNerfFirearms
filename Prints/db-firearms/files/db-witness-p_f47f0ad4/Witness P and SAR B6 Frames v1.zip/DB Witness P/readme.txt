
    ____  ____     ______________  _________    ____  __  ________
   / __ \/ __ )   / ____/  _/ __ \/ ____/   |  / __ \/  |/  / ___/
  / / / / __  |  / /_   / // /_/ / __/ / /| | / /_/ / /|_/ /\__ \ 
 / /_/ / /_/ /  / __/ _/ // _, _/ /___/ ___ |/ _, _/ /  / /___/ / 
/_____/_____/  /_/   /___/_/ |_/_____/_/  |_/_/ |_/_/  /_//____/  
                                                                  

++++++++The DB Witness P: EAA Witness P Frames by DB Firearms++++++++
++++++++SAR B6: SAR Arms B6 Frames by MPRTECH++++++++++++++++++++++++

These frames are a heavy remix of the frames from FMDA - huge thanks to their work and inspiration on many of my projects. They have been stylized based on the grip profile of the CZ P-07/P-09 and I've added both compact and full size versions. Also, a nice stipple. 
They are designed to use parts kits from the EAA Witness P, which is the polymer SMALL FRAME of the witness in 9mm or 40 S&W.
Additionally, MPRTECH has modified the witness frames to be compatible with the SAR Arms B6 frames which have 
a slightly different rear housing. When searching for parts kits, please be aware that these kits have integrated rails both front and rear. If you don't see the rail inserts, you're not looking at the right kits. 

The small frame witness uses a smaller grip and magazine and was discountinued in the early 2000's. This will not work with witness steel frame kits because they lack the rails, or the newer witness frame kits designed for LARGE FRAMES. If you have a question on compatibility, feel free to reach out to me on twitter @ArthurClaudeen. This is designed for SMALL FRAME FULL SIZE magazines. They hold 17 rounds. 

PRINT ORIENTATION: 
-This is a heavily debated topic. I prefer to print the frame upside down with the 'rails down'. However, many insist that the rails up
method is better, especially for preserving the quality of the inside of your frame. Either way it should wor. Supports on 
build plate. 

PRINT SETTINGS: 
-Frame was tested with PLA+ and proved to be very robust. ABS is preferred to prevent warping on warm days or if left in vehicle. 
-Print on the hotter side to ensure good layer adhesion. PLA+(220c) ABS(250c) 
-No raft or brim needed unless you have difficulty with build plate adhesion
-Supports on build plate

ASSEMBLY INSTRUCTIONS: 
-This frame is super simple to assemble after you've already done it once. The first time can be a bit rough. The trickiest part is the mag release retention doubling as the trigger return plunger. 
Refer to MPRTECH's assembly video here for the SAR. It is almost identical to the witness except you don't have to cut any custom pins for the trigger housing: https://odysee.com/@db-firearms:4/SAR-B6-Assembly-by-mprtech:9?r=8SVHZ93oyys7mceFgWifCLv1YK2tGGTR

Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself. 

https://dbdesignworks.com
