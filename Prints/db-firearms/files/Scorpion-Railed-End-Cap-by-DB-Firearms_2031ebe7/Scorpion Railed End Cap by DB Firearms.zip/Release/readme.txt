Presenting: Scorpion Evo Railed End Cap by DB Firearms

Description: This end cap is designed to be 3d printed and slid on the back of your Scorpion Evo. It will work with OEM Scorpion Evo 3 as well as the new 3+. It is also compatible with the Scorpion Alloy 3d printed receiver. It should work on other printed receivers that use the same dimensions as the OEM receiver in the back. 

It utilizes a section of aluminum 5-slot MLOK rail. It also uses aluminum heat-set QD Socket cups by Hyperion 2a. 

Parts Required: 
(1) 5-slot MLOK rail section like this one: https://www.amazon.com/360-TACTICAL-Slots-Aluminum-Section/dp/B0765RDTWW
(2) M4 x 14mm Flat Head Screws
(2) M4 Hex Nuts
(2) Hyperion2a Heat Set insert QD Sockets like these: https://hyperion2a.com/product/heat-set-quick-disconnect-inserts/


Print Instructions: 
1. Material - this will hold up fine in PLA+ due to using a metal rail. It should last a long time. however, it is suggested that for a real robust product, you print in CF Nylon like NylonX or PA612 by Polymaker. 

2. Print Orientation - Print in the orientation the file loads in with supports on build plate (use organic/tree supports)

3. Temp/Speed - Print as hot as you can with nice results and slow enough for proper layer adhesion. I slow my printer down for these types of parts where strength is key. 


Assembly Instructions: After removing supports and any brim material, check the fitment of your rail. It should fit flush with the back of the end cap. Press in the M4 nuts into the inside/back of the end cap until they are fully seated. Add a dab of loc-tite 242 to your screws and install through the rail and into the nuts. Tighten down to snug (around 15 in/lbs). Using a soldering iron, install the heat set qd sockets into the sides of the end cap. You can use the side of your soldering iron to melt them in. Once nearly flush, use a flat surface to push down fully flush and allow to set in place. Repeat on the other side. Install from the top of your receiver and slide on. Press the retainer button down and allow it to snap into place. DONE. 


dbdesignworks.com

License: Creative Commons Share Alike NON COMMERCIAL