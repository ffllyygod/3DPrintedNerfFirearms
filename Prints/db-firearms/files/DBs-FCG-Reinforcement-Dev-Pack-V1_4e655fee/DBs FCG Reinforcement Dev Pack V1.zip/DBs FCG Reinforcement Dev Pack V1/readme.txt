DB's Fire Control Group(FCG) Reinforcement Development Pack
These plates can be used to reinforce lower receivers that utilize AR-15 fire control groups. They require:
Metal Plates
Anti Walk/Anti Rotation FCG Pins with the screws on either end
Ambidextrous Safety(recommended)
---------------------------------------------------------------------
Instructions for Ordering Plates: 

DXF Files: To be used to send to services for laser cutting. Suggestion is SendCutSend. 
For Sendcutsend, make sure you have the settings set to MM.The plates are the same left to right, so make sure and order an even
amount of plates at minimum 2, so you have a set. 

Thickness and materials: We are shooting for a plate as close to 1mm as possible. So, SendCutSend materials
that will work would be:

Grade 5 Titanium .040"(1.02mm)
Grade 2 Titanium .040"(1.02mm)
304 Stainless Steel .048"(1.22mm)

Other more interesting materials may work but do not go too far past 1mm in thickness.
----------------------------------------------------------------------
Utilizing them in your design: 

Step 1, Placement: You can add the .step file to your own design to reinforce the pin holes. Keep the 
distance between the two plates the same distance, do not change. Distance between plates should be .895". Center the plates
between your lower ensuring they're locked to the Fire Control Group pin holes. 
Step 2, Cut: I use fusion 360 but in other design softwares it will be similar. Use the "Combine" tool 
with the plates as the tool bodies. Make sure you "keep tools" and choose the operation as "cut". 
Step 3, Tolerancing: I like to undersize the locating ribs and oversize the inlay portion in my lower by .2mm so that they fit nicely into the plates.
----------------------------------------------------------------------
Other things to consider: 
1. These plates will sit just a little proud of the sides of your lower. When you tighten down
your anti rotation screws, it will squeeze the plates together and into the lower slightly. This compressive
force is thought to help keep the screws from backing out. You can also use blue loctite on the screws. 
2. It is suggested that you also use some sort of ambidextrous safety to keep your plates in place in the back.
However, this is not required.
3. Use the anti rotation pins with the screws on the end. Most vendors will work but I prefer the stainless type from Dirty Bird.
4. Modification of the plates: There may be times where you need to modify or remove part of the plate in CAD to fit your
design. This is totally ok and not a big deal, just don't remove too much and keep the main components in place. 
5. Tolerance has been taken into consideration based on SendCutSend's tolerance specs, which is oversized by .006". So you may find that
the file has slightly larger than required holes for a standard AR-15. This is by design. If you are producing them yourself
and are capable of tighter tolerances, you may want to account for that in CAD.

GOOD LUCK. This is a free and open-source design released under Creative Commons, Share Alike. I don't want any financial compensation for providing it.
If you do use it, feel free to share with me your application of the tech on social media.

dbdesignworks.com

