
    ____  ____     ______________  _________    ____  __  ________
   / __ \/ __ )   / ____/  _/ __ \/ ____/   |  / __ \/  |/  / ___/
  / / / / __  |  / /_   / // /_/ / __/ / /| | / /_/ / /|_/ /\__ \ 
 / /_/ / /_/ /  / __/ _/ // _, _/ /___/ ___ |/ _, _/ /  / /___/ / 
/_____/_____/  /_/   /___/_/ |_/_____/_/  |_/_/ |_/_/  /_//____/  
                                                                  
## Legal Notice & Compliance Statement

DBDESIGNWORKS is a sole proprietorship based in and operating under the laws of the State of Idaho, USA.

These 3D-printable files are provided **exclusively for lawful personal use** by individuals who are:
- Not prohibited from possessing or manufacturing firearms under federal law (including 18 U.S.C. § 922(g)), and
- Fully authorized under all applicable federal, state, and local laws in their jurisdiction of residence to manufacture firearm components or complete firearms.

**These files are not intended for, and are not offered or distributed to, residents of any state or jurisdiction where the possession, manufacture, download, or use of these files is prohibited or requires a specific license that the user does not possess.** This includes, but is not limited to, the State of California.

By downloading, accessing, or using any file from this repository or website, you expressly represent and warrant that:
1. You are a law-abiding adult in full compliance with all federal, state, and local laws governing firearms and firearm-related items in your jurisdiction.
2. You are not located in, and will not use these files in, any jurisdiction where such activity is illegal.
3. You will not distribute, share, or sell these files in violation of any law.

**DB Design Works complies with all applicable federal and Idaho state laws.** We make no representation that these files are legal in your specific state or locality. It is solely your responsibility to determine the legality of these files, to verify your own eligibility, and to ensure full compliance before downloading or using them.

These files are provided **"AS IS"** without any warranty, express or implied. DB Design Works disclaims all liability for any loss, damage, injury, or legal consequence arising from the use or misuse of these files. Any unlawful use is strictly prohibited and is a violation of this notice.

If you are unsure whether you may legally download or use these files in your jurisdiction, do not download them.


++++++++SAR K2 .45 ACP +2 Magazine Extension by DB Firearms++++++++


This is a simple +2 magazine extension for the SAR K2 chambered in .45ACP. This extension will replace your factory baseplate and floorplate. Just remove the old ones, slide this on, and add a small screw at the back to prevent the magazine body from falling out. 

PRINT ORIENTATION: 
-The extension has been pre-oriented in its ideal print orientation for a material like PLA+. If you are printing in a Nylon based filament, there is a small flat spot on the back corner of the extension that will work better for CF Nylon or GF Nylon. 

PRINT SETTINGS: 
-PLA+ will be ok...but if it gets too hot in the summer sun it may cause rapid magazine disassembly. Test in PLA and print a final version in a more robust filament. I suggest Fiberon PA12CF10. https://amzn.to/4eBzCt9
-Print on the hotter side to ensure good layer adhesion. PLA+(220c)
-No raft or brim needed unless you have difficulty with build plate adhesion
-Use Organic Supports

ASSEMBLY INSTRUCTIONS: 

### Important Notes Before Starting
- Ensure **all support material** has been completely removed and any rough edges have been lightly sanded or deburred.
- Work on a stable surface and wear safety goggles if you are worried about a spring hitting your eyeballz.

### Step-by-Step Assembly

1. **Remove Factory Parts**  
   Place a small punch in the hole in the bottom of the baseplate to depress the floor plate/lock. Slide the baseplate off and remove the floor plate. You will not be using either of these parts. 

2. **Install Extension**  
   Push the magazine spring fully into the mag body and slide the extension on from the front of the mag/back of the extension until the spring bottoms out inside the extension.

3. **Install Retainer Screw**  
   Install a 3mmx8mm socket head screw into the hole at the back and screw it down until it bottoms out. Don't over-tighten.   

4. **Check Capacity**  
   Using a mag loader like this one: https://amzn.to/4cyeCRm to check that you can load 16 rounds of .45ACP. Unload all rounds(important) and check that the magazine locks into the gun and the slide locks back. 

---

Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself. 

https://dbdesignworks.com
