DB's MLOK QD Sling Swivel Mount

Utilizes these QD Socket Heat Inserts by Hyperion 2A: https://hyperion2a.com/product/heat-set-quick-disconnect-inserts/

Print Settings:
PLA+ or better. I suggest CF Nylon for a long lasting piece. Though these have been known to withstand over 200lbs of force in PLA+

Print orientation: Print with the cup facing up with the MLOK nubs on the build plate. Supports on build plate

Melting in QD insert: Use the side of a soldering iron to gently apply pressure to the aluminum QD cup. It will slowly melt in. Don't apply 
extra pressure. A small amount will be enough once the cup gets to the right temperature. To finish the melting in, push the cup in upside
down on a flat surface. Allow to fully cool before using. 

This uses M4x12mm flat head screws with mlok style nuts on the back. https://www.amazon.com/GOTICAL-M-Lok-Replacement-Screws-mlok/dp/B07WL7XQHJ
ENJOY
DBdesignworks.com