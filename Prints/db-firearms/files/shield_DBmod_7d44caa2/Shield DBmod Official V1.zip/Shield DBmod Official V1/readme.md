
    ____  ____     ______________  _________    ____  __  ________
   / __ \/ __ )   / ____/  _/ __ \/ ____/   |  / __ \/  |/  / ___/
  / / / / __  |  / /_   / // /_/ / __/ / /| | / /_/ / /|_/ /\__ \ 
 / /_/ / /_/ /  / __/ _/ // _, _/ /___/ ___ |/ _, _/ /  / /___/ / 
/_____/_____/  /_/   /___/_/ |_/_____/_/  |_/_/ |_/_/  /_//____/  
                                                                  

## Legal Notice & Compliance Statement

DBDESIGNWORKS is a sole proprietorship based in and operating under the laws of the State of Idaho, USA.

These 3D-printable files are provided **exclusively for lawful personal use** by individuals who are:
- Not prohibited from possessing or manufacturing firearms under federal law (including 18 U.S.C. § 922(g)), and
- Fully authorized under all applicable federal, state, and local laws in their jurisdiction of residence to manufacture firearm components or complete firearms.

**These files are not intended for, and are not offered or distributed to, residents of any state or jurisdiction where the possession, manufacture, download, or use of these files is prohibited or requires a specific license that the user does not possess.** This includes, but is not limited to, the State of California.

By downloading, accessing, or using any file from this repository or website, you expressly represent and warrant that:
1. You are a law-abiding adult in full compliance with all federal, state, and local laws governing firearms and firearm-related items in your jurisdiction.
2. You are not located in, and will not use these files in, any jurisdiction where such activity is illegal.
3. You will not distribute, share, or sell these files in violation of any law.

**DB Design Works complies with all applicable federal and Idaho state laws.** We make no representation that these files are legal in your specific state or locality. It is solely your responsibility to determine the legality of these files, to verify your own eligibility, and to ensure full compliance before downloading or using them.

These files are provided **"AS IS"** without any warranty, express or implied. DB Design Works disclaims all liability for any loss, damage, injury, or legal consequence arising from the use or misuse of these files. Any unlawful use is strictly prohibited and is a violation of this notice.

If you are unsure whether you may legally download or use these files in your jurisdiction, do not download them.


++++++++The Shield DBmod: A Smith & Wesson M&P Shield Frame by DB Firearms++++++++


These frames are designed to turn your original Shield parts kits back into functional firearms. YAY!
The main frame was edited from the gatalog release by FMDA (Thanks FMDA you're the GOAT)
Also, big thanks to OA for helping with the 7rd magazine baseplate!

There are 2 styles of frames in the files. Textured, and Blank. If you prefer to add your own texture, the blank STL should provide that jumping off point. Additionally, there is a grip sleeve for the 8rd magazines to match the frame profile and a baseplate for the 7rd magazines. If you are buying mags for the first time, I'd suggest you get the 8rd mags and NOT 7rd. Also, there is a frame version for kits that don't have a manual safety.

NOTES ON KITS AND MAGAZINES: This is for the original Shield and I didn't consider the Shield Plus in the design.


PRINT ORIENTATION: 
-All frames have been pre-oriented in their ideal print orientation(Rails Down, upside-down on build plate). If you are printing in a Nylon based filament, you may choose to rotate it 45 degrees. 

PRINT SETTINGS: 
-Frame should hold up fine in PLA+ as it's rather thick. However, be cool and print in this filament and your frame will last long time: https://amzn.to/3MP8L12
-Print on the hotter side to ensure good layer adhesion. PLA+(220c)
-No raft or brim needed unless you have difficulty with build plate adhesion
-Use Organic Supports

ASSEMBLY INSTRUCTIONS: 
Work in a clean, well-lit area on a stable surface. Always follow all firearm safety rules and local laws.

## Recommended Tools
- Small hammer or mallet
- Pin punch / roll pin starter
- Pick or small flat screwdriver
- Hand drill or pin vise
- Needle-nose pliers (optional)
- Safety glasses

## Step-by-Step Assembly

1. **Magazine Catch Spring**  
   Insert the magazine catch spring from the bottom of the frame. There's a nice hole for it!  
   If it resists, gently tap it upward with a small hammer until the spring is about ¾ visible in the magazine catch hole.  
   Insert the magazine catch and use a pick to bend/guide the spring into its slot on the catch.

2. **Prepare Pin Holes**  
   Ream all pin holes with a drill bit slightly smaller than the pins.  
   Alternatively, spin each pin in its hole (using a hand drill) until it melts through for a perfect fit.

3. **Rear Sear Assembly**  
   Install the rear sear assembly (with or without manual safety).  
   Insert the rear roll pin (this will be tight — use a punch and hammer if needed). Tap until flush.

4. **Trigger Assembly**  
   Drop the trigger assembly (with spring attached) into the frame and slide it forward into the front of the sear assembly.

5. **Locking Block Assembly**  
   Confirm the locking block spring is installed on the left side.  
   Insert the slide stop lever into the locking block.  
   Drop the complete assembly into the frame.

6. **Large Trigger Pivot Pin**  
   Insert from the **left side** of the frame in this order:  
   Locking block → Left trigger → Trigger return spring → Right trigger → Locking block → Out right side.  
   Tap gently until flush on the left.  
   **Tip:** If the pin catches on the spring, use a pick to gently pull the spring aside.

7. **Front Locking Block Roll Pin**  
   Drive the front roll pin in until flush on both sides.

8. **Takedown Lever**  
   Insert the takedown lever into the locking block (align the small protrusion with the hole).  
   Rotate **clockwise** until it points to the **6:00** position.

## Final Assembly & Function Check

9. **Install Slide**  
   Put the slide on the frame.  
   Pull the slide fully rearward and lock it open with the slide stop.  
   Rotate the takedown lever **counter-clockwise** to the **3:00** position.  
   Release the slide.

10. **Function Checks** (perform in order)
    - Magazine inserts and ejects cleanly  
    - Slide locks back on empty magazine (pull firmly near end of travel)  
    - Slide travels forward and cocks the striker  
    - Trigger releases the striker cleanly  
    - Check feeding **using snap caps only**

11. **Magazine Baseplate and Sleeve**
    - 7rd baseplate slides in place in lieu of factory baseplate. Just remove old and install new.  
    - 8rd sleeve will slip over magazine from the top and should lock into place. Watch for securing notches to click over factory baseplate.

## Safety Notes
- Ensure the firearm is **completely unloaded** during all assembly and testing.  
- Verify all pins are fully seated and nothing binds.  
- Test all safety features (manual safety if equipped) before live fire.  
- If anything feels wrong or binds excessively, stop and inspect parts for proper fit.  
- These instructions assume correctly manufactured parts. Minor fitting may be required.
- There are small dots where the manual safety resides. You can add some dabs of red and white paint here to signify safe/fire. 

---

**Your S&W Shield-style pistol is now fully assembled.**  

Perform a final visual inspection, then proceed to range testing at a safe location.  

**Stay safe and follow all local laws.**




Special Thanks to you for your support. You are so cool, you are beautiful. Have a nice day and remember to take care of yourself. 

https://dbdesignworks.com
