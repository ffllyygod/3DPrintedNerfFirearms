# Tec-Nein BETA

The Tec-Nein is a 3d printable lower receiver for the Intratec Tec-9 upper and lower parts kits. It will fit all variants of the Tec-9 that utilize a threaded end cap. This variant uses MP5 magazines. 

Frame by Revision Arms, with testing and small modifications by DB Firearms



## Description

This is a BETA and subject to change. Print at your own risk. Please report any feedback via the comments on Odysee. 



PLEASE NOTE: At this time it is not suggested you use AC Unity magazines with this design. Due to the slightly larger feed lips, they don't sit quite the same as the metal mags and cause feeding problems. Stick to metal magazines. 



## Materials Required

* Complete Tec-9 parts kit including upper receiver with bolt and complete lower parts kit including ejector
* MP5 patterned magazines in steel. 





*Other Components*

If you're using the 3d printed mag catch, you'll need the following parts

* &nbsp;	1x M3x30 socket head screw
* &nbsp;	1x 3mm heat set insert
* &nbsp;	1x M3 Nut
* &nbsp;	1x compression spring about like this one: https://www.springsfast.com/products/compression-springs/part-detail-compression-spring/?part=C08-032-024



If you're using a metal mag catch, you can buy it from revision arms by emailing sales@revisionarms.com

You can also buy a pre-cut ejector so you don't need to modify yours. 



## Printing Instructions

1. Load all files into your 3D printing slicer and print them in their default orientation using PLA filament. All files have been oriented and scaled properly.
2. Choose PLA+ or a stronger filament. Do not use PETG or silk filaments. Set your printer’s temperature as high as possible without losing accuracy, around 220°C (check your filament’s recommended settings).  Use cooling to prevent warping. The bed temp  should be set to around 60°C or whatever your filament recommends.
3. Use a layer height of 0.2 mm or smaller.
4. Select a 0.4 mm nozzle to ensure precise parts, as the design includes 0.2 mm clearance for moving components.
5. Enable FULL organic tree supports in your slicer.
6. Use a strong wall/infill combination. 8 walls with 100% infill is the suggested combination.
7. These are print suggestions. If you have a better print profile, please use it. However, do not alter the print orientation of the model unless you know exactly what you're doing. Otherwise, you could experience print failures related to the design.



## Assembly Instructions

1. Remove all supports
2. Cut your ejector like the photo in the files. It will need a small amount of clearance to allow you to install the mag catch.
3. Install the lower parts by first reaming all holes to size. Putting the pin in a drill and spinning it to enlarge the hole is a good option for a perfect fit. Install all lower parts. For now you can use the guide in the files if you need help. This will be updated at some point to show the correct receiver. Install the ejector and pin as well. 
4. If you are printing your mag catch, install the heat insert in the back of the button portion. Install the nut in the catch portion. Then, thread the m3 screw about 80% of the way through the latch side of the mag catch. Install it in the frame and slide the spring over the screw as you push it in. Add the button on the other side of the frame and finish installing the screw to pull the button inwards. 
5. Install your upper and takedown pin and check function. 



## Change Log

* version B1: Initial Beta

## License

Creative Commons License Share Alike NON Commercial

