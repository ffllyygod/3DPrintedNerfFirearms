# The Remote Buoy

This is a simple print to attach to your Apple TV Clone remote so you don't lose it in the couch cushions or under some furniture. Is it ugly? Sort of. But hey, you won't misplace that pesky remote anymore. 





## Materials Required

*You will need some PLA filament, a 3d printer, and a remote. This ONLY fits the remote from Amazon for the apple tv. Available HERE:*

*https://amzn.to/47fU92n (this is an affiliate link, so purchasing will help me buy more filament)*

## 

## Printing Instructions

1. Load file into your 3D printing slicer and print in the default orientation using PLA filament. The file has been oriented and scaled properly.
2. Use any filament you'd like. Something LESS BRITTLE is better as there is a compliance mechanism on the latch holding the remote in place. Set your printer’s temperature as high as possible without losing accuracy, around 220°C (check your filament’s recommended settings).  Use cooling to prevent warping. The bed temp  should be set to around 60°C or whatever your filament recommends.
3. Use a layer height of 0.2 mm
4. Select a 0.4 mm nozzle to ensure precise parts
5. Enable FULL organic tree supports in your slicer
6. Infill isn't super important. 2+ walls and 2+ top/bottom layers. Maybe 20% infill? 
7. These are print suggestions. If you have a better print profile, please use it.

## Assembly Instructions

1. Install the remote and push down until it clips in. That's it. 

## Change Log

* v1.0: Initial Release

## License

Creative Commons License Share Alike NON Commercial

